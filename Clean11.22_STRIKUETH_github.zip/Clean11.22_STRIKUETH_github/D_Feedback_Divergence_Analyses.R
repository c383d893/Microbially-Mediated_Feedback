#### FEEDBACK-MICROBIAL DIVERGENCE ANALYSES ####

# load packages
library(tidyverse)
library(ggplot2)
library(lsmeans)
library(dplyr)
library(lubridate)
library(lmerTest)
library(gridExtra)
library(lme4)
library(gdata)
library(ggeffects)
library(vegan)
library(phyloseq)
library(gdata)

###############################
######### READ IN DATA ########
###############################

# read census data 
pdat <- readRDS('data/census.meta.data.complete.rds')

# read blup estimates from biomass models
blup.filt <- readRDS("data/blup_estimated_biomass.rds") %>%
  mutate(Adult_Tag = as.character(Adult_Tag), Seedling_Species = as.character(Seedling_Species)) %>%
  distinct(Exclosure_Tag, .keep_all=TRUE) %>%
  drop_na()

# survival data
# assign alive Oct 1 (day 227)
surv.A <- pdat %>% filter(Survival==1 & mdoy >=227) %>% distinct(Seedling_ID,.keep_all=TRUE)
# assign dead Oct 1 (day 227)
surv.D <- pdat %>% filter(Survival==0 & mdoy <227)

# join surv.A and surv. D and determine proportion survived per exclosure
surv.filt <- rbind(surv.A, surv.D) %>%
  group_by(Exclosure_Tag, Survival) %>%
  summarize(N = n()) %>%
  mutate(prop = N / sum(N)) %>%
  filter(Survival == 1) %>%
  rename(propsurv = prop) %>%
  left_join(pdat, by = "Exclosure_Tag") %>%
  dplyr::select(c('Exclosure_Tag','propsurv','Adult_Tag','Adult_Species','Seedling_Species')) %>%
  distinct(Exclosure_Tag,.keep_all=TRUE)%>%
  drop_na()

###############################
##### PAIRWISE FEEDBACK #######
###############################

#choose one
# blup extracted biomass
dat.filt <- blup.filt
# survival
dat.filt <- surv.filt   

# set all combinations
sp.comb <- c("DG_HC", "DG_HT", "DG_SA", "HC_HT", "HC_SA", "SA_HT", "HC_DG", "HT_DG", "SA_DG", "HT_HC", "SA_HC", "HT_SA")
  
feedback.out <- data.frame()
# for sp combinations
for(P in sp.comb){ 
  # get A and B
  A <- substr(P, start = 1, stop = 2)
  B <- substr(P, start = 4, stop = 5)
  # subset data to pairs
    pair.dat <- dat.filt %>% filter(Adult_Species == A & Seedling_Species == A | Adult_Species == B & Seedling_Species == A| Adult_Species == A & Seedling_Species == B |Adult_Species == B & Seedling_Species == B) %>%
      mutate(type = case_when(Adult_Species == A & Seedling_Species == A  ~ "Aa",  
                              Adult_Species == B & Seedling_Species == B ~ "Bb",
                              Adult_Species == A & Seedling_Species == B ~ "Ab",
                              Adult_Species == B & Seedling_Species == A ~ "Ba")) 
    # given A adult tag, choose B adult tag
    Adult_TagA <- pair.dat %>% as.data.frame() %>% filter(Adult_Species == A) %>% dplyr::select(Adult_Tag) %>% distinct() %>% t() %>% as.vector()
    Adult_TagB <- pair.dat %>% as.data.frame() %>% filter(Adult_Species == B) %>% dplyr::select(Adult_Tag) %>% distinct() %>% t() %>% as.vector()
    rep.dat.out <- data.frame()
     for(AT in Adult_TagA){
      rep.datA <- pair.dat %>% filter(Adult_Tag==AT)
      for(BT in Adult_TagB){
        rep.datB <- pair.dat %>% filter(Adult_Tag==BT)
        rep.dat <- rbind(rep.datA, rep.datB) 
        rep.dat.bio <- rep.dat %>%
          group_by(type) %>%
          #!!change metric here: mean_totalbiomass; propsurv - sum or mean
          summarize(metric = mean(mean_totalbiomass))
        Aa <- rep.dat.bio %>% filter(type=="Aa") %>% dplyr::select(metric)
        Bb <- rep.dat.bio %>% filter(type=="Bb") %>% dplyr::select(metric)
        Ab <- rep.dat.bio %>% filter(type=="Ab") %>% dplyr::select(metric)
        Ba <- rep.dat.bio %>% filter(type=="Ba") %>% dplyr::select(metric)
        if (nrow(Ab)==0 | nrow(Bb)==0 |nrow(Aa) == 0 |nrow(Ba)==0){
          print ("incomplete pair")
        }else{
        fb.coef <-  Aa - Ba - Ab + Bb
        out.dat <- cbind(A,B,AT,BT,fb.coef)
        rep.dat.out <- rbind(rep.dat.out, out.dat)
        }
      }
     }
    feedback.out <- rbind(feedback.out,rep.dat.out)
  }

feedback.out <- feedback.out %>% mutate(ATBT= paste(AT,BT,sep="_")) %>%
  distinct(ATBT,.keep_all=TRUE) %>%
  rename(feedback = metric)

###############################
##### MICROBIAL DIVERGENCE ####
###############################

# read in data
dat.A <- readRDS("data/psAMFtaxmeta.rds") 
dat.O <- readRDS("data/ps.soil.OOMYtaxmeta.rds") 
dat.P <- readRDS("data/ps.psoil.taxmeta.rds")
dat.NP <- readRDS("data/ps.npsoil.taxmeta.rds") 

# sum across exclosures

###############################
############# AMF #############
###############################
dat.asv.A <- dat.A %>% 
  dplyr::select(-c("Seedling_ID", "Sample_Name", "Seedling_Species", "Adult_Species", "Group", "Sample_Type",   
                   "Timepoint", "Conhetero", "InOut","Exclosure_Tag")) %>% 
  group_by(Adult_Tag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('Adult_Tag')

asv.A = otu_table(as.matrix(dat.asv.A), taxa_are_rows = FALSE)     
ps.A <- phyloseq(asv.A) 

# rarify to even depth to compare between samples; based on values in C_Micorbial_Analyses.R
set.seed(609) 
sample_sums(ps.A)
ps.rare.A <- rarefy_even_depth(ps.A,sample.size = 1000)

# calculate bray distance
asv.rare.A <- t(as(otu_table(ps.rare.A),'matrix')) 
bray_dist.A <- as.matrix(distance(ps.rare.A, method = "bray", type = "samples")) %>% unmatrix() %>% as.data.frame()
colnames(bray_dist.A) <- c("bray.A")

# clean data
bray_dist.df.A <- bray_dist.A %>% rownames_to_column("Adult_TagC") %>%
  separate(Adult_TagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag, Btag, sep = "_")) %>%
  dplyr::select(-c("Atag","Btag")) %>%
  filter(!bray.A == 0) %>% 
  distinct(ATBT,.keep_all = TRUE)

###############################
############ OOMY #############
###############################

dat.otu.O <- dat.O %>% 
  dplyr::select(-c("Seedling_ID", "Sample_Name", "Seedling_Species", "Adult_Species", "Group", "Sample_Type",   
                   "Timepoint", "Conhetero", "InOut","Exclosure_Tag")) %>% 
  group_by(Adult_Tag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('Adult_Tag')

otu.O = otu_table(as.matrix(dat.otu.O), taxa_are_rows = FALSE)     
ps.O <- phyloseq(otu.O) 

# rarify to even depth to compare between samples; based on values in C_Micorbial_Analyses.R
set.seed(609) 
sample_sums(ps.O)
ps.rare.O <- rarefy_even_depth(ps.O,sample.size = 18000)

# calculate bray distance
asv.rare.O <- t(as(otu_table(ps.rare.O),'matrix')) 
bray_dist.O <- as.matrix(distance(ps.rare.O, method = "bray", type = "samples")) %>% unmatrix() %>% as.data.frame()
colnames(bray_dist.O) <- c("bray.O")

# clean data
bray_dist.df.O <- bray_dist.O %>% rownames_to_column("Adult_TagC") %>%
  separate(Adult_TagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag, Btag, sep = "_")) %>%
  dplyr::select(-c("Atag","Btag")) %>%
  filter(!bray.O == 0) %>% 
  distinct(ATBT,.keep_all = TRUE)

###############################
######## FUN PATHOGEN #########
###############################

dat.asv.P <- dat.P %>% 
  dplyr::select(-c("Seedling_ID", "Sample_Name", "Seedling_Species", "Adult_Species", "Group", "Sample_Type",   
                   "Timepoint", "Conhetero", "InOut","Exclosure_Tag")) %>% 
  group_by(Adult_Tag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('Adult_Tag')

asv.P = otu_table(as.matrix(dat.asv.P), taxa_are_rows = FALSE)     
ps.P <- phyloseq(asv.P) 

# rarify to even depth to compare between samples; based on values in C_Micorbial_Analyses.R
set.seed(609) 
sample_sums(ps.P)
ps.rare.P <- rarefy_even_depth(ps.P,sample.size = 100)

# calculate bray distance
asv.rare.P <-t(as(otu_table(ps.rare.P),'matrix')) 
bray_dist.P <- as.matrix(distance(ps.rare.P, method = "bray", type = "samples"))  %>% unmatrix() %>% as.data.frame()
colnames(bray_dist.P) <- c("bray.P")

# clean data
bray_dist.df.P <- bray_dist.P %>% rownames_to_column("Adult_TagC") %>%
  separate(Adult_TagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag,Btag,sep="_")) %>%
  dplyr::select(-c("Atag","Btag")) %>%
  filter(!bray.P==0) %>% 
  distinct(ATBT,.keep_all=TRUE)

###############################
####### FUN NON PATHOGEN ######
###############################

dat.asv.NP <- dat.NP %>% 
  dplyr::select(-c("Seedling_ID", "Sample_Name", "Seedling_Species", "Adult_Species", "Group", "Sample_Type",   
                   "Timepoint", "Conhetero", "InOut","Exclosure_Tag")) %>% 
  group_by(Adult_Tag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('Adult_Tag')

asv.NP <- otu_table(as.matrix(dat.asv.NP), taxa_are_rows = FALSE)     
ps.NP <- phyloseq(asv.NP) 

# rarify to even depth to compare between samples; based on values in C_Micorbial_Analyses.R
set.seed(609) 
sample_sums(ps.NP)
ps.rare.NP <- rarefy_even_depth(ps.NP,sample.size = 10000)

# calculate bray distance
asv.rare.NP <- t(as(otu_table(ps.rare.NP),'matrix')) 
bray_dist.NP <- as.matrix(distance(ps.rare.NP, method = "bray", type = "samples"))  %>% unmatrix() %>% as.data.frame()
colnames(bray_dist.NP) <- c("bray.NP")

# clean data
bray_dist.df.NP <- bray_dist.NP %>% rownames_to_column("Adult_TagC") %>%
  separate(Adult_TagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag,Btag, sep = "_")) %>%
  dplyr::select(-c("Atag", "Btag")) %>%
  filter(!bray.NP == 0) %>% 
  distinct(ATBT,.keep_all = TRUE)

###############################
#### JOIN ALL AND REGRESS #####
###############################

dat.reg <- feedback.out %>%
  mutate(ATBTmatch = map2_chr(AT, BT, ~toString(sort(c(.x, .y))))) %>%
  distinct(ATBTmatch, .keep_all=TRUE) %>%
  dplyr::select(-ATBTmatch) %>%
  left_join(bray_dist.df.NP, by = "ATBT") %>%
  left_join(bray_dist.df.P, by = "ATBT") %>%
  left_join(bray_dist.df.A, by = "ATBT") %>%
  left_join(bray_dist.df.O, by = "ATBT") %>%
  mutate(AB = map2_chr(A, B, ~toString(sort(c(.x, .y))))) 

# choose one:
m1 <- lm(feedback ~ bray.NP + bray.P + bray.A + bray.O, data = dat.reg)
m1 <- lm(feedback ~ bray.NP, data = dat.reg)
m1 <- lm(feedback ~ bray.P, data = dat.reg)
m1 <- lm(feedback ~ bray.A, data = dat.reg)
m1 <- lm(feedback ~ bray.O, data = dat.reg)

summary(m1)

# check model
par(mfrow = c(2, 2))
plot(m1)

###############################
####### GENERATE PLOTS ########
###############################

# TOTAL BIOMASS NON-PATHOGEN
new.dat <- with(dat.reg, expand.grid(bray.NP = seq(min(na.omit(dat.reg$bray.NP)), max(na.omit(dat.reg$bray.NP)), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.NP=new.dat$bray.NP)

TB.NP <-
ggplot(data = pred,aes(x = bray.NP, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.NP),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Non-pathogen)") +
  ylab("Feedback (Biomass)")+
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

# TOTAL BIOMASS PATHOGEN
new.dat <- with(dat.reg, expand.grid(bray.P = seq(min(na.omit(dat.reg$bray.P)), max(na.omit(dat.reg$bray.P)), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.P=new.dat$bray.P)

TB.P <-
  ggplot(data = pred,aes(x = bray.P, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.P),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Pathogen)") +
  ylab("Feedback (total biomass)")+
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

# SURVIVAL NON-PATHOGEN 
new.dat <- with(dat.reg, expand.grid(bray.NP = seq(min(na.omit(dat.reg$bray.NP)), max(na.omit(dat.reg$bray.NP)), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.NP=new.dat$bray.NP)

SUR.NP <- 
  ggplot(data = pred,aes(x = bray.NP, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.P),color="dimgrey", size= 2) +
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Non-Pathogen)") +
  ylab("Feedback (Survival)")+
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

# SURVIVAL PATHOGEN 
new.dat <- with(dat.reg, expand.grid(bray.P = seq(min(na.omit(dat.reg$bray.P)), max(na.omit(dat.reg$bray.P)), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.P=new.dat$bray.P)

SUR.P <- 
  ggplot(data = pred,aes(x = bray.P, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.P),color="dimgrey", size= 2) +
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Pathogen)") +
  ylab("Feedback (Survival)")+
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

png("Figures/BrayDiss.jpg", width=12, height= 6, units='in', res=300)
grid.arrange(TB.NP,SUR.P, ncol=2)
dev.off()

# BIOMASS NP (FULL MODEL)
new.dat <- with(dat.reg, expand.grid(bray.NP = seq(min(na.omit(dat.reg$bray.NP)), max(na.omit(dat.reg$bray.NP)), length = 100))) %>% 
  mutate(bray.P = mean(m1$model$bray.P),bray.A = mean(m1$model$bray.A), bray.O = mean(m1$model$bray.O))
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.NP=new.dat$bray.NP)

TB.NP.FULL <-
  ggplot(data = pred,aes(x = bray.NP, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.NP),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Non-pathogen Fungi)") +
  ylab("Feedback (Biomass)")+
  theme_classic()+
  theme(#axis.text.x = element_blank(),  
        #axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

# BIOMASS A (FULL MODEL)
new.dat <- with(dat.reg, expand.grid(bray.A = seq(min(na.omit(dat.reg$bray.A)), max(na.omit(dat.reg$bray.A)), length = 100))) %>% 
  mutate(bray.P = mean(m1$model$bray.P),bray.NP = mean(m1$model$bray.NP), bray.O = mean(m1$model$bray.O))
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.A=new.dat$bray.A)

TB.A.FULL <-
  ggplot(data = pred,aes(x = bray.A, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.A),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (AMF)") +
  ylab("")+
  theme_classic()+
  theme(#axis.text.x = element_blank(),  
        #axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

png("Figures/BrayDiss_FullModel.jpg", width=12, height= 6, units='in', res=300)
grid.arrange(TB.NP.FULL,TB.A.FULL, ncol=2)
dev.off()
