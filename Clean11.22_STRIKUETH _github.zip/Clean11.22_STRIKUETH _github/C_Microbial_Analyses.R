#### MICROBIAL ANALYSES ####

## COMMUNITY COMPOSITION
## DIFFERENTIAL ABUNDANCE

# load packages
library(tidyverse)
library(ggplot2)
library(lsmeans)
library(dplyr)
library(lmerTest)
library(pbkrtest)
library(gridExtra)
library(phyloseq)
library(vegan)
library(MASS)
library(lme4)
library(devtools)  
library(pairwiseAdonis)  
library(VennDiagram)     

#################################
##### COMMUNITY COMPOSITION #####
#################################

# create PERMANOVA function
perm5 <- function(dataset, expvar1, expvar2 = NA, expvar3 = NA){
  tax.rare <- t(as(otu_table(dataset), 'matrix'))
  smd.rare <- as(sample_data(dataset), 'data.frame')
  y <- "tax.rare"
  ifelse(is.na(expvar2), groupvars <- expvar1,
         ifelse(is.na(expvar3), groupvars <- c(expvar1, expvar2), groupvars <- c(expvar1, expvar2, expvar3)))
  formular <- as.formula(paste(y, paste(groupvars, collapse = "*"), sep ="~"))
  set.seed(609)
  perm <- how(nperm = 999)
  setBlocks(perm) <- with(smd.rare, smd.rare$Exclorure_Tag)
  ps.perm <- adonis2(formular, permutations = 999, data = smd.rare, method = 'bray')
  return(ps.perm)
}

# set colors
DG_Blue = rgb(75/255, 94/255, 160/255, 1)
HC_Green = rgb(121/255, 132/255, 27/255, 1)
HT_Yellow = rgb(218/255, 168/255, 17/255, 1)
SA_Purple = rgb(170/255, 142/255, 200/255, 1)

colScale <- scale_colour_manual(values = c(DG_Blue, HC_Green, HT_Yellow, SA_Purple))
fillScale <- scale_fill_manual(values = c(DG_Blue, HC_Green, HT_Yellow, SA_Purple))

# load meta data
meta <- readRDS("data/mol.meta.data.complete.rds") 

# generate subsets of AMF and FUN
metaAMF <- meta %>% filter(Group=="AMF")
rownames(metaAMF) <- metaAMF$Sample_Name
metaFUN <- meta %>% filter(Group=="FUN")
rownames(metaFUN) <- metaFUN$Sample_Name
metaOOMY <- meta %>% filter(Group=="OOMY")
rownames(metaOOMY) <- metaOOMY$Sample_Name

#####################################
##### AMF COMMUNITY COMPOSITION #####
#####################################

tax <- read.csv("data/ASVtable_clean_AMFonly.csv") %>% 
  t(.) %>% 
  as.data.frame() %>%
  rownames_to_column(var = "sample_names") %>%
  separate(sample_names, c("part1", "part2", "part3", "part4", "part5"), sep = "_", remove = TRUE) %>% 
  mutate(sample_names = paste(part1, part2, part3, sep = "_")) %>% 
  dplyr::select(-c("part1", "part2", "part3", "part4", "part5")) %>% 
  column_to_rownames("sample_names") %>%
  t(.)%>% 
  as.data.frame() %>%
  dplyr::rename(Taxa.ID = Taxa.ID_NA_NA)

rownames(tax) <- tax$Taxa.ID 
tax <- tax %>%
  dplyr::select(-Taxa.ID)  %>%
  mutate_all(as.numeric)
tax <- as.matrix(tax)

ph.taxAMF <- otu_table(tax, taxa_are_rows=TRUE)
ph.metaAMF <- sample_data(metaAMF)

psAMF <- phyloseq(ph.taxAMF, ph.metaAMF) %>%
  prune_taxa(taxa_sums(.)>0,.) %>%
  prune_samples(sample_sums(.)>0,.) %>% 
  subset_samples(.,!Adult_Species=="NA") %>%   
  subset_samples(.,!Seedling_Species=="NA")   

ps1AMF <- psAMF %>% subset_samples(Timepoint == "1") 

# for feedback_divergence
# extract data
psAMFmeta <- as(sample_data(ps1AMF), 'data.frame')
psAMFtax <- t(as(otu_table(ps1AMF), 'matrix'))

# join
psAMFtaxmeta <- psAMFtax %>%
  as.data.frame() %>%
  mutate(Sample_Name = rownames(.)) %>%
  left_join(psAMFmeta, by= "Sample_Name")

# write out
saveRDS(psAMFtaxmeta,"data/psAMFtaxmeta.rds")

#####################################
########### AMF PERMANOVA ###########
#####################################

set.seed(609) 
sample_sums(ps1AMF) 
hist(sample_sums(ps1AMF), breaks = 20) 
ps1AMF.rare <- rarefy_even_depth(ps1AMF, sample.size = 1000) 
perm5(ps1AMF.rare, "Adult_Species", "Seedling_Species")

#####################################
##### OOMY COMMUNITY COMPOSITION ####
#####################################

tax <- read.table("data/table_or_97_STRI_OOMY_R1_prune.txt", header=TRUE) %>% 
  dplyr::rename(Taxa.ID = OTU_ID)

rownames(tax) <- tax$Taxa.ID 
tax <- tax %>%
  dplyr::select(-Taxa.ID)  %>%
  mutate_all(as.numeric)
tax <- as.matrix(tax)

# prep for phyloseq
ph.taxOOMY <- otu_table(tax, taxa_are_rows=TRUE)
ph.metaOOMY <- sample_data(metaOOMY)

# filter
psOOMY <- phyloseq(ph.taxOOMY, ph.metaOOMY) %>%
  prune_taxa(taxa_sums(.)>0,.) %>%
  prune_samples(sample_sums(.)>0,.) %>% 
  subset_samples(.,!Adult_Species=="NA") %>%   
  subset_samples(.,!Seedling_Species=="NA")   

# timepoint one clean
ps1OOMY <- psOOMY %>% subset_samples(Timepoint=="1") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.) 

# soil v root
ps1OOMY_soil <- ps1OOMY %>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)
ps1OOMY_root <- ps1OOMY %>% subset_samples(Sample_Type=="Root") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)

# for feedback_divergence
# extract soil data
psOOMY.soilmeta <- as(sample_data(ps1OOMY_soil), 'data.frame')
psOOMY.soiltax <- t(as(otu_table(ps1OOMY_soil), 'matrix'))

# join
psOOMY.soiltaxmeta <- psOOMY.soiltax %>%
  as.data.frame() %>%
  mutate(Sample_Name = rownames(.)) %>%
  left_join(psOOMY.soilmeta, by= "Sample_Name")

# write out
saveRDS(psOOMY.soiltaxmeta,"data/ps.soil.OOMYtaxmeta.rds")

#####################################
####### OOMY PERMANOVA: SOIL ########
#####################################

# soil
set.seed(609) 
sample_sums(ps1OOMY_soil) 
hist(sample_sums(ps1OOMY_soil), breaks = 20) 
ps1OOMY_soil.rare <- rarefy_even_depth(ps1OOMY_soil, sample.size = 18000) 
perm5(ps1OOMY_soil.rare, "Adult_Species", "Seedling_Species")

# pairwise permanova seedling species
smd1.oomy_soil.rare <- as(sample_data(ps1OOMY_soil.rare), 'data.frame')
taxOOMY.soil.rare <- t(as(otu_table(ps1OOMY_soil.rare), 'matrix'))
pairwise.adonis(taxOOMY.soil.rare, smd1.oomy_soil.rare$Seedling_Species)

#####################################
####### OOMY PERMANOVA: ROOT ########
#####################################

# root
set.seed(609) 
sample_sums(ps1OOMY_root) 
hist(sample_sums(ps1OOMY_root), breaks = 20) 
ps1OOMY_root.rare <- rarefy_even_depth(ps1OOMY_root, sample.size = 15000) 
perm5(ps1OOMY_root.rare, "Adult_Species", "Seedling_Species")

#####################################
######### OOMY PERMANOVA PLOT #######
#####################################

# oomy soil
mp.bray.nmds <- ordinate(ps1OOMY_soil.rare, distance = 'bray', method = 'NMDS')
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaOOMY, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

oomy.soil <- 
  ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Adult_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.3, 0.3)+
  ylim(-0.3, 0.3)+
  colScale+
  fillScale+
  ggtitle("Soil community")+
  guides(color=guide_legend("Adult species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

# oomy root
mp.bray.nmds <- ordinate(ps1OOMY_root.rare, distance = 'bray', method = 'NMDS')
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaOOMY, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

oomy.root <- 
ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Seedling_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.6, 0.6)+
  ylim(-0.6, 0.6)+
  colScale+
  fillScale+
  ggtitle("Root community")+
  guides(color=guide_legend("Seedling species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))


png("Figures/NMDS_oomy.soil.jpg", width = 5, height = 5, units = 'in', res = 300)
oomy.soil
dev.off()

png("Figures/NMDS_oomy.root.jpg", width = 5, height = 5, units = 'in', res = 300)
oomy.root
dev.off()

#####################################
##### OOMY VENN DIAGRAMS: PATH ######
#####################################

# extract root v soil to compare
otaxasoil <- colnames(t(as(otu_table(ps1OOMY_soil), 'matrix')))
otaxaroot <- colnames(t(as(otu_table(ps1OOMY_root), 'matrix')))

list.path<-list(otaxasoil,otaxaroot)
names(list.path) <- c("Soil", "Root")

venn.diagram(
  x = list.path,
  category.names = c("", ""),
  filename = 'figures/VennOomy.png',
  output=TRUE,
  imagetype = "png" ,
  height = 480 , 
  width = 480 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c("darkblue", "darkred"), 
  cex = .6)

#####################################
##### FUN COMMUNITY COMPOSITION #####
#####################################

taxaFUN <- read.csv('data/table_or_97_STRI_ASVFUN_R1_R2_forR.csv', header=TRUE)
taxaFUN <- column_to_rownames(taxaFUN,'Taxa_ID') 

guildFUN <- read.csv('data/table_or_97_STRI_ASVFUN_R1_R2_tax.guilds.csv', header=TRUE)
guildFUN <- guildFUN %>% dplyr::select(Taxa_ID, Guild, Confidence.Ranking)

ID.guildFUN <- guildFUN %>% filter(!Guild=="-")

# write .csv
write.csv(ID.guildFUN,"data/FUNGuild_IdentifiedTaxa.csv")

# extract path guilds
path <- guildFUN %>% filter(Guild=="Plant Pathogen" | Guild=="Plant Pathogen-Wood Saprotroph"|Guild=="Plant Pathogen-Plant Saprotroph"| 
                            Guild=="Endophyte-Plant Pathogen-Undefined Saprotroph"|Guild=="Endophyte-Fungal Parasite-Plant Pathogen"|  
                            Guild=="Leaf Saprotroph-Plant Pathogen-Undefined Saprotroph-Wood Saprotroph"| Guild=="Plant Pathogen-Undefined Parasite-Undefined Saprotroph"|
                            Guild=="Animal Endosymbiont-Animal Pathogen-Endophyte-Plant Pathogen-Undefined Saprotroph"|Guild=="Dung Saprotroph-Endophyte-Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Endophyte-Plant Pathogen"| Guild=="Ectomycorrhizal-Fungal Parasite-Plant Pathogen-Wood Saprotroph"|
                            Guild=="Fungal Parasite-Plant Pathogen"| Guild=="Endophyte-Leaf Saprotroph-Plant Pathogen"|
                            Guild=="Endophyte-Plant Pathogen-Plant Saprotroph"| Guild=="Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Endophyte-Lichen Parasite-Plant Pathogen-Undefined Saprotroph"| Guild=="Fungal Parasite-Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Fungal Parasite-Plant Pathogen-Plant Saprotroph") %>% 
  mutate(newGuild = "Pathogen") %>% 
  filter(Confidence.Ranking!= "Possible") 

# get all other fungi
npath <- anti_join(guildFUN, path, by='Taxa_ID') %>% mutate(newGuild="Non-Pathogen") 

# join
guildFUN2 <- rbind(path,npath) %>%
  column_to_rownames(., 'Taxa_ID')%>%
  as.matrix(.)

# prep for phyloseq
ph.taxaFUN <- otu_table(taxaFUN, taxa_are_rows=TRUE) 
ph.metaFUN <- sample_data(metaFUN)	
ph.guildFUN <- tax_table(guildFUN2) 

# filter
psFUN <- phyloseq(ph.taxaFUN, ph.metaFUN,ph.guildFUN) %>% 
  prune_taxa(taxa_sums(.)>0,.) %>% 
  prune_samples(sample_sums(.)>0,.) %>%
  subset_samples(.,!Adult_Species=="NA") %>% 
  subset_samples(.,!Seedling_Species=="NA") %>% 
  subset_samples(., !Sample_Type=="Leaf")

# timepoint one clean
ps1FUN <- psFUN %>% subset_samples(Timepoint=="1") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.) 

# path and non
ps1FUN.p <- ps1FUN %>% subset_taxa(newGuild=="Pathogen") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)  
ps1FUN.n <- ps1FUN %>% subset_taxa(newGuild=="Non-Pathogen") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.) 

# path soil and root
ps1FUN.p_soil <- ps1FUN.p %>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)
ps1FUN.p_root <- ps1FUN.p %>% subset_samples(Sample_Type=="Root") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)

# non path soil and root
ps1FUN.n_soil <- ps1FUN.n %>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)
ps1FUN.n_root <- ps1FUN.n %>% subset_samples(Sample_Type=="Root") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)

# timepoint 2 clean
ps2FUN<- psFUN %>% subset_samples(Timepoint=="2") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.) 

# path and non
ps2FUN.p<- ps2FUN %>% subset_taxa(newGuild=="Pathogen") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)  
ps2FUN.n<- ps2FUN %>% subset_taxa(newGuild=="Non-Pathogen") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)

# soil path and non (same as above)
ps2FUN.p_soil <- ps2FUN.p %>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)
ps2FUN.n_soil <- ps2FUN.n %>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)

# timepoint 1 and 2 clean
psTPFUN.p_soil <- psFUN %>% subset_taxa(newGuild=="Pathogen") %>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)
psTPFUN.n_soil <- psFUN %>% subset_taxa(newGuild=="Non-Pathogen") %>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>0,.) %>% prune_samples(sample_sums(.)>0,.)

# for feedback_divergence
# extract data soil path
ps.psoil.meta <- as(sample_data(ps1FUN.p_soil), 'data.frame')
ps.psoil.tax <- t(as(otu_table(ps1FUN.p_soil), 'matrix'))

# join
ps.psoil.taxmeta <- ps.psoil.tax %>%
  as.data.frame() %>%
  mutate(Sample_Name = rownames(.)) %>%
  left_join(ps.psoil.meta, by = "Sample_Name")

# write out
saveRDS(ps.psoil.taxmeta,"data/ps.psoil.taxmeta.rds")

# extract data soil nonpath
ps.nsoil.meta <- as(sample_data(ps1FUN.n_soil), 'data.frame')
ps.nsoil.tax <- t(as(otu_table(ps1FUN.n_soil), 'matrix'))

# join
ps.nsoil.taxmeta <- ps.nsoil.tax %>%
  as.data.frame() %>%
  mutate(Sample_Name = rownames(.)) %>%
  left_join(ps.nsoil.meta, by= "Sample_Name")

# write out
saveRDS(ps.nsoil.taxmeta,"data/ps.npsoil.taxmeta.rds")

#####################################
##### FUN1 VENN DIAGRAMS: PATH ######
#####################################

# extract root v soil to compare
ptaxasoil <- colnames(t(as(otu_table(ps1FUN.p_soil), 'matrix')))
ptaxaroot <- colnames(t(as(otu_table(ps1FUN.p_root), 'matrix')))

list.path <- list(ptaxasoil, ptaxaroot)
names(list.path) <- c("Soil", "Root")

venn.diagram(
  x = list.path,
  category.names = c("", ""),
  filename = 'figures/VennFunPath.png',
  output=TRUE,
  imagetype="png" ,
  height = 480 , 
  width = 480 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill=c("darkblue", "darkred"), 
  cex = .6,
  rotation.degree = 180)

#####################################
#### FUN1 VENN DIAGRAMS: NON PATH ###
#####################################

ntaxasoil <- colnames(t(as(otu_table(ps1FUN.n_soil), 'matrix')))
ntaxaroot <- colnames(t(as(otu_table(ps1FUN.n_root), 'matrix')))

list.np <- list(ntaxasoil, ntaxaroot)
names(list.np) <- c("Soil", "Root")

venn.diagram(
  x = list.np,
  category.names = c("", ""),
  filename = 'figures/VennFunNonPath.png',
  output=TRUE,
  imagetype="png" ,
  height = 480 , 
  width = 480 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill=c("darkblue", "darkred"),
  cex = .6)

#####################################
###### FUN1 PERMANOVA: PATH SOIL ####
#####################################

set.seed(609) 
sample_sums(ps1FUN.p_soil)
hist(sample_sums(ps1FUN.p_soil), breaks = 20) 
ps1FUN.p_soil.rare <- rarefy_even_depth(ps1FUN.p_soil,sample.size=250) 
perm5(ps1FUN.p_soil.rare, "Adult_Species", "Seedling_Species")

#####################################
###### FUN1 PERMANOVA: PATH ROOT ####
#####################################

set.seed(609) 
sample_sums(ps1FUN.p_root)
hist(sample_sums(ps1FUN.p_root), breaks = 20) 
ps1FUN.p_root.rare <- rarefy_even_depth(ps1FUN.p_root,sample.size=250) # change this according to lowest read number
perm5(ps1FUN.p_root.rare, "Adult_Species", "Seedling_Species")

# pairwise permanova seedling species
smd1.p_root.rare <- as(sample_data(ps1FUN.p_root.rare), 'data.frame')
taxFUN.p_root.rare <- t(as(otu_table(ps1FUN.p_root.rare), 'matrix'))
pairwise.adonis(taxFUN.p_root.rare, smd1.p_root.rare$Seedling_Species)

#####################################
#### FUN1 PERMANOVA: NON PATH SOIL ##
#####################################

set.seed(609) 
sample_sums(ps1FUN.n_soil)
hist(sample_sums(ps1FUN.n_soil), breaks = 20) 
ps1FUN.n_soil.rare <- rarefy_even_depth(ps1FUN.n_soil,sample.size=10000) 
perm5(ps1FUN.n_soil.rare, "Adult_Species", "Seedling_Species")

# pairwise permanova adult species
smd1.n_soil.rare <- as(sample_data(ps1FUN.n_soil.rare), 'data.frame')
taxFUN.n_soil.rare <- t(as(otu_table(ps1FUN.n_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.n_soil.rare, smd1.n_soil.rare$Adult_Species)

#####################################
#### FUN1 PERMANOVA: NON PATH ROOT ##
#####################################

set.seed(609) 
sample_sums(ps1FUN.n_root)
hist(sample_sums(ps1FUN.n_root), breaks = 20) 
ps1FUN.n_root.rare <- rarefy_even_depth(ps1FUN.n_root,sample.size=3000) 
perm5(ps1FUN.n_root.rare, "Adult_Species", "Seedling_Species")

# pairwise permanova seedling species
smd1.n_root.rare <- as(sample_data(ps1FUN.n_root.rare), 'data.frame')
taxFUN.n_root.rare <- t(as(otu_table(ps1FUN.n_root.rare), 'matrix'))
pairwise.adonis(taxFUN.n_root.rare, smd1.n_root.rare$Seedling_Species)

# pairwise permanova adult species
smd1.n_root.rare <- as(sample_data(ps1FUN.n_root.rare), 'data.frame')
taxFUN.n_root.rare <- t(as(otu_table(ps1FUN.n_root.rare), 'matrix'))
pairwise.adonis(taxFUN.n_root.rare, smd1.n_root.rare$Adult_Species)

#####################################
######### FUN1 PERMANOVA PLOT #######
#####################################

# fun path soil
mp.bray.nmds <- ordinate(ps1FUN.p_soil.rare, distance = 'bray', method = 'NMDS')
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

p.soil <- 
  ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Adult_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.7, 0.7)+
  ylim(-0.7, 0.7)+
  colScale+
  fillScale+
  ggtitle("Soil community")+
  guides(color=guide_legend("Adult species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

# fun non path root
smd <- as(sample_data(ps1FUN.p_root.rare), 'data.frame')
mp.bray.nmds <- ordinate(ps1FUN.n_root.rare, distance='bray', method='NMDS')
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

p.root <- 
  ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Seedling_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.3, 0.3)+
  ylim(-0.3, 0.3)+
  colScale+
  fillScale+
  ggtitle("Root community")+
  guides(color=guide_legend("Seedling species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

# fun non path soil
mp.bray.nmds <- ordinate(ps1FUN.n_soil.rare, distance='bray', method='NMDS') 
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

np.soil <- 
  ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Adult_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.7, 0.7)+
  ylim(-0.7, 0.7)+
  colScale+
  fillScale+
  ggtitle("Soil community")+
  guides(color=guide_legend("Adult species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

# fun non path root
smd <- as(sample_data(ps1FUN.n_root.rare), 'data.frame')
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

np.root <- ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Seedling_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.3, 0.3)+
  ylim(-0.3, 0.3)+
  colScale+
  fillScale+
  ggtitle("Root community")+
  guides(color=guide_legend("Seedling species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

png("Figures/NMDS_p.soil.jpg", width=5, height= 5, units='in', res=300)
p.soil
dev.off()

png("Figures/NMDS_p.root.jpg", width=5, height= 5, units='in', res=300)
p.root
dev.off()

png("Figures/NMDS_np.soil.jpg", width=5, height= 5, units='in', res=300)
np.soil
dev.off()

png("Figures/NMDS_np.root.jpg", width=5, height= 5, units='in', res=300)
np.root
dev.off()

#####################################
#### FUN2 PERMANOVA: PATH SOIL ######
#####################################

set.seed(609) 
sample_sums(ps2FUN.p_soil)
hist(sample_sums(ps2FUN.p_soil), breaks = 20) 
ps2FUN.p_soil.rare <- rarefy_even_depth(ps2FUN.p_soil,sample.size=250) 
perm5(ps2FUN.p_soil.rare, "Adult_Species", "Seedling_Species")

# pairwise permanova adult species
smd2.p_soil.rare <- as(sample_data(ps2FUN.p_soil.rare), 'data.frame')
taxFUN.p_soil.rare <- t(as(otu_table(ps2FUN.p_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.p_soil.rare, smd2.p_soil.rare$Adult_Species)

#####################################
#### FUN2 PERMANOVA: NON PATH SOIL ##
#####################################

set.seed(609) 
sample_sums(ps2FUN.n_soil)
hist(sample_sums(ps2FUN.n_soil), breaks = 20) 
ps2FUN.n_soil.rare <- rarefy_even_depth(ps2FUN.n_soil,sample.size = 10000) 
perm5(ps2FUN.n_soil.rare, "Adult_Species", "Seedling_Species")

# pairwise permanova adult species
smd2.n_soil.rare <- as(sample_data(ps2FUN.n_soil.rare), 'data.frame')
taxFUN.n_soil.rare <- t(as(otu_table(ps2FUN.n_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.n_soil.rare, smd2.n_soil.rare$Adult_Species)

#####################################
######### FUN2 PERMANOVA PLOT #######
#####################################

# fun path soil
mp.bray.nmds <- ordinate(ps2FUN.p_soil.rare, distance = 'bray', method = 'NMDS')
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

#p2.soil <- 
  ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Adult_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-14, -13)+
  ylim(32.5, 33.5)+
  colScale+
  fillScale+
  ggtitle("Soil community")+
  guides(color=guide_legend("Adult species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

# fun non path soil
mp.bray.nmds <- ordinate(ps2FUN.n_soil.rare, distance='bray', method='NMDS') 
data.scores <- as.data.frame(scores(mp.bray.nmds, "sites"))
data.scores$Sample_Name <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample_Name") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

np2.soil <- 
  ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Adult_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.75, 0.75)+
  ylim(-0.75, 0.75)+
  colScale+
  fillScale+
  ggtitle("Soil community")+
  guides(color=guide_legend("Adult species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

png("Figures/NMDS_p2.soil.jpg", width=5, height= 5, units='in', res=300)
p2.soil
dev.off()

png("Figures/NMDS_np2.soil.jpg", width=5, height= 5, units='in', res=300)
np2.soil
dev.off()

#####################################
#### FUN1+2 PERMANOVA: PATH SOIL ####
#####################################

set.seed(609)
sample_sums(psTPFUN.p_soil)
hist(sample_sums(psTPFUN.p_soil), breaks = 20) 
psTPFUN.p_soil.rare <- rarefy_even_depth(psTPFUN.p_soil, sample.size = 100)

taxTPFUN.p_soil.rare<-t(as(otu_table(psTPFUN.p_soil.rare),'matrix'))
rownames(taxTPFUN.p_soil.rare)
smdTPFUN.p_soil.rare <- as(sample_data(psTPFUN.p_soil.rare), 'data.frame')

set.seed(609) 
perm <- how(nperm = 999)
setBlocks(perm) <- with(smdTPFUN.p_soil.rare, smdTPFUN.p_soil.rare$Exclorure_Tag)
psTPFUN.p_soil.perm<- adonis2(taxTPFUN.p_soil.rare ~ Adult_Species*Timepoint + Seedling_Species, permutations = 999, data= smdTPFUN.p_soil.rare, method='bray')
psTPFUN.p_soil.perm

# pairwise permanova adult species
smdTP.p_soil.rare <- as(sample_data(psTPFUN.p_soil.rare), 'data.frame')
taxFUN.p_soil.rare <- t(as(otu_table(psTPFUN.p_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.p_soil.rare, smdTP.p_soil.rare$Adult_Species)

##########################################
#### FUN1 + 2 PERMANOVA: NON PATH SOIL ###
##########################################

set.seed(609)
sample_sums(psTPFUN.n_soil)
hist(sample_sums(psTPFUN.n_soil), breaks = 20) 
psTPFUN.n_soil.rare <- rarefy_even_depth(psTPFUN.n_soil, sample.size = 10000)

taxTPFUN.n_soil.rare <- t(as(otu_table(psTPFUN.n_soil.rare),'matrix'))
rownames(taxTPFUN.n_soil.rare)
smdTPFUN.n_soil.rare <- as(sample_data(psTPFUN.n_soil.rare), 'data.frame')

set.seed(609)
perm <- how(nperm = 999)
setBlocks(perm) <- with(smdTPFUN.n_soil.rare, smdTPFUN.n_soil.rare$Exclorure_Tag)
psTPFUN.n_soil.perm <- adonis2(taxTPFUN.n_soil.rare ~ Adult_Species*Timepoint + Seedling_Species, permutations = 999, data= smdTPFUN.n_soil.rare, method='bray')
psTPFUN.n_soil.perm

# pairwise permanova adult species
smdTP.n_soil.rare <- as(sample_data(psTPFUN.n_soil.rare), 'data.frame')
taxFUN.n_soil.rare <- t(as(otu_table(psTPFUN.n_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.n_soil.rare, smdTP.n_soil.rare$Adult_Species)

#####################################
####### DIFFERENTIAL ABUNDANCE ######
#####################################

# define p-adjust function
p.adjust2 <- function (p, method = p.adjust.methods, n = length(p)) 
{
  method <- match.arg(method)
  if (method == "fdr") 
    method <- "BH"
  nm <- names(p)
  p <- as.numeric(p)
  p0 <- setNames(p, nm)
  if (all(nna <- !is.na(p))) 
    nna <- TRUE
  else p <- p[nna]
  lp <- length(p)
  #stopifnot(n >= lp)
  if (n <= 1) 
    return(p0)
  if (n == 2 && method == "hommel") 
    method <- "hochberg"
  p0[nna] <- switch(method, bonferroni = pmin(1, n * p), holm = {
    i <- seq_len(lp)
    o <- order(p)
    ro <- order(o)
    pmin(1, cummax((n + 1L - i) * p[o]))[ro]
  }, hommel = {
    if (n > lp) p <- c(p, rep.int(1, n - lp))
    i <- seq_len(n)
    o <- order(p)
    p <- p[o]
    ro <- order(o)
    q <- pa <- rep.int(min(n * p/i), n)
    for (j in (n - 1L):2L) {
      ij <- seq_len(n - j + 1L)
      i2 <- (n - j + 2L):n
      q1 <- min(j * p[i2]/(2L:j))
      q[ij] <- pmin(j * p[ij], q1)
      q[i2] <- q[n - j + 1L]
      pa <- pmax(pa, q)
    }
    pmax(pa, p)[if (lp < n) ro[1L:lp] else ro]
  }, hochberg = {
    i <- lp:1L
    o <- order(p, decreasing = TRUE)
    ro <- order(o)
    pmin(1, cummin((n + 1L - i) * p[o]))[ro]
  }, BH = {
    i <- lp:1L
    o <- order(p, decreasing = TRUE)
    ro <- order(o)
    pmin(1, cummin(n/i * p[o]))[ro]
  }, BY = {
    i <- lp:1L
    o <- order(p, decreasing = TRUE)
    ro <- order(o)
    q <- sum(1/(1L:n))
    pmin(1, cummin(q * n/i * p[o]))[ro]
  }, none = p)
  p0
}

# set contrasts
contrasts <- list("home vs. away" = c(3,-1,-1,-1,-1,3,-1,-1,-1,-1,3,-1,-1,-1,-1,3),
                  "DG_HC"= c(1,-1,0,0,-1,1,0,0,0,0,0,0,0,0,0,0),
                  "DG_HT"= c(1,0,-1,0,0,0,0,0,-1,0,1,0,0,0,0,0),
                  "DG_SA"= c(1,0,0,-1,0,0,0,0,0,0,0,0,-1,0,0,1),
                  "HC_HT"= c(0,0,0,0,0,1,-1,0,0,-1,1,0,0,0,0,0),
                  "HC_SA"= c(0,0,0,0,0,1,0,-1,0,0,0,0,0,-1,0,1),
                  "HT_SA"= c(0,0,0,0,0,0,0,0,0,0,1,-1,0,0,-1,1),
                  "DG_avg"= c(3,-1,-1,-1,-1,1,0,0,-1,0,1,0,-1,0,0,1),
                  "HC_avg"= c(1,-1,0,0,-1,3,-1,-1,0,-1,1,0,0,-1,0,1),
                  "HT_avg"= c(1,0,-1,0,0,1,-1,0,-1,-1,3,-1,0,0,-1,1),
                  "SA_avg"= c(1,0,0,-1,0,1,0,-1,0,0,1,-1,-1,-1,-1,3)
)

#####################################
##### AMF DIFFERENTIAL ABUNDANCE ####
#####################################

tax.amf <- t(as(otu_table(ps1AMF),'matrix')) 
colsum <- colSums(tax.amf!= 0) 
tax.amf <- rbind(tax.amf,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.amf <- tax.amf[!(row.names(tax.amf) %in% row.names.remove), ] 

smd1.amf <- as(sample_data(ps1AMF), 'data.frame') 
smd1.amf  <- smd1.amf[rownames(smd1.amf) %in% rownames(tax.amf), ]

taxa <- tax.amf
smd <- smd1.amf

# loop glm over
output.amf <- data.frame() 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model <- lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_Tag), data = smd)
  joint_tests(model)
  means <- emmeans(model, ~ Seedling_Species*Adult_Species)
  results <- lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.amf <- rbind(output.amf,results) 
}

# add otu names
names <- rep(colnames(taxa), each = 11)
output.amf$Taxon <- names

# adjust p for multiple comparisons
output.amf$padj <- p.adjust2(output.amf$p.value, method = "BH", n = length(unique(output.amf$Taxon)))

# write .csv
write.csv(output.amf, file = "data/DiffAbundanceAMF.csv")
output.amf <- read.csv("data/DiffAbundanceAMF.csv")

##########################################
##### AMF DIFFERENTIAL ABUNDANCE PLOT ####
##########################################

# subset and filter output data
op.a.soil.dght <- output.amf %>%
  filter(contrast == "DG_HT") %>%
  filter(padj < 0.05) %>%
  filter(Taxon != "ASV_489") 

op.a.soil.hcht <- output.amf %>%
  filter(contrast == "HC_HT") %>%
  filter(padj < 0.05) %>%
  filter(Taxon != "ASV_489" & Taxon != "ASV_1129") 

# subset taxa DGHT
taxa.dght <- taxa %>%
  t(.) %>%
  as.data.frame() %>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.a.soil.dght, by = "Taxon")

rownames(taxa.dght) <- taxa.dght$Taxon
taxa.dght <- taxa.dght %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# subset taxa HCHT
taxa.hcht <- taxa %>%
  t(.) %>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.a.soil.hcht, by = "Taxon")

rownames(taxa.hcht) <- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# plot DGHT
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species == "DG"&means$Seedling_Species == "DG") 
                                 | (means$Adult_Species == "DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT"&means$Seedling_Species == "DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_DGHT_ASoil", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.dght, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

# plot HT-HC
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

for(i in colnames(taxa.hcht)) {                                                             
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hthc <- means %>% filter((means$Adult_Species =="HC" & means$Seedling_Species == "HC") 
                                 | (means$Adult_Species =="HC" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HC")) %>%
    mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_HTHC_Asoil", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.hthc, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.hthc[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

##########################################
#### OOMY SOIL DIFFERENTIAL ABUNDANCE ####
##########################################

tax.o.soil <- t(as(otu_table(ps1OOMY_soil),'matrix')) 
colsum <- colSums(tax.o.soil!= 0) 
tax.o.soil <- rbind(tax.o.soil,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.o.soil<-tax.o.soil[!(row.names(tax.o.soil) %in% row.names.remove), ] 

smd1.o.soil <- as(sample_data(ps1OOMY_soil), 'data.frame') 
smd1.o.soil <- smd1.o.soil[rownames(smd1.o.soil) %in% rownames(tax.o.soil), ] 

taxa <- tax.o.soil
smd <- smd1.o.soil

# loop glm over
output.o.soil<-data.frame() 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_Tag), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.o.soil<- rbind(output.o.soil,results) 
}

## add taxa names
names <- rep(colnames(taxa), each = 11)
output.o.soil$Taxon <- names

## adjust p for multiple comparisons
output.o.soil$padj <- p.adjust2(output.o.soil$p.value, method = "BH", n= length(unique(output.o.soil$Taxon)))

# write .csv
write.csv(output.o.soil, file = "data/DiffAbundanceOOMYsoil.csv")
output.o.soil <- read.csv("data/DiffAbundanceOOMYsoil.csv")

###############################################
#### OOMY SOIL DIFFERENTIAL ABUNDANCE PLOT ####
###############################################

# subset and filter output data
op.o.soil.dght <- output.o.soil %>%
  filter(contrast == "DG_HT") %>%
  filter(padj < 0.05) %>%
  filter(Taxon != "c6390ccb47705e05025b150a89137919")

op.o.soil.hcht <- output.o.soil %>%
  filter(contrast == "HC_HT") %>%
  filter(padj < 0.05) %>%
  filter(Taxon != "c6390ccb47705e05025b150a89137919")

# subset taxa DGHT
taxa.dght <- taxa %>%
  t(.) %>%
  as.data.frame() %>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.o.soil.dght, by = "Taxon")

rownames(taxa.dght) <- taxa.dght$Taxon
taxa.dght <- taxa.dght %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# subset taxa HCHT
taxa.hcht <- taxa %>%
  t(.) %>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.o.soil.hcht, by = "Taxon")

rownames(taxa.hcht) <- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# plot DGHT
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species == "DG"&means$Seedling_Species == "DG") 
                                 | (means$Adult_Species == "DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT"&means$Seedling_Species == "DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_DGHT_OSoil", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width = 10, height = 10, units = 'in', res = 300)
  print({ggplot(means.dght, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 25000, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

# plot HT-HC
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

for(i in colnames(taxa.hcht)) {                                                             
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hthc <- means %>% filter((means$Adult_Species =="HC" & means$Seedling_Species == "HC") 
                                 | (means$Adult_Species =="HC" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HC")) %>%
  mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_HTHC_Osoil", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.hthc, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.hthc[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 25000, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

##########################################
#### OOMY ROOT DIFFERENTIAL ABUNDANCE ####
##########################################

tax.o.root <- t(as(otu_table(ps1OOMY_root),'matrix')) 
colsum <- colSums(tax.o.root!= 0) 
tax.o.root <- rbind(tax.o.root,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.o.root<-tax.o.root[!(row.names(tax.o.root) %in% row.names.remove), ] 

smd1.o.root <- as(sample_data(ps1OOMY_root), 'data.frame') 
smd1.o.root  <- smd1.o.root[rownames(smd1.o.root) %in% rownames(tax.o.root), ] 

taxa <- tax.o.root
smd <- smd1.o.root

# loop glm over
output.o.root<-data.frame() 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_Tag), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results <-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.o.root <- rbind(output.o.root,results) 
}

# add taxa names
names <- rep(colnames(taxa), each = 11)
output.o.root$Taxon <- names

# adjust p for multiple comparisons
output.o.root$padj <- p.adjust2(output.o.root$p.value, method = "BH", n= length(unique(output.o.root$Taxon)))

# write .csv
write.csv(output.o.root, file = "data/DiffAbundanceOOMYroot.csv")
output.o.root <- read.csv("data/DiffAbundanceOOMYroot.csv")

###############################################
#### OOMY ROOT DIFFERENTIAL ABUNDANCE PLOT ####
###############################################

# subset and filter output data
op.o.root.dght <- output.o.root %>%
  filter(contrast == "DG_HT") %>%
  filter(padj < 0.05) 
# no significant contrasts

op.o.root.hcht <- output.o.root %>%
  filter(contrast == "HC_HT") %>%
  filter(padj < 0.05) 
# no significant contrasts

#####################################
##### FUN DIFFERENTIAL ABUNDANCE ####
#####################################

#################################################
##### FUN1 DIFFERENTIAL ABUNDANCE: PATH SOIL ####
#################################################

tax.p.soil <- t(as(otu_table(ps1FUN.p_soil),'matrix')) 
colsum <- colSums(tax.p.soil!= 0) 
tax.p.soil <- rbind(tax.p.soil,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.p.soil<-tax.p.soil[!(row.names(tax.p.soil) %in% row.names.remove), ] 

smd1.p.soil <- as(sample_data(ps1FUN.p_soil), 'data.frame') 
smd1.p.soil  <- smd1.p.soil[rownames(smd1.p.soil) %in% rownames(tax.p.soil), ] 

taxa <- tax.p.soil
smd <- smd1.p.soil

# loop glm over
output.p.soil<-data.frame() 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_Tag), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.p.soil<- rbind(output.p.soil,results) 
}

## add taxa names
names <- rep(colnames(taxa), each = 11)
output.p.soil$Taxon <- names

## adjust p for multiple comparisons
output.p.soil$padj <- p.adjust2(output.p.soil$p.value, method = "BH", n = length(unique(output.p.soil$Taxon)))

# write .csv
write.csv(output.p.soil, file = "data/DiffAbundancePsoil.csv")
output.p.soil <- read.csv("data/DiffAbundancePsoil.csv")

######################################################
##### FUN1 DIFFERENTIAL ABUNDANCE: PATH SOIL PLOT ####
######################################################

# subset and filter output data
op.p.soil.dght <- output.p.soil %>%
  filter(contrast == "DG_HT") %>%
  filter(padj < 0.05) 
# no significant contrasts

op.p.soil.hcht <- output.p.soil %>%
  filter(contrast == "HC_HT") %>%
  filter(padj < 0.05) 
# no significant contrasts

#################################################
##### FUN1 DIFFERENTIAL ABUNDANCE: PATH ROOT ####
#################################################

tax.p.root <- t(as(otu_table(ps1FUN.p_root),'matrix')) 
colsum <- colSums(tax.p.root!= 0) 
tax.p.root <- rbind(tax.p.root,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>%
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.p.root<-tax.p.root[!(row.names(tax.p.root) %in% row.names.remove), ] 

smd1.p.root <- as(sample_data(ps1FUN.p_root), 'data.frame') 
smd1.p.root  <- smd1.p.root[rownames(smd1.p.root) %in% rownames(tax.p.root), ] 

taxa <- tax.p.root
smd <- smd1.p.root

# loop glm over 
output.p.root <- data.frame() 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model <- lmer(taxa[,i]~ Seedling_Species*Adult_Species + (1|Adult_Tag:InOut), data = smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results <- lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.p.root <- rbind(output.p.root,results) 
}

# add taxa names
names <- rep(colnames(taxa), each = 11)
output.p.root$Taxon <- names

# adjust p for multiple comparisons
output.p.root$padj <- p.adjust2(output.p.root$p.value, method = "BH", n = length(unique(output.p.root$Taxon))) 

# write .csv
write.csv(output.p.root, file = "data/DiffAbundanceProot.csv")
output.p.root <- read.csv("data/DiffAbundanceProot.csv")

######################################################
##### FUN1 DIFFERENTIAL ABUNDANCE: PATH ROOT PLOT ####
######################################################

# subset and filter output data
op.p.root.dght <- output.p.root %>%
  filter(contrast == "DG_HT") %>%
  filter(padj < 0.05) 

op.p.root.hcht <- output.p.root %>%
  filter(contrast == "HC_HT") %>%
  filter(padj < 0.05) 

# subset taxa DGHT
taxa.dght <- taxa %>%
  t(.) %>%
  as.data.frame() %>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.p.root.dght, by = "Taxon")

rownames(taxa.dght) <- taxa.dght$Taxon
taxa.dght <- taxa.dght %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# subset taxa HCHT
taxa.hcht <- taxa %>%
  t(.) %>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.p.root.hcht, by = "Taxon")

rownames(taxa.hcht) <- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# plot DGHT
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species == "DG"&means$Seedling_Species == "DG") 
                                 | (means$Adult_Species == "DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT"&means$Seedling_Species == "DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_DGHT_Proot", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.dght, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

# plot HT-HC
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

for(i in colnames(taxa.hcht)) {                                                             
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hthc <- means %>% filter((means$Adult_Species =="HC" & means$Seedling_Species == "HC") 
                                 | (means$Adult_Species =="HC" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HC")) %>%
    mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_HTHC_Proot", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.hthc, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.hthc[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}
  
#################################################
#### FUN1 DIFFERENTIAL ABUNDANCE: NPATH SOIL ####
#################################################

tax.n.soil <- t(as(otu_table(ps1FUN.n_soil), 'matrix'))
colsum <- colSums(tax.n.soil!= 0) 
tax.n.soil <- rbind(tax.n.soil,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.n.soil <- tax.n.soil[!(row.names(tax.n.soil) %in% row.names.remove), ] 

smd1.n.soil <- as(sample_data(ps1FUN.n_soil), 'data.frame') 
smd1.n.soil  <- smd1.n.soil[rownames(smd1.n.soil) %in% rownames(tax.n.soil), ]

taxa <- tax.n.soil
smd <- smd1.n.soil

# loop glm over 
output.n.soil <- data.frame() 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_Tag), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.n.soil<- rbind(output.n.soil,results) 
}

## add taxa names
names <- rep(colnames(taxa), each = 11)
output.n.soil$Taxon <- names

# adjust p for multiple comparisons
output.n.soil$padj <- p.adjust2(output.n.soil$p.value, method = "BH", n= length(unique(output.n.soil$Taxon)))

# write csv
write.csv(output.n.soil, file = "data/DiffAbundanceNsoil.csv") 
output.n.soil <- read.csv("data/DiffAbundanceNsoil.csv") 

######################################################
#### FUN1 DIFFERENTIAL ABUNDANCE: NPATH SOIL PLOT ####
######################################################

# subset and filter output data
op.n.soil.dght <- output.n.soil %>%
  filter(contrast == "DG_HT") %>%
  filter(padj < 0.05) %>%
  filter(Taxon != "98683a9bb792d2bfa8140bda8f50eeda" & Taxon != "cacf4ff779b0d6397efd5145990a4fdb" & Taxon != "a6edf52767504fabc181ee136d35273d" & Taxon != "14ac98ba45ecc82e95eb50d5f78845bb" &
         Taxon != "5875bd38d9d5ef23f444d50893a81660" & Taxon != "97106987d9db973ece1e37d2cb59294f" & Taxon != "f162b182aab45b78a358a22a0213210d" & Taxon != "2dd3cc59c5cb5489c4afb15b263631be" &
         Taxon != "fdd6cd827cfad830a0cad85e8d459c44" & Taxon != "856a560c5e0f633904ecdfe04cc7476d" & Taxon != "51d3474cbb0c9d86ccbdfeae05d683e5" & Taxon != "185d31eeffb270573d5cc0663d01707e" &
         Taxon != "107329701c0560216d5b3d51c6e8ec8a" & Taxon != "64534f2a2228a8f9ff305fb8a7f62c87" & Taxon != "86fc044e1d76bfd39d44f1faab9f3fce" & Taxon != "2df258373253e8307b8816ad1977cbf2" &
         Taxon != "1840d200e5b18e20e8c480e98b296a22" & Taxon != "f1e8eee0980950ffc5bf3ec23b198827" & Taxon != "3b5322381246054e1c6b8bb7bab857d9" & Taxon != "c9c54bf79c4ed681543fb0302604e69c" &
         Taxon != "9122097133b5ca2ef2bddb6e3f023395" & Taxon != "dfddf8d3eb48fe9f1a0a2d85e81dfb4e" & Taxon != "8a5a4197b9e87b591ecaee21a43adf8e" & Taxon != "d7b39597e050b643cc240ad3ac4ecc65" &
         Taxon != "2a245f2f39ea904508227470807f60df" & Taxon != "9dd33cc10930a9ac9335b22d645cb289" & Taxon != "b9440034df7e95350b680bdfd6a2ecd4" & Taxon != "a27f807eb5e1003e6cb053898af8a2ad" &
         Taxon != "87d60e53e61ca8f29d09983c3e2180e6" & Taxon != "662c843ec41b7625f963de5b4f034b52" & Taxon != "003da23a222184c005636e2baca86107" & Taxon != "932e1e0b5eeec0f7dc2a98e7482046e7" &
         Taxon != "4f7b68214c49e4d068ab3b460dd9c6f5" & Taxon != "4f0376b7c4de9ed2eceb4d1de6692450" & Taxon != "0f768aa81104d601f94dfe19da97dcd4" & Taxon != "8c9dbbb65761f7749a76bd635da86836" &
         Taxon != "d83b2443b228df12c2af3c15ad331a5a" & Taxon != "e74a7303d00f24e55cfbecfd19a1aa79" & Taxon != "8212bc40c1ae06c6dbad910cbd4c3161" & Taxon != "2ba07b7c1c027c4d201862e0bde75ecd" &
         Taxon != "169036304f7dd12b9798424f655ca8e0" & Taxon != "7ec29f6fa1363a21c1af226b79e167a3" & Taxon != "f88c6e3cfd3ceac5f9d11ebcb182a231" & Taxon != "8cbe340abaf883b19a772b3ef95a5417" &
         Taxon != "bf33b416fcde98336911c946f9f5e845")
           
op.n.soil.hcht <- output.n.soil %>%
  filter(contrast == "HC_HT") %>%
  filter(padj < 0.05) %>%
  filter(Taxon != "66bb708a895108277275dc0c4d2ce050" & Taxon != "98683a9bb792d2bfa8140bda8f50eeda" & Taxon != "cacf4ff779b0d6397efd5145990a4fdb" & Taxon != "c437ba5d8af3ad6e34fe30a716f411dd" &
         Taxon != "9b1c028a199962fdcd733d68d534ad83" & Taxon != "a6edf52767504fabc181ee136d35273d" & Taxon != "14ac98ba45ecc82e95eb50d5f78845bb" & Taxon != "c625bbb07e1ec612707430e8cbb6dd6a" &
         Taxon != "97106987d9db973ece1e37d2cb59294f" & Taxon != "8023562da20e965a1201a2a5a4b1e344" & Taxon != "2dd3cc59c5cb5489c4afb15b263631be" & Taxon != "612b2d96211a577543e809e1d970310e" &
         Taxon != "8ffbc086d5e746acc3e5d1213b77692b" & Taxon != "185d31eeffb270573d5cc0663d01707e" & Taxon != "64534f2a2228a8f9ff305fb8a7f62c87" & Taxon != "86fc044e1d76bfd39d44f1faab9f3fce" &
         Taxon != "2df258373253e8307b8816ad1977cbf2" & Taxon != "1840d200e5b18e20e8c480e98b296a22" & Taxon != "f1e8eee0980950ffc5bf3ec23b198827" & Taxon != "3b5322381246054e1c6b8bb7bab857d9" &
         Taxon != "c9c54bf79c4ed681543fb0302604e69c" & Taxon != "68f3b4f77c1b147a08161130f6af508b" & Taxon != "9122097133b5ca2ef2bddb6e3f023395" & Taxon != "88113e8358694e6f6c9b8b1370167531" &
         Taxon != "d51cd3a882719093a2876741d51ee976" & Taxon != "dfddf8d3eb48fe9f1a0a2d85e81dfb4e" & Taxon != "8a5a4197b9e87b591ecaee21a43adf8e" & Taxon != "2a245f2f39ea904508227470807f60df" &
         Taxon != "9dd33cc10930a9ac9335b22d645cb289" & Taxon != "0b3bc68994fecd03e51c2d251f237a78" & Taxon != "d4abededf1d30b4d87ea40e46241a390" & Taxon != "d78027af66577b114d905753aa1327f6" & 
         Taxon != "003da23a222184c005636e2baca86107" & Taxon != "932e1e0b5eeec0f7dc2a98e7482046e7" & Taxon != "50d7b20f071b94d778f8421558737aac" & Taxon != "8ccd9212dbb384b65113ed12aff8bafc" &
         Taxon != "8d7bcfe8b35c1e0286abcf72de917ba6" & Taxon != "4f0376b7c4de9ed2eceb4d1de6692450" & Taxon != "0f768aa81104d601f94dfe19da97dcd4" & Taxon != "8c9dbbb65761f7749a76bd635da86836" &
         Taxon != "6f78bafda5e27d778e4e9dfe8fb81a37" & Taxon != "d83b2443b228df12c2af3c15ad331a5a" & Taxon != "48b6326cfc31f69a3514ab60c47e1e9d" & Taxon != "e74a7303d00f24e55cfbecfd19a1aa79" &
         Taxon != "2ba07b7c1c027c4d201862e0bde75ecd" & Taxon != "169036304f7dd12b9798424f655ca8e0" & Taxon != "7ec29f6fa1363a21c1af226b79e167a3" & Taxon != "083e8b7013db180e52493f26289f4503" &
         Taxon != "f88c6e3cfd3ceac5f9d11ebcb182a231" & Taxon != "c3e7668189223e121cd18056887f5022" & Taxon != "0deb20c2e0edb738c40c675ad499b7cf")

# subset taxa DGHT
taxa.dght <- taxa %>%
  t(.) %>%
  as.data.frame() %>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.soil.dght, by = "Taxon")

rownames(taxa.dght) <- taxa.dght$Taxon
taxa.dght <- taxa.dght %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# subset taxa HCHT
taxa.hcht <- taxa %>%
  t(.) %>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.soil.hcht, by = "Taxon")

rownames(taxa.hcht) <- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# plot DGHT
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species == "DG"&means$Seedling_Species == "DG") 
                                 | (means$Adult_Species == "DG"& means$Seedling_Species == "HT") 
                                 | (means$Adult_Species == "HT" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species == "HT"&means$Seedling_Species == "DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_DGHT_NPSoil", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.dght, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position = position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face = "bold"),
            plot.title = element_text(face = "bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face ="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face = "italic"))
  })
  dev.off()
}

# plot HT-HC
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

for(i in colnames(taxa.hcht)) {                                                             
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hthc <- means %>% filter((means$Adult_Species =="HC" & means$Seedling_Species == "HC") 
                                 | (means$Adult_Species =="HC" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HC")) %>%
    mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_HTHC_NPsoil", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.hthc, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.hthc[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

#################################################
#### FUN1 DIFFERENTIAL ABUNDANCE: NPATH ROOT ####
#################################################

tax.n.root <- t(as(otu_table(ps1FUN.n_root),'matrix')) 
colsum <- colSums(tax.n.root!= 0) 
tax.n.root <- rbind(tax.n.root,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>%
  as.matrix()
row.names.remove <- c("colsum")
tax.n.root<-tax.n.root[!(row.names(tax.n.root) %in% row.names.remove), ] 

smd1.n.root <- as(sample_data(ps1FUN.n_root), 'data.frame') 
smd1.n.root  <- smd1.n.root[rownames(smd1.n.root) %in% rownames(tax.n.root), ] 

taxa <- tax.n.root
smd <- smd1.n.root

# loop glm over 
output.n.root<-data.frame() 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_Tag:InOut), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.n.root<- rbind(output.n.root,results) 
}

## add taxa names
names <- rep(colnames(taxa), each = 11)
output.n.root$Taxon <- names

## adjust p for multiple comparisons
output.n.root$padj <- p.adjust2(output.n.root$p.value, method = "BH", n = length(unique(output.n.root$Taxon)))

# write .csv
write.csv(output.n.root, file = "data/DiffAbundanceNroot.csv") 
output.n.root <- read.csv("data/DiffAbundanceNroot.csv") 

######################################################
#### FUN1 DIFFERENTIAL ABUNDANCE: NPATH ROOT PLOT ####
######################################################

# subset and filter output data
op.n.root.dght <- output.n.root %>%
  filter(contrast == "DG_HT") %>%
  filter(padj < 0.05) %>%
  filter(Taxon != "a91e08e2e09046e48fca648ba375697" & Taxon != "0a91e08e2e09046e48fca648ba375697" & Taxon != "b48b1ab356793160fef5ca9bf80af15a" & Taxon != "3397d01a20811eb960a5055467b9212b") 

op.n.root.hcht <- output.n.root %>%
  filter(contrast == "HC_HT") %>%
  filter(padj < 0.05) 

# subset taxa DGHT
taxa.dght <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.root.dght, by = "Taxon")

rownames(taxa.dght) <- taxa.dght$Taxon
taxa.dght <- taxa.dght %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# subset taxa HCHT
taxa.hcht <- taxa %>%
  t(.) %>%
  as.data.frame() %>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.root.hcht, by = "Taxon")

rownames(taxa.hcht) <- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht %>%
  dplyr::select(-c(Taxon)) %>%
  t(.)

# plot DGHT
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species == "DG"&means$Seedling_Species == "DG") 
                                 | (means$Adult_Species == "DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species == "HT"&means$Seedling_Species == "DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_DGHT_NProot", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.dght, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

# plot HT-HC
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

for(i in colnames(taxa.hcht)) {                                                             
  print(i)                                                                              
  model <- lmer(taxa[,i] ~ Seedling_Species*Adult_Species + (1|Adult_Tag:Seedling_Species), data = smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hthc <- means %>% filter((means$Adult_Species =="HC" & means$Seedling_Species == "HC") 
                                 | (means$Adult_Species =="HC" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species == "HC")) %>%
    mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_HTHC_NProot", i, sep = "") 
  filepath = paste(filename, ".png", sep = "") 
  png(filepath, width=10, height= 10, units = 'in', res = 300)
  print({ggplot(means.hthc, aes(NewSS, emmean, color = NewSS)) +
      geom_rect(data=means.hthc[2:3,], aes(color= NA, fill = NewAS, alpha = 0.1), xmin = -Inf, xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position = position_dodge(1), size = 10) + 
      geom_errorbar(aes(ymin = emmean - SE, ymax = emmean + SE), width = 0.5, size = 2, position=position_dodge(1))+
      labs(title = i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale + fillScale +
      facet_grid(~NewAS) +
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}
