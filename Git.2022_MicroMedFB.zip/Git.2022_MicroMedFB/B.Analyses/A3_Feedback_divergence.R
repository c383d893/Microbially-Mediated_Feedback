## EXCLOSURE LEVEL (soil)
## For each species pair,
## separate individual tests of feedback (home x 2 away x 2)
## get feedback coefficient
## get microbial divergence in exclosures
## need to repeat for different microbial groups

## biomass diff = ln(finalbiomass)- ln(initialbiomass) = ln(finalbiomass/initialbiomass)
## biomass = ln(biomass)
## use diff2 = negative differences removed

#### PACKAGES ####
# for all analyses 
library(tidyverse)
library(ggplot2)
library(lsmeans)
library(dplyr)
library(lubridate)
library(lmerTest)
library(gridExtra)
library(lme4)
library(gdata)
library(ggeffects)
library(vegan)
library(phyloseq)

###############################
######### READ IN DATA ########
###############################

#july 15
#yday("2019-7-15") #196
#august 15
#yday("2019-8-15") # 227
#sept 15
#yday("2019-8-15") # 258

dat.bioheight <- read.csv("data/BiomassHeightOneRow07.06.22.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() %>%
  rename(Adult_tag = AdultTag) %>%
  mutate(Adult_tag = as.character(Adult_tag),Seedling_Species=as.character(Seedling_Species)) %>%
  dplyr::select(c("Exclosure_Tag","Adult_tag","Adult_Species","Seedling_Species","Height.diff2","BMTotal.diff2", "BMAbove.diff2", "BMBelow.diff2")) %>%
  drop_na()
  
blup.bio<-readRDS("data/blupestimatedbiomas_June10.22.rds") %>%
  mutate(Adult_tag=as.character(Adult_tag),Seedling_Species=as.character(Seedling_Species))

blup.filt <- dat.bioheight %>%
 full_join(blup.bio,by=c("Exclosure_Tag","Adult_tag","Seedling_Species")) %>%
 distinct(Exclosure_Tag, .keep_all=TRUE) %>%
 dplyr::select(c("Exclosure_Tag","Adult_tag","Adult_Species","Seedling_Species","mean_totalbiomass","mean_abovebiomass","mean_belowbiomass")) %>%
 drop_na()

surv <- readRDS('data/survivaldatarepeat.rds')
#On October 1, what was alive? What was still alive that day or after?
#For each observation, was it alive at that point?
surv.A <- surv %>% filter(Survival==1 & mdoy >=258) %>% distinct(Seedling_ID,.keep_all=TRUE)
#On October 1, what was dead? What was dead by that time?
# When things die, this only happens once. did things die before that day?
surv.D <- surv %>% filter(Survival==0 & mdoy <258)

surv.filt <- rbind(surv.A, surv.D) %>%
  group_by(Exclosure_Tag,Survival) %>%
  summarize(N = n()) %>%
  mutate(prop= N / sum(N)) %>%
  filter(Survival==1) %>%
  rename(propsurv=prop) %>%
  left_join(surv, by="Exclosure_Tag") %>%
  dplyr::select(c('Exclosure_Tag','propsurv','AdultTag','Adult_Species','Seedling_Species')) %>%
  dplyr::rename(Adult_tag=AdultTag) %>%
  distinct(Exclosure_Tag,.keep_all=TRUE)%>%
  drop_na()

###############################
##### PAIRWISE FEEDBACK #######
###############################

##!!!!! choose one below

#choose one
dat.filt <- dat.bioheight  # height & biomass
dat.filt <- blup.filt      # blup extracted biomass
dat.filt <- surv.filt      # survival

#lg biomass difference: aka what is the average/total growth in the exclosure

#measured values 
#BMTotal.diff2
#BMAbove.diff2
#BMBelow.diff2
#Height.diff2

#blup values (blup.filt)
#mean_totalbiomass
#mean_abovebiomass
#mean_belowbiomass

#measured survival (surv.filt)
#propsurv

sp.comb <- c("DG_HC","DG_HT", "DG_SA","HC_HT","HC_SA", "SA_HT","HC_DG","HT_DG", "SA_DG","HT_HC","SA_HC", "SA_HT")
  
feedback.out <- data.frame()
# for sp combinations
for(P in sp.comb){ 
  # get A and B
  A <- substr(P, start = 1, stop = 2)
  B <- substr(P, start = 4, stop = 5)
  #subset data to pairs
    pair.dat <- dat.filt %>% filter(Adult_Species == A & Seedling_Species ==A |Adult_Species ==B & Seedling_Species ==A| Adult_Species == A & Seedling_Species ==B |Adult_Species ==B & Seedling_Species ==B) %>%
      mutate(type = case_when(Adult_Species == A & Seedling_Species ==A  ~ "Aa",  
                              Adult_Species ==B & Seedling_Species ==B ~ "Bb",
                              Adult_Species == A & Seedling_Species ==B ~ "Ab",
                              Adult_Species ==B & Seedling_Species ==A ~ "Ba")) 
    #given A adult tag, choose B adult tag
    Adult_tagA <- pair.dat %>% filter(Adult_Species == A) %>% dplyr::select(Adult_tag) %>% distinct() %>% t() %>% as.vector()
    Adult_tagB <- pair.dat %>% filter(Adult_Species == B) %>% dplyr::select(Adult_tag) %>% distinct() %>% t() %>% as.vector()
    rep.dat.out <- data.frame()
     for(AT in Adult_tagA){
      rep.datA <- pair.dat %>% filter(Adult_tag==AT)
      for(BT in Adult_tagB){
        rep.datB <- pair.dat %>% filter(Adult_tag==BT)
        rep.dat <- rbind(rep.datA, rep.datB) 
        rep.dat.bio <- rep.dat %>%
          group_by(type) %>%
          #!!change metric here
          #!!change mean or sum
          summarize(metric = sum(mean_belowbiomass))
        Aa <- rep.dat.bio %>% filter(type=="Aa") %>% dplyr::select(metric)
        Bb <- rep.dat.bio %>% filter(type=="Bb") %>% dplyr::select(metric)
        Ab <- rep.dat.bio %>% filter(type=="Ab") %>% dplyr::select(metric)
        Ba <- rep.dat.bio %>% filter(type=="Ba") %>% dplyr::select(metric)
        if (nrow(Ab)==0 | nrow(Bb)==0 |nrow(Aa) == 0 |nrow(Ba)==0){
          print ("incomplete pair")
        }else{
        fb.coef <-  Aa - Ba - Ab + Bb
        out.dat <- cbind(A,B,AT,BT,fb.coef)
        rep.dat.out <- rbind(rep.dat.out, out.dat)
        }
      }
     }
    feedback.out <- rbind(feedback.out,rep.dat.out)
  }

feedback.out <- feedback.out %>% mutate(ATBT= paste(AT,BT,sep="_")) %>%
  distinct(ATBT,.keep_all=TRUE) %>%
  rename(feedback = metric)

###############################
##### MICROBIAL DIVERGENCE ####
###############################

#Choose one
dat.NP <- read.csv("data/PlantMicrobiomeSoilNonpathsASV.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() 

dat.P <- read.csv("data/PlantMicrobiomeSoilPathsASV.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() 

dat.A <- read.csv("data/PlantMicrobiomeAMFASV.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() 

#NP
dat.asv <- dat.NP %>% 
  dplyr::select(-c("Exclosure_Tag","doy.diff.avg","BMT.diff.avg","BMA.diff.avg","BMB.diff.avg",
            "Sample_Name","Seedling_Species","Adult_Species","Group","Sample_Type","Timepoint","Conhetero")) %>% 
  group_by(AdultTag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('AdultTag')

#PATH
dat.asv <- dat.P %>% 
  dplyr::select(-c("Exclosure_Tag","Adult_tag","doy.diff","BMTotal.diff2","BMAbove.diff2","BMBelow.diff2",
            "Sample_Name","Seedling_Species","Adult_Species","Group","Date_collected","Sample_Type","Timepoint","Conhetero","Seedling_ID")) %>% 
  group_by(AdultTag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('AdultTag')

#AMF
dat.asv <- dat.A %>% 
  dplyr::select(-c("Exclosure_Tag","doy.diff.avg","BMT.diff.avg","BMA.diff.avg","BMB.diff.avg",
            "Sample_Name","Seedling_Species","Adult_Species","Group","Sample_Type","Timepoint","Conhetero")) %>% 
  group_by(AdultTag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('AdultTag')

asv = otu_table(as.matrix(dat.asv), taxa_are_rows = FALSE)              
ps <- phyloseq(asv) 

# purge out zero sum OTUS, but also remove rare OTUs (10 reads)
ps <- prune_taxa(taxa_sums(ps)>10,ps) 

# rarify to even depth to compare between samples
set.seed(609) 
sample_sums(ps)

ps.rare <- rarefy_even_depth(ps,sample.size = min(sample_sums(ps)))

# save new meta and asv table
asv.rare <-t(as(otu_table(ps.rare),'matrix')) 

bray_dist <- as.matrix(distance(ps.rare, method = "bray", type = "samples"))  %>% unmatrix() %>% as.data.frame()
colnames(bray_dist) <- c("bray")

bray_dist.df <- bray_dist %>% rownames_to_column("AdultTagC") %>%
  separate(AdultTagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag,Btag,sep="_")) %>%
  dplyr::select(-c("Atag","Btag")) %>%
  filter(!bray==0) %>% 
  distinct(ATBT,.keep_all=TRUE)
  
###############################
#### JOIN BOTH AND REGRESS ####
###############################

dat.reg <- feedback.out %>%
  full_join(bray_dist.df, by ="ATBT") %>%
  mutate(AB = map2_chr(A, B, ~toString(sort(c(.x, .y))))) %>%
  drop_na() 

m1<- lm(feedback ~ bray, data=dat.reg)
#m1<- lmer(feedback ~ bray +(1|AB), data=dat.reg)
summary(m1)
anova(m1)

#check model
par(mfrow = c(2, 2))
plot(m1)

m1.plot <- ggeffect(m1, terms = c("bray"), type= "re")
plot(m1.plot,raw=TRUE)

############################
####### mean value #########
############################

#output BMTotal.diff2
#NP: 0.2808     0.1411   1.990   0.0541 .
#P:  0.10712    0.10898   0.983    0.336
#AMF: 0.002648   0.031318   0.085    0.933

#output BMAbove.diff2
#NP: 0.2332     0.1220   1.911   0.0637 .
#P:  0.07232    0.09422   0.768    0.451
#AMF: 0.007758   0.026940   0.288    0.775

#output BMBelow.diff2
#NP: 0.04358    0.02279   1.912   0.0636 .
#P: 0.03282    0.01523   2.155   0.0419 *
#AMF: -0.004811   0.004977  -0.967    0.340

#output Height.diff2
#NP: 24.767      8.283   2.990  0.00494 **
#P: 11.018      7.469   1.475    0.154
#AMF: 1.0534     1.9392   0.543    0.590

#blup total biomass:
#NP: 0.19190    0.06526   2.940  0.00562 **
#P: 0.13307    0.05224   2.548   0.0180 *
#AMF:  -0.009976   0.015203  -0.656    0.516

#blup above biomass:
#NP: 0.15537    0.05078   3.060  0.00411 **
#P: 0.09825    0.04162   2.360   0.0271 *
#AMF: -0.0067929  0.0119387  -0.569    0.573

#blup below biomass:
#NP: 0.02704    0.01524   1.775   0.0842 .
#P: 0.032545   0.009592   3.393  0.00250 **
#AMF: -0.0035736  0.0032960  -1.084    0.285

#survival:
#NP: 1.0271     0.5769   1.780   0.1003
#P: 0.063392 0.063392  15.552 0.004274 **
#AMF: 0.3451     0.4953   0.697    0.499

############################
######## sum value #########
############################

#output BMTotal.diff2
#NP: -0.2772     1.6535  -0.168    0.868
#P: 1.2889     0.9467   1.362    0.187
#AMF: -0.1692     0.3478  -0.487  0.62944  

#output BMAbove.diff2
#NP: -0.2413     1.3179  -0.183    0.856
#P:  0.9992     0.7641   1.308    0.204
#AMF: -0.1310     0.2773  -0.472  0.63949 

#output BMBelow.diff2
#NP: -0.03292    0.30878  -0.107    0.916
#P: 0.2710     0.1678   1.615    0.120
#AMF: -0.03576    0.06488  -0.551  0.58479

#output Height.diff2:
#NP: -69.50     117.36  -0.592    0.557
#P: 70.40      64.67   1.089    0.288
#AMF: 4.871     24.860   0.196   0.8457 

#blup total biomass:
#NP: 0.19190    0.06526   2.940  0.00562 **
#P: 0.13307    0.05224   2.548   0.0180 *
#AMF: -0.009976   0.015203  -0.656    0.516

#blup above biomass:
#NP: 0.15537    0.05078   3.060  0.00411 **
#P: 0.09825    0.04162   2.360   0.0271 *
#AMF: -0.0067929  0.0119387  -0.569    0.573

#blup below biomass:
#NP: 0.02704    0.01524   1.775   0.0842 .
#P: 0.032545   0.009592   3.393  0.00250 **
#AMF: -0.0035736  0.0032960  -1.084    0.285

#survival
#NP: -0.4455     2.1166  -0.210    0.837
#P: -2.8223     0.8676  -3.253   0.0117 *
#AMF: 1.0998     1.6209   0.679    0.510

#### Visualisation ####

new.dat <- with(dat.reg, expand.grid(bray = seq(min(bray), max(bray), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray=new.dat$bray)

TB <-
ggplot(data = pred,aes(x = bray, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (non-pathogen)") +
  ylab("Feedback (total biomass)")+
  theme_bw()+
  theme(text = element_text(size = 15, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        plot.title = element_text(face="bold",hjust = 0.5),
        axis.text.x=element_text(size = 10, face="italic"),
        axis.text.y=element_text(size = 10),
        legend.position = "none",
        strip.text.x = element_text(face="italic"))#+
  #theme(legend.position = "bottom")+
  #guides(color=guide_legend(" "))


new.dat <- with(dat.reg, expand.grid(bray = seq(min(bray), max(bray), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray=new.dat$bray)

SUR <- 
  ggplot(data = pred,aes(x = bray, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (pathogen)") +
  ylab("Feedback (survival)")+
  theme_bw()+
  theme(text = element_text(size = 15, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        plot.title = element_text(face="bold",hjust = 0.5),
        axis.text.x=element_text(size = 10, face="italic"),
        axis.text.y=element_text(size = 10),
        legend.position = "none",
        strip.text.x = element_text(face="italic"))#+
  #theme(legend.position = "bottom")+
  #guides(fill=guide_legend(" "))

png("Figures/Figure5_27.6.22.jpg", width=12, height= 6, units='in', res=300)
grid.arrange(TB,SUR, ncol=2)
dev.off()
