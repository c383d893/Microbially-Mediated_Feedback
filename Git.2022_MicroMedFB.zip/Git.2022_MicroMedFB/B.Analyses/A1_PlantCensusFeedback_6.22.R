#### Clean script ####
# Contents:
# Biomass analyses
# Survival analyses

#### PACKAGES ####
# for all analyses 
library(tidyverse)
library(ggplot2)
library(lsmeans)
library(dplyr)
library(lubridate)
library(lmerTest)
library(pbkrtest)
library(gridExtra)

#### Pairwise feedback analyses: BIOMASS ####
####. Load data ####
# Biomass measurements
bm <- read.csv2("data/AllometricEquations.csv") %>%
  rename(Seedling = X.....Seedling, NumberLeaves = X..Leaves) 
bm <- bm %>%
  mutate(Height2 = as.numeric(bm$Height))%>%
  mutate(DryWeightRoot = as.numeric(bm$Dry.Weight.Roots))%>%
  mutate(DryWeightLeaves = as.numeric(bm$Dry.Weight.Leaves))%>%
  mutate(DryWeightStem = as.numeric(bm$Dry.Weight.Steam))%>%
  dplyr::select(-c(Dry.Weight.Roots, Dry.Weight.Steam, Dry.Weight.Leaves, Height))%>%
  mutate(TotalBM = DryWeightRoot + DryWeightStem + DryWeightLeaves)%>%
  mutate(Above = DryWeightStem + DryWeightLeaves)%>%
  rename(Height = Height2) %>%
  mutate(Sp = substr(Seedling, 1,6))%>%
  mutate(Seedling_Species = ifelse(Sp =="HEISCO", "HC", ifelse(Sp == "DIALGU", "DG", ifelse(Sp =="HIRTTR", "HT", "SA"))))
bm.dg <- bm %>%
  subset(., Seedling_Species=="DG")
bm.ht <- bm %>%
  subset(., Seedling_Species=="HT")
bm.hc <- bm %>%
  subset(., Seedling_Species=="HC")
bm.sa <- bm %>%
  subset(., Seedling_Species=="SA")

# Seedling census data
pdat<- read.csv("data/Seedling_census_data_curated_12_20_21.csv",header=TRUE,sep=",") %>%  
  dplyr::select(c(Date,Seedling_ID,Seedling_Num,Height,Num_Leaves,AdultTag,Date_collected,Adult_Species,Seedling_Species))  %>% 
  rename(NumberLeaves = Num_Leaves)%>%
  mutate(mYear = substr(Date, 1,4)) %>% 
  mutate(mMonth = substr(Date, 5,6)) %>%
  mutate(mDay =substr(Date, 7,8)) %>%
  mutate(mnewDate= paste(mYear, mMonth, mDay, sep="-")) %>% 
  mutate(mdoy = yday(mnewDate)) %>%
  mutate(mdoy = ifelse(mYear==2020, mdoy+365, mdoy)) %>% # add 365 days for observations in 2020, because 01-01-2019 is day 1
  mutate(cYear = ifelse(Date_collected != 0, substr(Date_collected, 1,4), NA)) %>% 
  mutate(cMonth = ifelse(Date_collected != 0, substr(Date_collected, 5,6), NA)) %>%
  mutate(cDay = ifelse(Date_collected != 0, substr(Date_collected, 7,8), NA)) %>%
  mutate(cnewDate= ifelse(Date_collected != 0, paste(cYear, cMonth, cDay, sep="-"), NA)) %>% 
  mutate(cdoy = yday(cnewDate)) %>% 
  mutate(cdoy = ifelse(cYear==2020, cdoy+365, cdoy)) %>% 
  mutate(Conhetero = ifelse(Adult_Species==Seedling_Species, "Con", "Hetero")) 
pdat <- pdat %>%
  drop_na(., Height)
pdat.nzh <- pdat %>%
  subset(., Height != 0)
pdat.dg <- pdat.nzh %>%
  subset(., Seedling_Species =="DG")
pdat.ht <- pdat.nzh %>%
  subset(., Seedling_Species =="HT")
pdat.hc <- pdat.nzh %>%
  subset(., Seedling_Species =="HC")
pdat.sa <- pdat.nzh  %>%
  subset(., Seedling_Species =="SA")

####. Species-wise biomass modelling ####
# DG
lm.dg.total <- lm(log(TotalBM) ~ Height + NumberLeaves, data = bm.dg)
summary(lm.dg.total) 
lm.dg.ab <- lm(log(Above) ~ Height + NumberLeaves, data = bm.dg)
summary(lm.dg.ab) 
lm.dg.bel <- lm(log(DryWeightRoot) ~ Height + NumberLeaves, data = bm.dg)
summary(lm.dg.bel) 

par(mfrow = c(2, 2))
plot(lm.dg.total)
plot(lm.dg.ab)
plot(lm.dg.bel)

# HT
lm.ht.total <- lm(log(TotalBM) ~ Height + NumberLeaves, data = bm.ht)
summary(lm.ht.total) 
lm.ht.ab <- lm(log(Above) ~ Height + NumberLeaves, data = bm.ht)
summary(lm.ht.ab) 
lm.ht.bel <- lm(log(DryWeightRoot) ~ Height + NumberLeaves, data = bm.ht)
summary(lm.ht.bel) 

plot(lm.ht.total) 
plot(lm.ht.ab)
plot(lm.ht.bel)

# HC
lm.hc.total <- lm(log(TotalBM) ~ Height + NumberLeaves, data = bm.hc)
summary(lm.hc.total)
lm.hc.ab <- lm(log(Above) ~ Height + NumberLeaves, data = bm.hc)
summary(lm.hc.ab)
lm.hc.bel <- lm(log(DryWeightRoot) ~ Height + NumberLeaves, data = bm.hc)
summary(lm.hc.bel)

plot(lm.hc.total) 
plot(lm.hc.ab)
plot(lm.hc.bel)

# SA
lm.sa.total <- lm(log(TotalBM) ~ Height + NumberLeaves, data = bm.sa)
summary(lm.sa.total) 
lm.sa.ab <- lm(log(Above) ~ Height + NumberLeaves, data = bm.sa)
summary(lm.sa.ab) 
lm.sa.bel <- lm(log(DryWeightRoot) ~ Height + NumberLeaves, data = bm.sa)
summary(lm.sa.bel)

plot(lm.sa.total)
plot(lm.sa.ab)
plot(lm.sa.bel)

####. species-wise biomass predictions####
# DG
par(mfrow = c(1,1))
pred.dg.total <- predict.glm(lm.dg.total, type ="response", newdata = pdat.dg)%>%
  exp(.)
hist(pred.dg.total)
pred.dg.ab <- predict.glm(lm.dg.ab, type = "response", newdata = pdat.dg)%>%
  exp(.)
hist(pred.dg.ab)
pred.dg.bel <- predict.glm(lm.dg.bel, type = "response", newdata = pdat.dg)%>%
  exp(.)
hist(pred.dg.bel)

# HT
pred.ht.total <- predict.glm(lm.ht.total, type ="response", newdata = pdat.ht)%>%
  exp(.)
hist(pred.ht.total)
pred.ht.ab <- predict.glm(lm.ht.ab, type = "response", newdata = pdat.ht)%>%
  exp(.)
hist(pred.ht.ab)
pred.ht.bel <- predict.glm(lm.ht.bel, type = "response", newdata = pdat.ht)%>%
  exp(.)
hist(pred.ht.bel)

# HC
pred.hc.total <- predict.glm(lm.hc.total, type ="response", newdata = pdat.hc)%>%
  exp(.)
hist(pred.hc.total)
pred.hc.ab <- predict.glm(lm.hc.ab, type = "response", newdata = pdat.hc)%>%
  exp(.)
hist(pred.hc.ab)
pred.hc.bel <- predict.glm(lm.hc.bel, type = "response", newdata = pdat.hc)%>%
  exp(.)
hist(pred.hc.bel)

# SA
pred.sa.total <- predict.glm(lm.sa.total, type ="response", newdata = pdat.sa)%>%
  exp(.)
hist(pred.sa.total)
pred.sa.ab <- predict.glm(lm.sa.ab, type = "response", newdata = pdat.sa)%>%
  exp(.)
hist(pred.sa.ab)
pred.sa.bel <- predict.glm(lm.sa.bel, type = "response", newdata = pdat.sa)%>%
  exp(.)
hist(pred.sa.bel)

#### add predictions to pdat ####
pdat.dg$TotalBM <- pred.dg.total
pdat.dg$AboveBM <- pred.dg.ab
pdat.dg$BelowBM <- pred.dg.bel

pdat.ht$TotalBM <- pred.ht.total
pdat.ht$AboveBM <- pred.ht.ab
pdat.ht$BelowBM <- pred.ht.bel

pdat.hc$TotalBM <- pred.hc.total
pdat.hc$AboveBM <- pred.hc.ab
pdat.hc$BelowBM <- pred.hc.bel

pdat.sa$TotalBM <- pred.sa.total
pdat.sa$AboveBM <- pred.sa.ab
pdat.sa$BelowBM <- pred.sa.bel

# stack pdat seedling species subset
pdatBM <- rbind(pdat.dg, pdat.hc, pdat.ht, pdat.sa)
write.csv(pdatBM, file = "data/SeedlingCensus_Biomass_7.4.22.csv")
pdatBM <- read.csv("data/SeedlingCensus_Biomass_7.4.22.csv")

####. Modelling biomass ####
# total biomass
bm.glm.total<-lmer(TotalBM ~ Seedling_Species*Adult_Species*mdoy +(1|AdultTag:Seedling_Species)+ (1|AdultTag:Seedling_Species:Seedling_ID) , data= pdatBM)
#space v repeated measure
summary(bm.glm.total)
anova(bm.glm.total)

# for BLUP extraction
total_biomass<- ranef(bm.glm.total) %>% as.data.frame() %>% mutate(condval2=exp(condval))
total_biomass<- total_biomass %>% separate('grp', c("Adult_tag","Seedling_Species","Seedling_ID"), sep = ":") %>%
  group_by(Adult_tag,Seedling_Species) %>%
  summarize(mean_totalbiomass = mean(condval)) %>%
  mutate(Exclosure_Tag=paste(Adult_tag,Seedling_Species,sep="_"))

# above-ground biomass
bm.glm.above<-lmer(AboveBM ~ Seedling_Species*Adult_Species*mdoy +(1|AdultTag:Seedling_Species)+ (1|AdultTag:Seedling_Species:Seedling_ID) , data= pdatBM)
summary(bm.glm.above)
anova(bm.glm.above)

# for BLUP extraction
above_biomass<- ranef(bm.glm.above) %>% as.data.frame() %>% mutate(condval2=exp(condval))
above_biomass<-above_biomass %>% separate('grp', c("Adult_tag","Seedling_Species","Seedling_ID"), sep = ":") %>%
  group_by(Adult_tag,Seedling_Species) %>%
  summarize(mean_abovebiomass = mean(condval)) %>%
  mutate(Exclosure_Tag=paste(Adult_tag,Seedling_Species,sep="_"))

# below-ground biomass
bm.glm.below<-lmer(BelowBM ~ Seedling_Species*Adult_Species*mdoy +(1|AdultTag:Seedling_Species)+ (1|AdultTag:Seedling_Species:Seedling_ID) , data= pdatBM)
summary(bm.glm.below)
anova(bm.glm.below)

# for BLUP extraction
pdatBM<- pdatBM %>% mutate(Exclosure_Tag=paste(AdultTag,Seedling_Species, sep="_"))
below_biomass<- ranef(bm.glm.below) %>% as.data.frame() %>% mutate(condval2=exp(condval))
below_biomass<- below_biomass %>% separate('grp', c("Adult_tag","Seedling_Species","Seedling_ID"), sep = ":") %>%
  group_by(Adult_tag,Seedling_Species) %>%
  summarize(mean_belowbiomass = mean(condval)) %>%
  mutate(Exclosure_Tag=paste(Adult_tag,Seedling_Species,sep="_"))

# join BLUP: feedback divergence analysis
blup_bio <- total_biomass %>%
  full_join(above_biomass, by =c('Adult_tag','Seedling_Species','Exclosure_Tag')) %>%
  full_join(below_biomass, by =c('Adult_tag','Seedling_Species','Exclosure_Tag'))
saveRDS(blup_bio,"data/blupestimatedbiomas_June10.22.rds")

####. Contrast analysis ####
contrasts <- list("home vs. away" = c(3,-1,-1,-1,-1,3,-1,-1,-1,-1,3,-1,-1,-1,-1,3),
                  "DG_HC"= c(1,-1,0,0,-1,1,0,0,0,0,0,0,0,0,0,0),
                  "DG_HT"= c(1,0,-1,0,0,0,0,0,-1,0,1,0,0,0,0,0),
                  "DG_SA"= c(1,0,0,-1,0,0,0,0,0,0,0,0,-1,0,0,1),
                  "HC_HT"= c(0,0,0,0,0,1,-1,0,0,-1,1,0,0,0,0,0),
                  "HC_SA"= c(0,0,0,0,0,1,0,-1,0,0,0,0,0,-1,0,1),
                  "HT_SA"= c(0,0,0,0,0,0,0,0,0,0,1,-1,0,0,-1,1),
                  "DG_avg"= c(3,-1,-1,-1,-1,1,0,0,-1,0,1,0,-1,0,0,1),
                  "HC_avg"= c(1,-1,0,0,-1,3,-1,-1,0,-1,1,0,0,-1,0,1),
                  "HT_avg"= c(1,0,-1,0,0,1,-1,0,-1,-1,3,-1,0,0,-1,1),
                  "SA_avg"= c(1,0,0,-1,0,1,0,-1,0,0,1,-1,-1,-1,-1,3))

# total biomass
means.TotalBM <- emmeans(bm.glm.total, ~Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000)
results.TotalBM<-lsmeans::contrast(means.TotalBM,contrasts)
results.Total.df<-as.data.frame(results.TotalBM)
results.Total.df

# above-ground biomass
means.AboveBM <- emmeans(bm.glm.above, ~Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000)
results.AboveBM<-lsmeans::contrast(means.AboveBM,contrasts)
results.Above.df<-as.data.frame(results.AboveBM)
results.Above.df

# below-ground biomass
means.BelowBM <- emmeans(bm.glm.below, ~Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000)
results.BelowBM<-lsmeans::contrast(means.BelowBM,contrasts)
results.Below.df<-as.data.frame(results.BelowBM)
results.Below.df

####. visualisation ####
DG_Blue = rgb(75/255, 94/255, 160/255, 1)
HC_Green = rgb(121/255, 132/255, 27/255, 1)
HT_Yellow = rgb(218/255, 168/255, 17/255, 1)
SA_Purple = rgb(170/255, 142/255, 200/255, 1)

colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow)) # only HC and HT, because only significant contrast
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

#total biomass
refTotal<- lsmeans(bm.glm.total, pairwise~Seedling_Species*Adult_Species, data = pdatBM, pbkrtest.limit =  5000, lmerTest.limit = 5000)
refTotal.table <- as.data.frame(refTotal$lsmeans)

ref.total.hcht <- refTotal.table %>%
  filter((Adult_Species =="HC"&Seedling_Species=="HC") | 
           (Adult_Species=="HC"& Seedling_Species =="HT") | 
           (Adult_Species =="HT" & Seedling_Species =="HT") | 
           (Adult_Species=="HT"&Seedling_Species=="HC"))%>%
  mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
  mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))

png("Figures/BMTotal_hcht_28.4.22_02.jpg", width=6, height= 6, units='in', res=300)
biomass<-ref.total.hcht%>%
  ggplot(., aes(NewSS, lsmean, color=NewSS))+
  geom_rect(data=ref.total.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = 0,ymax = 7.5, alpha =0.25) +
  geom_point(position=position_dodge(1), size=10, show.legend = FALSE)+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5, size=2, position = position_dodge(1))+
  ylab("Total Biomass")+
  xlab("Seedling Species")+
  #ylim(0.075, 0.175)+
  facet_grid(~NewAS)+
  theme_minimal()+
  theme(text = element_text(size = 35, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        plot.title = element_text(face="bold",hjust = 0.5),
        axis.text.x=element_text(size = 30, face="italic"),
        axis.text.y=element_text(size = 30),
        legend.position = "none",
        strip.text.x = element_text(face="italic"))+
  colScale +
  fillScale
dev.off()

#above ground biomass
refAbove<- lsmeans(bm.glm.above, pairwise~Seedling_Species*Adult_Species, data = pdatBM, pbkrtest.limit =  5000, lmerTest.limit = 5000)
refAbove.table <- as.data.frame(refAbove$lsmeans)

ref.above.hcht <- refAbove.table %>%
  filter((Adult_Species =="HC"&Seedling_Species=="HC") | 
           (Adult_Species=="HC"& Seedling_Species =="HT") | 
           (Adult_Species =="HT" & Seedling_Species =="HT") | 
           (Adult_Species=="HT"&Seedling_Species=="HC"))%>%
  mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
  mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))

png("Figures/BMAbove_hcht_28.4.22_02.jpg", width=6, height= 6, units='in', res=300)
ref.above.hcht%>%
  ggplot(., aes(NewSS, lsmean, color=NewSS))+
  geom_rect(data=ref.above.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = 0,ymax = 7.5, alpha =0.25) +
  geom_point(position=position_dodge(1), size=4, show.legend = FALSE)+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5, size=1, position = position_dodge(1))+
  ylab("Above-ground Biomass")+
  xlab("Seedling Species")+
  ylim(0.05, 0.17)+
  facet_grid(~NewAS)+
  theme_minimal()+
  theme(text = element_text(size = 18, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        plot.title = element_text(face="bold",hjust = 0.5),
        axis.text.x=element_text(size = 15, face="italic"),
        axis.text.y=element_text(size = 15),
        legend.position = "none",
        strip.text.x = element_text(face="italic"))+
  colScale +
  fillScale
dev.off()

#below-ground biomass
refBelow<- lsmeans(bm.glm.below, pairwise~Seedling_Species*Adult_Species, data = pdatBM, pbkrtest.limit =  5000, lmerTest.limit = 5000)
refBelow.table <- as.data.frame(refBelow$lsmeans)

ref.below.hcht <- refBelow.table %>%
  filter((Adult_Species =="HC"&Seedling_Species=="HC") | 
           (Adult_Species=="HC"& Seedling_Species =="HT") | 
           (Adult_Species =="HT" & Seedling_Species =="HT") | 
           (Adult_Species=="HT"&Seedling_Species=="HC"))%>%
  mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
  mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))

png("Figures/BMBelow_hcht_28.4.22_02.jpg", width=6, height= 6, units='in', res=300)
ref.below.hcht%>%
  ggplot(., aes(NewSS, lsmean, color=NewSS))+
  geom_rect(data=ref.below.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = 0,ymax = 7.5, alpha =0.25) +
  geom_point(position=position_dodge(1), size=4, show.legend = FALSE)+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5, size=1, position = position_dodge(1))+
  ylab("Below-ground Biomass")+
  xlab("Seedling Species")+
  ylim(0.01, 0.04)+
  facet_grid(~NewAS)+
  theme_minimal()+
  theme(text = element_text(size = 18, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        plot.title = element_text(face="bold",hjust = 0.5),
        axis.text.x=element_text(size = 15, face="italic"),
        axis.text.y=element_text(size = 15),
        legend.position = "none",
        strip.text.x = element_text(face="italic"))+
  colScale +
  fillScale
dev.off()

#### Pairwise feedback analyses: SURVIVAL ####
####. Load data ####
pdat<- read.csv("data/Seedling_census_data_curated_12_20_21.csv",header=TRUE,sep=",") %>%  
  dplyr::select(c(Date,Seedling_ID,Herbivory,Pathogen_Symptoms,Date_collected,Cause_of_death,AdultTag,Adult_Species,Seedling_Species))  %>%   
  mutate(mYear = substr(Date, 1,4)) %>% 
  mutate(mMonth = substr(Date, 5,6)) %>%
  mutate(mDay =substr(Date, 7,8)) %>%
  mutate(mnewDate= paste(mYear, mMonth, mDay, sep="-")) %>% 
  mutate(mdoy = yday(mnewDate)) %>%
  mutate(mdoy = ifelse(mYear==2020, mdoy+365, mdoy)) %>%
  mutate(cYear = ifelse(Date_collected != 0, substr(Date_collected, 1,4), NA)) %>% 
  mutate(cMonth = ifelse(Date_collected != 0, substr(Date_collected, 5,6), NA)) %>%
  mutate(cDay = ifelse(Date_collected != 0, substr(Date_collected, 7,8), NA)) %>%
  mutate(cnewDate= ifelse(Date_collected != 0, paste(cYear, cMonth, cDay, sep="-"), NA)) %>% 
  mutate(cdoy = yday(cnewDate)) %>% 
  mutate(cdoy = ifelse(cYear==2020, cdoy+365, cdoy)) %>% 
  mutate(Conhetero = ifelse(Adult_Species==Seedling_Species, "Con", "Hetero")) %>%  
  dplyr::select(-c(mYear, mMonth, mDay, mnewDate, cYear, cMonth, cDay, cnewDate)) %>%
  mutate(Exclosure_Tag = paste(AdultTag, Seedling_Species, sep = "_")) 

pdat.last<- pdat %>% 
  group_by(Seedling_ID) %>% 
  arrange(desc(mdoy)) %>%     
  dplyr::slice(1) %>%            
  ungroup() %>%
  as.data.frame() %>%
  mutate(Survival= ifelse(Cause_of_death == "Collected", 1, 0)) 

pdat.before <- anti_join(pdat, pdat.last) %>% mutate(Survival = 1) 
pdatSur <- rbind(pdat.before, pdat.last)

saveRDS(pdatSur,'data/survivaldatarepeat.rds')

####. Modelling survival ####
survival.glm.repeat<-glmer(Survival ~ Seedling_Species*Adult_Species*mdoy +(1|AdultTag:Seedling_Species)+ (1|AdultTag:Seedling_Species:Seedling_ID)  , data= pdatSur, family = "binomial")
summary(survival.glm.repeat)
anova(survival.glm.repeat)

####. contrast analysis ####
contrasts <- list("home vs. away" = c(3,-1,-1,-1,-1,3,-1,-1,-1,-1,3,-1,-1,-1,-1,3),
                  "DG_HC"= c(1,-1,0,0,-1,1,0,0,0,0,0,0,0,0,0,0),
                  "DG_HT"= c(1,0,-1,0,0,0,0,0,-1,0,1,0,0,0,0,0),
                  "DG_SA"= c(1,0,0,-1,0,0,0,0,0,0,0,0,-1,0,0,1),
                  "HC_HT"= c(0,0,0,0,0,1,-1,0,0,-1,1,0,0,0,0,0),
                  "HC_SA"= c(0,0,0,0,0,1,0,-1,0,0,0,0,0,-1,0,1),
                  "HT_SA"= c(0,0,0,0,0,0,0,0,0,0,1,-1,0,0,-1,1),
                  "DG_avg"= c(3,-1,-1,-1,-1,1,0,0,-1,0,1,0,-1,0,0,1),
                  "HC_avg"= c(1,-1,0,0,-1,3,-1,-1,0,-1,1,0,0,-1,0,1),
                  "HT_avg"= c(1,0,-1,0,0,1,-1,0,-1,-1,3,-1,0,0,-1,1),
                  "SA_avg"= c(1,0,0,-1,0,1,0,-1,0,0,1,-1,-1,-1,-1,3))

means.Sur <- emmeans(survival.glm.repeat, ~Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000)
results.sur<-lsmeans::contrast(means.Sur,contrasts)
results.sur.df<-as.data.frame(results.sur)
results.sur.df

####. Visualisation ####
DG_Blue = rgb(75/255, 94/255, 160/255, 1)
HC_Green = rgb(121/255, 132/255, 27/255, 1)
HT_Yellow = rgb(218/255, 168/255, 17/255, 1)
SA_Purple = rgb(170/255, 142/255, 200/255, 1)

colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow)) # only DG and HT, because only significant contrast
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

ref<- lsmeans(survival.glm.repeat, pairwise~Seedling_Species*Adult_Species, data = pdat, pbkrtest.limit =  5000, lmerTest.limit = 5000, type = "response")
ref.table <- as.data.frame(ref$lsmeans)

ref.t.dght <- ref.table %>%
  filter((Adult_Species =="DG"&Seedling_Species=="DG") | 
           (Adult_Species=="DG"& Seedling_Species =="HT") | 
           (Adult_Species =="HT" & Seedling_Species =="HT") | 
           (Adult_Species=="HT"&Seedling_Species=="DG"))%>%
  mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
  mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))

png("Figures/Survival_dght_prob_20.4.22.jpg", width=6, height= 6, units='in', res=300)
survival<- ref.t.dght%>%
  ggplot(., aes(NewSS, prob, color=NewSS))+
  geom_rect(data=ref.t.dght[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = 0,ymax = 7.5, alpha = 0.25) +
  geom_point(position=position_dodge(1), size=10, show.legend = FALSE)+
  geom_errorbar(aes(ymin=prob-SE, ymax=prob+SE), width=.5, size=2, position = position_dodge(1))+
  ylab("Survival")+
  xlab("Seedling Species")+
  #ylim(0.95, 1.005)+
  facet_grid(~NewAS)+
  theme_minimal()+
  theme(text = element_text(size = 35, family = "Tahoma"),
        axis.title = element_text(face="bold"),
        plot.title = element_text(face="bold",hjust = 0.5),
        axis.text.x=element_text(size = 30, face="italic"),
        axis.text.y=element_text(size = 30),
        legend.position = "none",
        strip.text.x = element_text(face="italic"))+
  colScale +
  fillScale
dev.off()

png("Figures/Figure2_27.6.22.jpg", width=30, height= 14, units='in', res=300)
grid.arrange(survival,biomass, ncol=2)
dev.off()
