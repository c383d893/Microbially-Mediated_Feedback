#### PLANT CENSUS FEEDBACK ANALYSES ####

## ALLOMETRIC MODELS/PREDICTIONS
## BIOMASS
## SURVIVAL 

# load packages
library(tidyverse)
library(ggplot2)
library(lsmeans)
library(lmerTest)
library(pbkrtest)
library(gridExtra)
library(lme4)

# set colors
DG_Blue = rgb(75/255, 94/255, 160/255, 1)
HC_Green = rgb(121/255, 132/255, 27/255, 1)
HT_Yellow = rgb(218/255, 168/255, 17/255, 1)
SA_Purple = rgb(170/255, 142/255, 200/255, 1)

###############################
###### ALLOMETRIC MODELS ######
###############################

# read census data
pdat <- readRDS("data/census.meta.data.complete.rds") %>%
  # drop zero and no height data
  drop_na(., Height) %>%
  subset(., Height != 0) 

# load data for allometric equations, calculate biomass, relabel species
bm <- read.csv("data/AllometricEquations.csv", header = TRUE, sep = ",") %>%
  rename(Num_Leaves = Leaves) %>%
  mutate(TotalBM = DryWeightRoot + DryWeightStem + DryWeightLeaves)%>%
  mutate(Above = DryWeightStem + DryWeightLeaves) %>%
  mutate(Sp = substr(Seedling, 1,6))%>%
  mutate(Seedling_Species = ifelse(Sp == "HEISCO", "HC", ifelse(Sp == "DIALGU", "DG", ifelse(Sp == "HIRTTR", "HT", "SA"))))

# subset bm data to each species
bm.dg <- bm %>% filter(Seedling_Species == "DG")
bm.ht <- bm %>% filter(Seedling_Species == "HT")
bm.hc <- bm %>% filter(Seedling_Species == "HC")
bm.sa <- bm %>% filter(Seedling_Species == "SA")

# subset census data to each species
pdat.dg <- pdat %>% filter(Seedling_Species == "DG")
pdat.ht <- pdat %>% filter(Seedling_Species == "HT")
pdat.hc <- pdat %>% filter(Seedling_Species == "HC")
pdat.sa <- pdat %>% filter(Seedling_Species == "SA")

# biomass model & predict DG 
lm.dg.total <- lm(log(TotalBM) ~ Height + Num_Leaves, data = bm.dg)
summary(lm.dg.total) 
lm.dg.ab <- lm(log(Above) ~ Height + Num_Leaves, data = bm.dg)
summary(lm.dg.ab) 
lm.dg.bel <- lm(log(DryWeightRoot) ~ Height + Num_Leaves, data = bm.dg)
summary(lm.dg.bel) 

pred.dg.total <- predict.glm(lm.dg.total, type ="response", newdata = pdat.dg) %>% exp(.)
pred.dg.ab <- predict.glm(lm.dg.ab, type = "response", newdata = pdat.dg) %>% exp(.)
pred.dg.bel <- predict.glm(lm.dg.bel, type = "response", newdata = pdat.dg) %>% exp(.)

pdat.dg$TotalBM <- pred.dg.total
pdat.dg$AboveBM <- pred.dg.ab
pdat.dg$BelowBM <- pred.dg.bel

# biomass model & predict HT
lm.ht.total <- lm(log(TotalBM) ~ Height + Num_Leaves, data = bm.ht)
lm.ht.ab <- lm(log(Above) ~ Height + Num_Leaves, data = bm.ht)
lm.ht.bel <- lm(log(DryWeightRoot) ~ Height + Num_Leaves, data = bm.ht)

pred.ht.total <- predict.glm(lm.ht.total, type ="response", newdata = pdat.ht) %>% exp(.)
pred.ht.ab <- predict.glm(lm.ht.ab, type = "response", newdata = pdat.ht) %>% exp(.)
pred.ht.bel <- predict.glm(lm.ht.bel, type = "response", newdata = pdat.ht) %>% exp(.)

pdat.ht$TotalBM <- pred.ht.total
pdat.ht$AboveBM <- pred.ht.ab
pdat.ht$BelowBM <- pred.ht.bel

# biomass model & predict HC
lm.hc.total <- lm(log(TotalBM) ~ Height + Num_Leaves, data = bm.hc)
lm.hc.ab <- lm(log(Above) ~ Height + Num_Leaves, data = bm.hc)
lm.hc.bel <- lm(log(DryWeightRoot) ~ Height + Num_Leaves, data = bm.hc)

pred.hc.total <- predict.glm(lm.hc.total, type ="response", newdata = pdat.hc) %>% exp(.)
pred.hc.ab <- predict.glm(lm.hc.ab, type = "response", newdata = pdat.hc) %>% exp(.)
pred.hc.bel <- predict.glm(lm.hc.bel, type = "response", newdata = pdat.hc) %>% exp(.)

pdat.hc$TotalBM <- pred.hc.total
pdat.hc$AboveBM <- pred.hc.ab
pdat.hc$BelowBM <- pred.hc.bel

# biomass model & predict SA
lm.sa.total <- lm(log(TotalBM) ~ Height + Num_Leaves, data = bm.sa)
lm.sa.ab <- lm(log(Above) ~ Height + Num_Leaves, data = bm.sa)
lm.sa.bel <- lm(log(DryWeightRoot) ~ Height + Num_Leaves, data = bm.sa)

pred.sa.total <- predict.glm(lm.sa.total, type ="response", newdata = pdat.sa) %>% exp(.)
pred.sa.ab <- predict.glm(lm.sa.ab, type = "response", newdata = pdat.sa) %>% exp(.)
pred.sa.bel <- predict.glm(lm.sa.bel, type = "response", newdata = pdat.sa) %>% exp(.)

pdat.sa$TotalBM <- pred.sa.total
pdat.sa$AboveBM <- pred.sa.ab
pdat.sa$BelowBM <- pred.sa.bel

# join all together
pdatBM <- rbind(pdat.dg, pdat.hc, pdat.ht, pdat.sa)

# create data to join with blup later
pdatBM.blup <- pdatBM %>% 
  distinct(Adult_Tag, .keep_all=TRUE) %>%
  dplyr::select(c(Adult_Tag, Adult_Species))

###############################
######### BIOMASS FB ##########
###############################

# total biomass
bm.glm.total <- lmer(TotalBM ~ Seedling_Species*Adult_Species*mdoy + (1|Adult_Tag:Seedling_Species) + (1|Adult_Tag:Seedling_Species:Seedling_ID), data = pdatBM)
summary(bm.glm.total)
anova(bm.glm.total)

# for BLUP extraction
total_biomass <- ranef(bm.glm.total) %>% as.data.frame() %>% filter(!grpvar=="Adult_Tag:Seedling_Species")
total_biomass <- total_biomass %>% separate('grp', c("Adult_Tag","Seedling_Species","Seedling_ID"), sep = ":") %>%
  group_by(Adult_Tag, Seedling_Species) %>%
  summarize(mean_totalbiomass = mean(condval)) %>%
  mutate(Exclosure_Tag = paste(Adult_Tag, Seedling_Species, sep = "_")) %>%
  left_join(pdatBM.blup, by = "Adult_Tag")

# above-ground biomass
bm.glm.above <-lmer(AboveBM ~ Seedling_Species*Adult_Species*mdoy +(1|Adult_Tag:Seedling_Species)+ (1|Adult_Tag:Seedling_Species:Seedling_ID) , data= pdatBM)
summary(bm.glm.above)
anova(bm.glm.above)

# for BLUP extraction
above_biomass <- ranef(bm.glm.above) %>% as.data.frame() %>% filter(!grpvar=="Adult_Tag:Seedling_Species")
above_biomass <- above_biomass %>% separate('grp', c("Adult_Tag","Seedling_Species","Seedling_ID"), sep = ":") %>%
  group_by(Adult_Tag, Seedling_Species) %>%
  summarize(mean_abovebiomass = mean(condval)) %>%
  mutate(Exclosure_Tag = paste(Adult_Tag, Seedling_Species, sep = "_")) %>%
  left_join(pdatBM.blup, by = "Adult_Tag")

# below-ground biomass
bm.glm.below <- lmer(BelowBM ~ Seedling_Species*Adult_Species*mdoy +(1|Adult_Tag:Seedling_Species)+ (1|Adult_Tag:Seedling_Species:Seedling_ID) , data= pdatBM)
summary(bm.glm.below)
anova(bm.glm.below)

# for BLUP extraction
pdatBM <- pdatBM %>% mutate(Exclosure_Tag = paste(Adult_Tag, Seedling_Species, sep = "_"))
below_biomass <- ranef(bm.glm.below) %>% as.data.frame() %>% filter(!grpvar=="Adult_Tag:Seedling_Species")
below_biomass <- below_biomass %>% separate('grp', c("Adult_Tag", "Seedling_Species", "Seedling_ID"), sep = ":") %>%
  group_by(Adult_Tag, Seedling_Species) %>%
  summarize(mean_belowbiomass = mean(condval)) %>%
  mutate(Exclosure_Tag = paste(Adult_Tag, Seedling_Species, sep = "_")) %>%
  left_join(pdatBM.blup, by = "Adult_Tag")

# join BLUP: feedback divergence analysis
blup_bio <- total_biomass %>%
  full_join(above_biomass, by = c('Adult_Tag','Adult_Species','Seedling_Species','Exclosure_Tag')) %>%
  full_join(below_biomass, by = c('Adult_Tag','Adult_Species','Seedling_Species','Exclosure_Tag'))

# write as .rds file
saveRDS(blup_bio, "data/blup_estimated_biomass.rds")

# set contrast
contrasts <- list("home vs. away" = c(3,-1,-1,-1,-1,3,-1,-1,-1,-1,3,-1,-1,-1,-1,3),
                  "DG_HC"= c(1,-1,0,0,-1,1,0,0,0,0,0,0,0,0,0,0),
                  "DG_HT"= c(1,0,-1,0,0,0,0,0,-1,0,1,0,0,0,0,0),
                  "DG_SA"= c(1,0,0,-1,0,0,0,0,0,0,0,0,-1,0,0,1),
                  "HC_HT"= c(0,0,0,0,0,1,-1,0,0,-1,1,0,0,0,0,0),
                  "HC_SA"= c(0,0,0,0,0,1,0,-1,0,0,0,0,0,-1,0,1),
                  "HT_SA"= c(0,0,0,0,0,0,0,0,0,0,1,-1,0,0,-1,1),
                  "DG_avg"= c(3,-1,-1,-1,-1,1,0,0,-1,0,1,0,-1,0,0,1),
                  "HC_avg"= c(1,-1,0,0,-1,3,-1,-1,0,-1,1,0,0,-1,0,1),
                  "HT_avg"= c(1,0,-1,0,0,1,-1,0,-1,-1,3,-1,0,0,-1,1),
                  "SA_avg"= c(1,0,0,-1,0,1,0,-1,0,0,1,-1,-1,-1,-1,3))

# total biomass
means.TotalBM <- emmeans(bm.glm.total, ~Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000, type="response")
results.TotalBM <- lsmeans::contrast(means.TotalBM,contrasts)
results.Total.df <- as.data.frame(results.TotalBM)
results.Total.df
results.Total.df.bar <- results.Total.df %>% filter(!contrast == "home vs. away") %>% filter(!contrast == "DG_avg") %>% 
  filter(!contrast == "HT_avg") %>% filter(!contrast == "HC_avg") %>% filter(!contrast == "SA_avg")

TotalBM.plot <- 
  ggplot(results.Total.df.bar, aes(x=reorder(contrast,estimate), estimate)) + 
  geom_point(position=position_dodge(1), size =4) + 
  geom_errorbar(aes(ymin=estimate-SE, ymax=estimate+SE), width=0.5,size=1, position=position_dodge(1)) + 
  xlab("Species pair")+ ylab("Feedback (Biomass)")+
  geom_abline(intercept = 0, slope = 0, linetype="dashed") +
  theme_minimal(base_size = 16)+
  theme(#axis.text.y = element_blank(), 
    #axis.ticks = element_blank(),  
    axis.title.x = element_text(size=18, family = "Tahoma"), 
    axis.title.y = element_text(size=18, family = "Tahoma"), 
    panel.background = element_blank(), 
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(), 
    plot.background = element_blank(),
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 25)) 

png("Figures/PlantCensusFeedback_TotalBM.plot.jpg", width = 8, height = 4, units = 'in', res = 300)
TotalBM.plot
dev.off()

# above-ground biomass
means.AboveBM <- emmeans(bm.glm.above, ~Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000)
results.AboveBM <- lsmeans::contrast(means.AboveBM, contrasts)
results.Above.df <- as.data.frame(results.AboveBM)
results.Above.df
results.Above.df.bar <- results.Above.df %>% filter(!contrast == "home vs. away") %>% filter(!contrast == "DG_avg") %>% 
  filter(!contrast == "HT_avg") %>% filter(!contrast == "HC_avg") %>% filter(!contrast == "SA_avg")

AboveBM.plot <- 
ggplot(results.Above.df.bar, aes(x=reorder(contrast,estimate), estimate)) + 
  geom_point(position=position_dodge(1), size =4) + 
  geom_errorbar(aes(ymin=estimate-SE, ymax=estimate+SE), width=0.5,size=1, position=position_dodge(1)) + 
  xlab("Species pair")+ ylab("Feedback (Biomass)")+
  geom_abline(intercept = 0, slope = 0, linetype="dashed") +
  theme_minimal(base_size = 16)+
  theme(#axis.text.y = element_blank(), 
    #axis.ticks = element_blank(),  
    axis.title.x = element_text(size=18, family = "Tahoma"), 
    axis.title.y = element_text(size=18, family = "Tahoma"), 
    panel.background = element_blank(), 
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(), 
    plot.background = element_blank(),
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 25)) 

png("Figures/PlantCensusFeedback_AboveBM.plot.jpg", width = 8, height = 4, units = 'in', res = 300)
AboveBM.plot
dev.off()

# below-ground biomass
means.BelowBM <- emmeans(bm.glm.below, ~Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000)
results.BelowBM <- lsmeans::contrast(means.BelowBM,contrasts)
results.Below.df <- as.data.frame(results.BelowBM)
results.Below.df
results.Below.df.bar <- results.Below.df %>% filter(!contrast == "home vs. away") %>% filter(!contrast == "DG_avg") %>% 
  filter(!contrast == "HT_avg") %>% filter(!contrast == "HC_avg") %>% filter(!contrast == "SA_avg")

BelowBM.plot <- 
ggplot(results.Below.df.bar, aes(x=reorder(contrast,estimate), estimate)) + 
  geom_point(position=position_dodge(1), size =4) + 
  geom_errorbar(aes(ymin=estimate-SE, ymax=estimate+SE), width=0.5,size=1, position=position_dodge(1)) + 
  xlab("Species pair")+ ylab("Feedback (Biomass)")+
  geom_abline(intercept = 0, slope = 0, linetype="dashed") +
  theme_minimal(base_size = 16)+
  theme(#axis.text.y = element_blank(), 
    #axis.ticks = element_blank(),  
    axis.title.x = element_text(size=18, family = "Tahoma"), 
    axis.title.y = element_text(size=18, family = "Tahoma"), 
    panel.background = element_blank(), 
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(), 
    plot.background = element_blank(),
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 25)) 

png("Figures/PlantCensusFeedback_BelowBM.plot.jpg", width = 8, height = 4, units = 'in', res = 300)
BelowBM.plot
dev.off()

colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow)) 
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

# total biomass contrast HC_HT
refTotal <- lsmeans(bm.glm.total, pairwise~Seedling_Species*Adult_Species, data = pdatBM, pbkrtest.limit =  5000, lmerTest.limit = 5000)
refTotal.table <- as.data.frame(refTotal$lsmeans)

ref.total.hcht <- refTotal.table %>%
  filter((Adult_Species =="HC"&Seedling_Species=="HC") | 
           (Adult_Species=="HC"& Seedling_Species =="HT") | 
           (Adult_Species =="HT" & Seedling_Species =="HT") | 
           (Adult_Species=="HT"&Seedling_Species=="HC"))%>%
  mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
  mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))

pdatBM.hcht <- pdatBM %>%
  filter((Adult_Species =="HC" & Seedling_Species=="HC") | 
                        (Adult_Species == "HC"& Seedling_Species == "HT") | 
                        (Adult_Species == "HT" & Seedling_Species == "HT") | 
                        (Adult_Species == "HT"&Seedling_Species == "HC")) %>%
  mutate(NewSS = case_when(Seedling_Species == "HC" ~ "H.c.",
                           Seedling_Species == "HT" ~ "H.t.")) %>%
  mutate(NewAS = case_when(Adult_Species == "HC" ~ "Heisteria concinna",
                                    Adult_Species == "HT" ~ "Hirtella triandra"))

TotalBM.plot.HTHC <- 
  ref.total.hcht %>%
  ggplot(., aes(NewSS, lsmean, color=NewSS))+
  geom_rect(data=ref.total.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = 0,ymax = 7.5, alpha =0.25) +
  geom_point(position=position_dodge(1), size=10, show.legend = FALSE)+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5, size=2, position = position_dodge(1))+
  geom_point(data = pdatBM.hcht,aes(x=NewSS,y=TotalBM,color=NewAS),position=position_jitter(width =.2),size=2,alpha=0.5, pch=1)+
  ylab("Biomass")+
  xlab("Seedling Species")+
  ylim(0.075, 0.3)+
  facet_grid(~NewAS)+
  theme_minimal(base_size = 16)+
  theme(#axis.text.y = element_blank(), 
        #axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 25))+
  colScale + fillScale 

png("Figures/PlantCensusFeedback_TotalBM.plot.HTHC.jpg", width = 5, height = 5, units = 'in', res = 300)
TotalBM.plot.HTHC
dev.off()

# above biomass contrast HC_HT
refAbove <- lsmeans(bm.glm.above, pairwise~Seedling_Species*Adult_Species, data = pdatBM, pbkrtest.limit =  5000, lmerTest.limit = 5000)
refAbove.table <- as.data.frame(refAbove$lsmeans)

ref.above.hcht <- refAbove.table %>%
  filter((Adult_Species == "HC" & Seedling_Species == "HC") | 
           (Adult_Species == "HC" & Seedling_Species == "HT") | 
           (Adult_Species =="HT" & Seedling_Species == "HT") | 
           (Adult_Species == "HT" & Seedling_Species == "HC"))%>%
  mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
  mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))

AboveBM.plot.HTHC <-
  ref.above.hcht %>%
  ggplot(., aes(NewSS, lsmean, color=NewSS))+
  geom_rect(data=ref.total.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = 0,ymax = 7.5, alpha =0.25) +
  geom_point(position=position_dodge(1), size=10, show.legend = FALSE)+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5, size=2, position = position_dodge(1))+
  geom_point(data = pdatBM.hcht,aes(x=NewSS,y=AboveBM,color=NewSS),position=position_jitter(width =.2),size=2,alpha=0.5, pch=1)+
  ylab("Aboveground Biomass")+
  xlab("Seedling Species")+
  #ylim(0.075, 0.175)+
  facet_grid(~NewAS)+
  theme_minimal(base_size=16)+
  theme(#axis.text.y = element_blank(), 
        #axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 25))+
  colScale + fillScale

png("Figures/PlantCensusFeedback_AboveBM.plot.HTHC.jpg", width = 10, height = 10, units = 'in', res = 300)
AboveBM.plot.HTHC
dev.off()

# below biomass contrast HC-HT
refBelow<- lsmeans(bm.glm.below, pairwise~Seedling_Species*Adult_Species, data = pdatBM, pbkrtest.limit =  5000, lmerTest.limit = 5000)
refBelow.table <- as.data.frame(refBelow$lsmeans)

ref.below.hcht <- refBelow.table %>%
  filter((Adult_Species =="HC"&Seedling_Species=="HC") | 
           (Adult_Species=="HC"& Seedling_Species =="HT") | 
           (Adult_Species =="HT" & Seedling_Species =="HT") | 
           (Adult_Species=="HT"&Seedling_Species=="HC"))%>%
  mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
  mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))

BelowBM.plot.HTHC <-
ref.below.hcht %>%
  ggplot(., aes(NewSS, lsmean, color=NewSS))+
  geom_rect(data=ref.total.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = 0,ymax = 7.5, alpha =0.25) +
  geom_point(position=position_dodge(1), size=10, show.legend = FALSE)+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5, size=2, position = position_dodge(1))+
  geom_point(data = pdatBM.hcht,aes(x=NewSS,y=BelowBM,color=NewSS),position=position_jitter(width =.2),size=2,alpha=0.5, pch=1)+
  ylab("Belowground Biomass")+
  xlab("Seedling Species")+
  #ylim(0.075, 0.175)+
  facet_grid(~NewAS)+
  theme_minimal(base_size=16)+
  theme(#axis.text.y = element_blank(), 
        #axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 25))+
  colScale + fillScale

png("Figures/PlantCensusFeedback_BelowBM.plot.HTHC.jpg", width = 10, height = 10, units = 'in', res = 300)
BelowBM.plot.HTHC
dev.off()

###############################
######### SURVIVAL FB #########
###############################

pdat.sur <- readRDS("data/census.meta.data.complete.rds")
  
survival.glm.repeat <- glmer(Survival ~ Seedling_Species*Adult_Species*mdoy + (1|Adult_Tag:Seedling_Species) + (1|Adult_Tag:Seedling_Species:Seedling_ID), data = pdat.sur, family = "binomial", glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000)))
summary(survival.glm.repeat)
anova(survival.glm.repeat)

# fixed version for means extraction
survival.glm.repeat.fixed <- glmer(Survival ~ Seedling_Species*Adult_Species*mdoy + Adult_Species:Adult_Tag:Seedling_Species + (1|Adult_Tag:Seedling_Species:Seedling_ID), data = pdat.sur, family = "binomial", glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 100000)))
summary(survival.glm.repeat.fixed)

# for means extraction
# logit
means.Sur.fixed <- emmeans(survival.glm.repeat.fixed, ~ Adult_Species:Adult_Tag:Seedling_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000)
Sur.table <- as.data.frame(means.Sur.fixed) %>%
  mutate(Exclosure_Tag = paste(Adult_Tag, Seedling_Species, sep = "_")) %>%
  rename(probsurv = emmean)

# write as .rds file
saveRDS(Sur.table, "data/means_estimated_survival.rds")

means.Sur <- emmeans(survival.glm.repeat, ~ Seedling_Species*Adult_Species, pbkrtest.limit = 5000, lmerTest.limit = 5000, type= "response")

results.sur <- lsmeans::contrast(means.Sur,contrasts)
results.sur.df <- as.data.frame(results.sur)
results.sur.df
results.sur.df.bar <- results.sur.df %>% filter(!contrast == "home vs. away") %>% filter(!contrast == "DG_avg") %>% 
  filter(!contrast == "HT_avg") %>% filter(!contrast == "HC_avg") %>% filter(!contrast == "SA_avg") %>% filter(!contrast == "HC_SA") 

Survival.plot <- 
  ggplot(results.sur.df.bar, aes(x=reorder(contrast,odds.ratio), odds.ratio)) + 
  geom_point(position=position_dodge(1), size=5, show.legend = FALSE)+
  geom_errorbar(aes(ymin=odds.ratio-SE, ymax=odds.ratio+SE), width=.5, size=1, position = position_dodge(1))+
  xlab("Species pair")+ ylab("Feedback (Survival)")+
  geom_abline(intercept = 0, slope = 0, linetype="dashed") +
  theme_minimal(base_size = 16)+
  theme(#axis.text.y = element_blank(), 
    #axis.ticks = element_blank(),  
    axis.title.x = element_text(size=18, family = "Tahoma"), 
    axis.title.y = element_text(size=18, family = "Tahoma"), 
    panel.background = element_blank(), 
    panel.grid.major = element_blank(),  
    panel.grid.minor = element_blank(), 
    plot.background = element_blank(),
    legend.position = "none",
    plot.title = element_text(hjust = 0.5, size = 25)) 

png("Figures/PlantCensusFeedback_Survival.plot.jpg", width = 8, height = 4, units = 'in', res = 300)
Survival.plot
dev.off()

# set colors
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow)) 
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

ref <- lsmeans(survival.glm.repeat, pairwise~Seedling_Species*Adult_Species, data = pdat.sur, pbkrtest.limit =  5000, lmerTest.limit = 5000, type = "response")
ref.table <- as.data.frame(ref$lsmeans)

ref.t.dght <- ref.table %>%
  filter((Adult_Species == "DG"&Seedling_Species == "DG") | 
           (Adult_Species == "DG"& Seedling_Species == "HT") | 
           (Adult_Species == "HT" & Seedling_Species == "HT") | 
           (Adult_Species == "HT"&Seedling_Species == "DG"))%>%
  mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
  mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))

pdat.sur.dght <- pdat.sur %>%
  filter((Adult_Species == "DG"&Seedling_Species == "DG") | 
           (Adult_Species == "DG"& Seedling_Species == "HT") | 
           (Adult_Species == "HT" & Seedling_Species == "HT") | 
           (Adult_Species == "HT"&Seedling_Species == "DG"))%>%
  mutate(NewSS = case_when(Seedling_Species == "DG" ~ "D.g.",
                           Seedling_Species == "HT" ~ "H.t.")) %>%
  mutate(NewAS = case_when(Adult_Species == "DG" ~ "Dialium guianense",
                           Adult_Species == "HT" ~ "Hirtella triandra"))

Survival.plot.DGHT <- 
  ref.t.dght %>%
  ggplot(., aes(NewSS, lsmean, color=NewSS))+
  geom_rect(data=ref.t.dght[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = -Inf,ymax = Inf, alpha = 0.25) +
  geom_point(position=position_dodge(1), size=10, show.legend = FALSE)+
  geom_errorbar(aes(ymin=lsmean-SE, ymax=lsmean+SE), width=.5, size=2, position = position_dodge(1))+
  #for SI with points
  #geom_point(data = pdat.sur.dght,aes(x=NewSS,y=Survival,color=NewSS),position=position_jitter(width =.2, height=0),size=2,alpha=0.8, pch=1)+
  ylab("Survival")+
  xlab("Seedling Species")+
  #ylim(0.075, 0.175)+
  facet_grid(~NewAS)+
  theme_minimal(base_size = 16)+
  theme(#axis.text.y = element_blank(), 
        #axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 25))+
  colScale + fillScale

png("figures/PlantCensusFeedback_Survival.DGHT.jpg", width=5, height= 5, units='in', res=300)
Survival.plot.DGHT
dev.off()

png("figures/PlantCensusFeedback_Survival.DGHT_SI.jpg", width=5, height= 5, units='in', res=300)
Survival.plot.DGHT
dev.off()
