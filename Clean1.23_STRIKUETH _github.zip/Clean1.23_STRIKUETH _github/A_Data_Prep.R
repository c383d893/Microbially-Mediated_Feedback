#### CLEAN METADATA ####

# clean molecular data
# clean census data

#############################################
##### CLEAN MOLECULAR SAMPLE META DATA ######
#############################################

# load packages
library(tidyverse)
library(lubridate)
library(ape)
library(TreeTools)

# import meta data seed
meta.seed <- read.table('data/Seedling_Metadata_05.27.2021.txt',header=TRUE)
# import meta data soil
meta.soil.1 <- read.table('data/Sequenced_soil_metadata_1.txt',header=TRUE)
meta.soil.2 <- read.table('data/Sequenced_soil_metadata_2.txt',header=TRUE)

meta.soil <- meta.soil.1 %>% full_join(meta.soil.2, by ="Soil_ID") %>%
  mutate(Sample_Type ="Soil") %>%
  rename(Adult_tag = Adult_Tag) %>%
  dplyr::select(-Soil_ID)

# add Sample_Type:
meta.seed.root <- filter(meta.seed, grepl("_R", Sample_Name)) %>%
  mutate(Sample_Type = "Root")
meta.seed.leaf <- filter(meta.seed, grepl("_L", Sample_Name)) %>%
  mutate(Sample_Type = "Leaf")
meta.seed <- rbind(meta.seed.root,meta.seed.leaf) %>%
  mutate(Timepoint ="1")

# add timepoint to roots:
meta.soil.T2 <- filter(meta.soil, grepl("_T", Sample_Name)) %>%
  mutate(Timepoint = "2")
meta.soil.T1 <- filter(meta.soil, grepl("_S", Sample_Name)) %>%
  mutate(Timepoint = "1")
meta.soil <- rbind(meta.soil.T1, meta.soil.T2)

# join meta.seed and meta.soil:
meta.mol <- bind_rows(meta.seed,meta.soil) %>% 
  mutate_all(as.factor) %>%
  dplyr::select(-Status) %>%
  # assign con v hetero
  mutate(Conhetero = ifelse(Seedling_Species==Adult_Species, "Con", "Hetero")) %>% 
  mutate(Conhetero = as.factor(Conhetero)) %>%
  # assign exclosure in v out
  mutate(InOut = ifelse(grepl("_1_",Seedling_ID), "In", "Out")) %>%
  # assign exclosure
  mutate(Exclosure_Tag = paste(Adult_tag, Seedling_Species, sep = "_")) %>%
  rename(Adult_Tag = Adult_tag)
  
# save as .rds file
saveRDS(meta.mol, file="data/mol.meta.data.complete.rds")

#############################################
########## CLEAN CENSUS META DATA ###########
#############################################

census.dat <- read.csv("data/Seedling_census_data_curated_12_20_21.csv", header = TRUE, sep = ",") %>%  
  # extract year month date of planting (Date) and assign day number
  mutate(mYear = substr(Date, 1,4)) %>% 
  mutate(mMonth = substr(Date, 5,6)) %>%
  mutate(mDay = substr(Date, 7,8)) %>%
  mutate(mnewDate = paste(mYear, mMonth, mDay, sep="-")) %>% 
  mutate(mdoy = yday(mnewDate)) %>%
  mutate(mdoy = ifelse(mYear == 2020, mdoy + 365, mdoy)) %>% # add 365 days for observations in 2020, because 01-01-2019 is day 1
  # extract year month date of collection (Date_collected) and assign day number
  mutate(cYear = ifelse(Date_collected != 0, substr(Date_collected, 1,4), NA)) %>% 
  mutate(cMonth = ifelse(Date_collected != 0, substr(Date_collected, 5,6), NA)) %>%
  mutate(cDay = ifelse(Date_collected != 0, substr(Date_collected, 7,8), NA)) %>%
  mutate(cnewDate= ifelse(Date_collected != 0, paste(cYear, cMonth, cDay, sep = "-"), NA)) %>% 
  mutate(cdoy = yday(cnewDate)) %>% 
  mutate(cdoy = ifelse(cYear == 2020, cdoy + 365, cdoy)) %>% 
  # assign con v hetero status
  mutate(Conhetero = ifelse(Adult_Species == Seedling_Species, "Con", "Hetero")) %>%
  # assign exclosure
  mutate(Exclosure_Tag = paste(AdultTag, Seedling_Species, sep = "_")) %>%
  select(-c(mYear, mMonth, mDay, cYear, cMonth, cDay, mnewDate, cnewDate, Exclosure_Code, Seedling_Num)) %>%
  rename(Adult_Tag = AdultTag) %>%
  mutate(Adult_Tag = as.character(Adult_Tag))

# assign survival status
# check to see the final status of each seedling & assign survival of yes if collected
census.last <- census.dat %>% 
  group_by(Seedling_ID) %>% 
  arrange(desc(mdoy)) %>%     
  dplyr::slice(1) %>%            
  ungroup() %>%
  as.data.frame() %>%
  mutate(Survival = ifelse(Cause_of_death == "Collected", 1, 0)) 

census.before <- anti_join(census.dat, census.last) %>% mutate(Survival = 1) 
census.dat.all <- rbind(census.before, census.last) 

# save as .rds file
saveRDS(census.dat.all, file="data/census.meta.data.complete.rds")
