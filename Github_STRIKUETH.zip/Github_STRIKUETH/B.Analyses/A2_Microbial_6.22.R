#### Clean script ####
# Contents:
# Microbial community composition analyses
# Microbial differential abundance analyses
# Code for microbiome analyses loads ASV data

#### PACKAGES ####
# for all analyses 
library(tidyverse)
library(ggplot2)
library(lsmeans)
library(dplyr)
library(lubridate)
library(lmerTest)
library(pbkrtest)
library(gridExtra)
library(phyloseq)
library(vegan)
library(multcomp)
library(MASS)
library(lme4)
library(devtools)  
library(pairwiseAdonis)  
library(VennDiagram)     

#### Microbiome analyses: COMMUNITY COMPOSITION ####
####. Define function ####
perm5 <- function(dataset, expvar1, expvar2 = NA, expvar3 = NA){
  tax.rare <- t(as(otu_table(dataset), 'matrix'))
  smd.rare <- as(sample_data(dataset), 'data.frame')
  y <- "tax.rare"
  ifelse(is.na(expvar2), groupvars <- expvar1,
         ifelse(is.na(expvar3), groupvars <- c(expvar1, expvar2), groupvars <- c(expvar1, expvar2, expvar3)))
  formular <- as.formula(paste(y, paste(groupvars, collapse = "*"), sep ="~"))
  set.seed(609)
  perm <- how(nperm = 999)
  setBlocks(perm) <- with(smd.rare, smd.rare$Exclorure_Tag)
  ps.perm <- adonis2(formular, permutations = 999, data = smd.rare, method = 'bray')
  return(ps.perm)
}

####. Define colours for visualisation ####
DG_Blue = rgb(75/255, 94/255, 160/255, 1)
HC_Green = rgb(121/255, 132/255, 27/255, 1)
HT_Yellow = rgb(218/255, 168/255, 17/255, 1)
SA_Purple = rgb(170/255, 142/255, 200/255, 1)
colScale <- scale_colour_manual(values = c(DG_Blue, HC_Green, HT_Yellow, SA_Purple))
fillScale <- scale_fill_manual(values = c(DG_Blue, HC_Green, HT_Yellow, SA_Purple))

####. Meta data ####
meta <- readRDS("data/meta.data.complete_24.05.22.RDS") #previously 5.28.21
meta <- meta %>%
  mutate(Conhetero = ifelse(Seedling_Species==Adult_Species, "Con", "Hetero")) %>% 
  mutate(Conhetero = as.factor(Conhetero)) %>%
  mutate(InOut = ifelse(grepl("_1_",Seedling_ID), "In", "Out"))%>%
  mutate(Exclosure_Tag = if_else(Sample_Type=="Root", paste(Adult_tag, InOut, sep = "_"), as.character(Adult_tag)))

metaAMF <- meta %>% filter(Group=="AMF")
metaFUN <- meta %>% filter(Group=="FUN") %>% mutate(Sample = rownames(.))

####. AMF community composition ####
####.. AMF data ####

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# the following code will read the ASV data
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

tax <- read.csv("data/ASVtable_clean_AMFonly.csv") %>% 
  t(.) %>% 
  as.data.frame()%>%
  rownames_to_column(var = "sample_names") %>%
  separate(sample_names, c("part1", "part2", "part3", "part4", "part5"), sep = "_", remove = TRUE)%>% 
  mutate(sample_names=paste(part1, part2, part3, sep = "_"))%>% 
  dplyr::select(-c("part1", "part2", "part3", "part4", "part5"))%>% 
  column_to_rownames("sample_names")%>%
  t(.)%>% 
  as.data.frame()%>%
  dplyr::rename(X.Taxa.ID = X.Taxa.ID_NA_NA) %>% 
  dplyr::select(-X_NA_NA)
# > replace tsv with csv for other AMF analyses!!!!

rownames(tax)<-tax$X.Taxa.ID 
tax <- tax %>%
  dplyr::select(-X.Taxa.ID) 
tax <- as.data.frame(sapply(tax,as.numeric)) 
tax <- as.matrix(tax)

####... AMF phyloseq set up ####
ph.taxAMF <- otu_table(tax, taxa_are_rows=TRUE)
ph.metaAMF <- sample_data(metaAMF)

psAMF <- phyloseq(ph.taxAMF, ph.metaAMF) %>%
  prune_taxa(taxa_sums(.)>10,.) %>%
  prune_samples(sample_sums(.)>0,.) %>% 
  subset_samples(.,!Adult_Species=="NA") %>%   
  subset_samples(.,!Seedling_Species=="NA")   

ps1AMF<- psAMF %>% subset_samples(Timepoint=="1") %>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) 

####.. AMF Permanovas ####

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# rarefy even depth needs to be adapted to lowest read number
# get lowest read number from sample sums
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

set.seed(609) 
sample_sums(ps1AMF) 
hist(sample_sums(ps1AMF), breaks = 20) 
ps1AMF.rare <- rarefy_even_depth(ps1AMF,sample.size=352) # change this according to lowest read number
perm5(ps1AMF.rare, "Adult_Species", "Seedling_Species")

####. FUN community composition ####
####.. FUN data ####

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# the following code will read the ASV data
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

taxaFUN <- read.csv('data/table_or_97_STRI_ASVFUN_R1_R2_forR.csv', header=TRUE)
taxaFUN <- column_to_rownames(taxaFUN,'Taxa_ID') 

guildFUN <- read.csv('data/table_or_97_STRI_ASVFUN_R1_R2_tax.guilds.csv', header=TRUE)
guildFUN <- guildFUN %>% dplyr::select(Taxa_ID, Guild, Confidence.Ranking)

path<-guildFUN %>% filter(Guild=="Plant Pathogen" | Guild=="Plant Pathogen-Wood Saprotroph"|Guild=="Plant Pathogen-Plant Saprotroph"| 
                            Guild=="Endophyte-Plant Pathogen-Undefined Saprotroph"|Guild=="Endophyte-Fungal Parasite-Plant Pathogen"|  
                            Guild=="Leaf Saprotroph-Plant Pathogen-Undefined Saprotroph-Wood Saprotroph"| Guild=="Plant Pathogen-Undefined Parasite-Undefined Saprotroph"|
                            Guild=="Animal Endosymbiont-Animal Pathogen-Endophyte-Plant Pathogen-Undefined Saprotroph"|Guild=="Dung Saprotroph-Endophyte-Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Endophyte-Plant Pathogen"| Guild=="Ectomycorrhizal-Fungal Parasite-Plant Pathogen-Wood Saprotroph"|
                            Guild=="Fungal Parasite-Plant Pathogen"| Guild=="Endophyte-Leaf Saprotroph-Plant Pathogen"|
                            Guild=="Endophyte-Plant Pathogen-Plant Saprotroph"| Guild=="Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Endophyte-Lichen Parasite-Plant Pathogen-Undefined Saprotroph"| Guild=="Fungal Parasite-Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Fungal Parasite-Plant Pathogen-Plant Saprotroph") %>% 
  mutate(newGuild="Pathogen") %>% 
  filter(Confidence.Ranking!="Possible") 

npath<- anti_join(guildFUN, path, by='Taxa_ID') %>% mutate(newGuild="Non-Pathogen") 

guildFUN2 <- rbind(path,npath) %>%
  column_to_rownames(., 'Taxa_ID')%>%
  as.matrix(.)

####... FUN phyloseq set up ####
ph.taxaFUN <- otu_table(taxaFUN, taxa_are_rows=TRUE) 
ph.metaFUN <- sample_data(metaFUN)	
ph.guildFUN <- tax_table(guildFUN2) 

psFUN <- phyloseq(ph.taxaFUN, ph.metaFUN,ph.guildFUN) %>% 
  prune_taxa(taxa_sums(.)>10,.)%>% 
  prune_samples(sample_sums(.)>0,.)%>%
  subset_samples(.,!Adult_Species=="NA")%>% 
  subset_samples(.,!Seedling_Species=="NA") %>% 
  subset_samples(., !Sample_Type=="Leaf")

ps1FUN <- psFUN %>% subset_samples(Timepoint=="1")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) 

ps1FUN.p <- ps1FUN %>% subset_taxa(newGuild=="Pathogen")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)  
ps1FUN.n <- ps1FUN %>% subset_taxa(newGuild=="Non-Pathogen")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) 

ps1FUN.p_soil <- ps1FUN.p %>% subset_samples(Sample_Type=="Soil")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)
ps1FUN.p_root <- ps1FUN.p %>% subset_samples(Sample_Type=="Root")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)

ps1FUN.n_soil <- ps1FUN.n %>% subset_samples(Sample_Type=="Soil")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)
ps1FUN.n_root <- ps1FUN.n %>% subset_samples(Sample_Type=="Root")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)

ps2FUN<- psFUN %>% subset_samples(Timepoint=="2")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) 

ps2FUN.p<- ps2FUN %>% subset_taxa(newGuild=="Pathogen")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)  
ps2FUN.n<- ps2FUN %>% subset_taxa(newGuild=="Non-Pathogen")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)

ps2FUN.p_soil <- ps2FUN.p %>% subset_samples(Sample_Type=="Soil")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)

ps2FUN.n_soil <- ps2FUN.n %>% subset_samples(Sample_Type=="Soil")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)

psTPFUN.p_soil <- psFUN %>% subset_taxa(newGuild=="Pathogen")%>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)
psTPFUN.n_soil <- psFUN %>% subset_taxa(newGuild=="Non-Pathogen")%>% subset_samples(Sample_Type=="Soil") %>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)

####.. FUN venn diagram root v soil ####

####... FUN pathogens venn diagram ####

ptaxasoil <- colnames(t(as(otu_table(ps1FUN.p_soil), 'matrix')))
ptaxaroot <- colnames(t(as(otu_table(ps1FUN.p_root), 'matrix')))

list.path<-list(ptaxasoil,ptaxaroot)
names(list.path) <- c("Soil", "Root")

venn.diagram(
  x = list.path,
  category.names = c("", ""),
  filename = 'figures/VennFunPath.Aug13.2022.png',
  output=TRUE,
  # Output features
  imagetype="png" ,
  height = 480 , 
  width = 480 , 
  resolution = 300,
  compression = "lzw",
  # Circles
  lwd = 2,
  lty = 'blank',
  fill=c("darkblue", "darkred"), 
  # Numbers
  cex = .6,
  fontface = "bold",
  fontfamily = "sans")

####... FUN nonpathogens venn diagram ####

ntaxasoil <- colnames(t(as(otu_table(ps1FUN.n_soil), 'matrix')))
ntaxaroot <- colnames(t(as(otu_table(ps1FUN.n_root), 'matrix')))

list.np<-list(ntaxasoil,ntaxaroot)
names(list.np) <- c("", "")

venn.diagram(
  x = list.np,
  category.names = c("", ""),
  filename = 'figures/VennFunNonPath.Aug13.2022.png',
  output=TRUE,
  # Output features
  imagetype="png" ,
  height = 480 , 
  width = 480 , 
  resolution = 300,
  compression = "lzw",
  # Circles
  lwd = 2,
  lty = 'blank',
  fill=c("darkblue", "darkred"),
  # Numbers
  cex = .6,
  fontface = "bold",
  fontfamily = "sans")

####.. FUN permanovas time point 1 ####

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# rarefy even depth needs to be adapted to lowest read number
# get lowest read number from sample sums
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

####... FUN pathogens soil ####
set.seed(609) 
sample_sums(ps1FUN.p_soil)
ps1FUN.p_soil.rare <- rarefy_even_depth(ps1FUN.p_soil,sample.size=24) # change this according to lowest read number
perm5(ps1FUN.p_soil.rare, "Adult_Species", "Seedling_Species")

####... FUN pathogens root ####
set.seed(609) 
sample_sums(ps1FUN.p_root)
ps1FUN.p_root.rare <- rarefy_even_depth(ps1FUN.p_root,sample.size=13) # change this according to lowest read number
perm5(ps1FUN.p_root.rare, "Adult_Species", "Seedling_Species")

####.... pairwise permanova ####
# pairwise species comparisons according to variable previously found significant
smd1.p_root.rare <- as(sample_data(ps1FUN.p_root.rare), 'data.frame')
taxFUN.p_root.rare <- t(as(otu_table(ps1FUN.p_root.rare), 'matrix'))
pairwise.adonis(taxFUN.p_root.rare, smd1.p_root.rare$Seedling_Species)

####... FUN non-pathogens soil ####
set.seed(609) 
sample_sums(ps1FUN.n_soil)
ps1FUN.n_soil.rare <- rarefy_even_depth(ps1FUN.n_soil,sample.size=3550) 
perm5(ps1FUN.n_soil.rare, "Adult_Species", "Seedling_Species")

####.... pairwise anova ####
smd1.n_soil.rare <- as(sample_data(ps1FUN.n_soil.rare), 'data.frame')
taxFUN.n_soil.rare <- t(as(otu_table(ps1FUN.n_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.n_soil.rare, smd1.n_soil.rare$Adult_Species)

####... FUN non-pathogens root ####
set.seed(609) 
sample_sums(ps1FUN.n_root)
ps1FUN.n_root.rare <- rarefy_even_depth(ps1FUN.n_root,sample.size=1330) 
perm5(ps1FUN.n_root.rare, "Adult_Species", "Seedling_Species")

####.... pairwise anova seedling species ####
smd1.n_root.rare <- as(sample_data(ps1FUN.n_root.rare), 'data.frame')
taxFUN.n_root.rare <- t(as(otu_table(ps1FUN.n_root.rare), 'matrix'))
pairwise.adonis(taxFUN.n_root.rare, smd1.n_root.rare$Seedling_Species)

####.... pairwise anova adult species ####
smd1.n_root.rare <- as(sample_data(ps1FUN.n_root.rare), 'data.frame')
taxFUN.n_root.rare <- t(as(otu_table(ps1FUN.n_root.rare), 'matrix'))
pairwise.adonis(taxFUN.n_root.rare, smd1.n_root.rare$Adult_Species)

####.... visualisation non-pathogens ####
#NMDS in ggplot
ordinate(ps1FUN.n_soil.rare, distance='bray', method='NMDS') -> mp.bray.nmds
data.scores <- as.data.frame(scores(mp.bray.nmds))
data.scores$Sample <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

np.soil <- ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Adult_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-1.5, 1.5)+
  ylim(-1.5, 1.5)+
  colScale+
  fillScale+
  ggtitle("Soil community")+
  guides(color=guide_legend("Adult species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

#NMDS in ggplot
smd <- as(sample_data(ps1FUN.n_root.rare), 'data.frame')
ordinate(ps1FUN.n_root.rare, distance='bray', method='NMDS') -> mp.bray.nmds
data.scores <- as.data.frame(scores(mp.bray.nmds))
data.scores$Sample <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., smd, by = "Sample") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

np.root <- ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Seedling_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.3, 0.3)+
  ylim(-0.3, 0.3)+
  colScale+
  fillScale+
  ggtitle("Root community")+
  guides(color=guide_legend("Seedling species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

####.... visualisation Pathogens ####
#NMDS in ggplot
ordinate(ps1FUN.p_soil.rare, distance='bray', method='NMDS') -> mp.bray.nmds
data.scores <- as.data.frame(scores(mp.bray.nmds))
data.scores$Sample <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., metaFUN, by = "Sample") 
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

p.soil <- ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Adult_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-1.4, 1.4)+
  ylim(-1.4, 1.4)+
  colScale+
  fillScale+
  ggtitle("Soil community")+
  guides(color=guide_legend("Adult species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

#NMDS in ggplot
smd <- as(sample_data(ps1FUN.p_root.rare), 'data.frame')
ordinate(ps1FUN.n_root.rare, distance='bray', method='NMDS') -> mp.bray.nmds
data.scores <- as.data.frame(scores(mp.bray.nmds))
data.scores$Sample <- rownames(data.scores)
data.scores <- data.scores %>%
  full_join(., smd, by = "Sample")%>%
  drop_na()
species.scores <- as.data.frame(scores(mp.bray.nmds, "species"))
species.scores$species <- rownames(species.scores)

p.root <- ggplot() + 
  geom_point(data=data.scores,aes(x=NMDS1,y=NMDS2,colour=Seedling_Species),size=3) + 
  coord_equal() +
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))+
  xlim(-0.3, 0.3)+
  ylim(-0.3, 0.3)+
  colScale+
  fillScale+
  ggtitle("Root community")+
  guides(color=guide_legend("Seedling species"))+
  theme(legend.text=element_text(size=15),
        legend.title=element_text(size=15))

png("Figures/NMDS_np.soil_Aug3.22.jpg", width=6, height= 6, units='in', res=300)
np.soil
dev.off()

png("Figures/NMDS_np.root_Aug3.22.jpg", width=6, height= 6, units='in', res=300)
np.root
dev.off()

png("Figures/NMDS_p.soil_Aug3.22.jpg", width=6, height= 6, units='in', res=300)
p.soil
dev.off()

png("Figures/NMDS_p.root_Aug3.22.jpg", width=6, height= 6, units='in', res=300)
p.root
dev.off()

####.. FUN permanovas time point 2 ####
####... FUN pathogens soil T2 ####
set.seed(609) 
sample_sums(ps2FUN.p_soil)
ps2FUN.p_soil.rare <- rarefy_even_depth(ps2FUN.p_soil,sample.size=29) 
perm5(ps2FUN.p_soil.rare, "Adult_Species", "Seedling_Species")

#pairwise adonis pathogens soil T2
smd2.p_soil.rare <- as(sample_data(ps2FUN.p_soil.rare), 'data.frame')
taxFUN.p_soil.rare <- t(as(otu_table(ps2FUN.p_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.p_soil.rare, smd2.p_soil.rare$Adult_Species)

####... FUN non-pathogens soil T2 ####
set.seed(609) 
sample_sums(ps2FUN.n_soil)
ps2FUN.n_soil.rare <- rarefy_even_depth(ps2FUN.n_soil,sample.size=1389) 
perm5(ps2FUN.n_soil.rare, "Adult_Species", "Seedling_Species")

####.... pairwise adonis non-pathogens soil T2
smd2.n_soil.rare <- as(sample_data(ps2FUN.n_soil.rare), 'data.frame')
taxFUN.n_soil.rare <- t(as(otu_table(ps2FUN.n_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.n_soil.rare, smd2.n_soil.rare$Adult_Species)

####.. FUN permanovas across time points ####
####... FUN pathogens soils ####
set.seed(609)
sample_sums(psTPFUN.p_soil)
psTPFUN.p_soil.rare <- rarefy_even_depth(psTPFUN.p_soil, sample.size = 24)

taxTPFUN.p_soil.rare<-t(as(otu_table(psTPFUN.p_soil.rare),'matrix'))
rownames(taxTPFUN.p_soil.rare)
smdTPFUN.p_soil.rare <- as(sample_data(psTPFUN.p_soil.rare), 'data.frame')

set.seed(609) 
perm <- how(nperm = 999)
setBlocks(perm) <- with(smdTPFUN.p_soil.rare, smdTPFUN.p_soil.rare$Exclorure_Tag)
psTPFUN.p_soil.perm<- adonis2(taxTPFUN.p_soil.rare ~ Adult_Species*Timepoint + Seedling_Species, permutations = 999, data= smdTPFUN.p_soil.rare, method='bray')
psTPFUN.p_soil.perm

####.... pairwise adonis ####
smdTP.p_soil.rare <- as(sample_data(psTPFUN.p_soil.rare), 'data.frame')
taxFUN.p_soil.rare <- t(as(otu_table(psTPFUN.p_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.p_soil.rare, smdTP.p_soil.rare$Adult_Species)

####... FUN non-pathogens soil ####
set.seed(609)
sample_sums(psTPFUN.n_soil)
psTPFUN.n_soil.rare <- rarefy_even_depth(psTPFUN.n_soil, sample.size = 1442)

taxTPFUN.n_soil.rare<-t(as(otu_table(psTPFUN.n_soil.rare),'matrix'))
rownames(taxTPFUN.n_soil.rare)
smdTPFUN.n_soil.rare <- as(sample_data(psTPFUN.n_soil.rare), 'data.frame')

set.seed(609)
perm <- how(nperm = 999)
setBlocks(perm) <- with(smdTPFUN.n_soil.rare, smdTPFUN.n_soil.rare$Exclorure_Tag)
psTPFUN.n_soil.perm<- adonis2(taxTPFUN.n_soil.rare ~ Adult_Species*Timepoint + Seedling_Species, permutations = 999, data= smdTPFUN.n_soil.rare, method='bray')
psTPFUN.n_soil.perm

####.... pairwise adonis non-pathogens soil ####
smdTP.n_soil.rare <- as(sample_data(psTPFUN.n_soil.rare), 'data.frame')
taxFUN.n_soil.rare <- t(as(otu_table(psTPFUN.n_soil.rare), 'matrix'))
pairwise.adonis(taxFUN.n_soil.rare, smdTP.n_soil.rare$Adult_Species)

#### Microbiome analyses: DIFFERENTIAL ABUNDANCE ####
####. define new p-adjust function ####
p.adjust2 <- function (p, method = p.adjust.methods, n = length(p)) 
{
  method <- match.arg(method)
  if (method == "fdr") 
    method <- "BH"
  nm <- names(p)
  p <- as.numeric(p)
  p0 <- setNames(p, nm)
  if (all(nna <- !is.na(p))) 
    nna <- TRUE
  else p <- p[nna]
  lp <- length(p)
  #stopifnot(n >= lp)
  if (n <= 1) 
    return(p0)
  if (n == 2 && method == "hommel") 
    method <- "hochberg"
  p0[nna] <- switch(method, bonferroni = pmin(1, n * p), holm = {
    i <- seq_len(lp)
    o <- order(p)
    ro <- order(o)
    pmin(1, cummax((n + 1L - i) * p[o]))[ro]
  }, hommel = {
    if (n > lp) p <- c(p, rep.int(1, n - lp))
    i <- seq_len(n)
    o <- order(p)
    p <- p[o]
    ro <- order(o)
    q <- pa <- rep.int(min(n * p/i), n)
    for (j in (n - 1L):2L) {
      ij <- seq_len(n - j + 1L)
      i2 <- (n - j + 2L):n
      q1 <- min(j * p[i2]/(2L:j))
      q[ij] <- pmin(j * p[ij], q1)
      q[i2] <- q[n - j + 1L]
      pa <- pmax(pa, q)
    }
    pmax(pa, p)[if (lp < n) ro[1L:lp] else ro]
  }, hochberg = {
    i <- lp:1L
    o <- order(p, decreasing = TRUE)
    ro <- order(o)
    pmin(1, cummin((n + 1L - i) * p[o]))[ro]
  }, BH = {
    i <- lp:1L
    o <- order(p, decreasing = TRUE)
    ro <- order(o)
    pmin(1, cummin(n/i * p[o]))[ro]
  }, BY = {
    i <- lp:1L
    o <- order(p, decreasing = TRUE)
    ro <- order(o)
    q <- sum(1/(1L:n))
    pmin(1, cummin(q * n/i * p[o]))[ro]
  }, none = p)
  p0
}

####. contrasts and colours ####
contrasts <- list("home vs. away" = c(3,-1,-1,-1,-1,3,-1,-1,-1,-1,3,-1,-1,-1,-1,3),
                  "DG_HC"= c(1,-1,0,0,-1,1,0,0,0,0,0,0,0,0,0,0),
                  "DG_HT"= c(1,0,-1,0,0,0,0,0,-1,0,1,0,0,0,0,0),
                  "DG_SA"= c(1,0,0,-1,0,0,0,0,0,0,0,0,-1,0,0,1),
                  "HC_HT"= c(0,0,0,0,0,1,-1,0,0,-1,1,0,0,0,0,0),
                  "HC_SA"= c(0,0,0,0,0,1,0,-1,0,0,0,0,0,-1,0,1),
                  "HT_SA"= c(0,0,0,0,0,0,0,0,0,0,1,-1,0,0,-1,1),
                  "DG_avg"= c(3,-1,-1,-1,-1,1,0,0,-1,0,1,0,-1,0,0,1),
                  "HC_avg"= c(1,-1,0,0,-1,3,-1,-1,0,-1,1,0,0,-1,0,1),
                  "HT_avg"= c(1,0,-1,0,0,1,-1,0,-1,-1,3,-1,0,0,-1,1),
                  "SA_avg"= c(1,0,0,-1,0,1,0,-1,0,0,1,-1,-1,-1,-1,3)
)

DG_Blue = rgb(75/255, 94/255, 160/255, 1)
HC_Green = rgb(121/255, 132/255, 27/255, 1)
HT_Yellow = rgb(218/255, 168/255, 17/255, 1)
SA_Purple = rgb(170/255, 142/255, 200/255, 1)

####. Meta data ####
meta<-readRDS("data/meta.data.complete_24.05.22.RDS") #previously 5.28.21
meta <- meta %>%
  mutate(Conhetero = ifelse(Seedling_Species==Adult_Species, "Con", "Hetero")) %>% 
  mutate(Conhetero = as.factor(Conhetero)) %>%
  mutate(InOut = ifelse(grepl("_1_",Seedling_ID), "In", "Out"))%>%
  mutate(Exclosure_Tag = if_else(Sample_Type=="Root", paste(Adult_tag, InOut, sep = "_"), as.character(Adult_tag)))

metaAMF<-meta %>% filter(Group=="AMF")

metaFUN<-meta %>% filter(Group=="FUN")

####. AMF differential abundance ####
####.. AMF data ####

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# the following code will read the ASV data
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

tax<- read.csv("data/ASVtable_clean_AMFonly.csv") 
tax<- as.data.frame(tax)%>%
  dplyr::select(-X)
rownames(tax) <- paste("ASV", seq(1:nrow(tax)), sep = "_") 
tax2 <- tax %>%
  dplyr::select(X.Taxa.ID) %>%
  rownames_to_column(var = "OTU_name")
tax <- tax %>%
  dplyr::select(-X.Taxa.ID)
tax <- tax %>% 
  t(.) %>%
  as.data.frame()%>%
  rownames_to_column(var = "sample_names") %>%
  separate(sample_names, c("part1", "part2", "part3", "part4", "part5"), sep = "_", remove = TRUE)%>% 
  mutate(sample_names=paste(part1, part2, part3, sep = "_"))%>% 
  dplyr::select(-c("part1", "part2", "part3", "part4", "part5"))%>% 
  column_to_rownames("sample_names")%>%
  t(.)%>% #transpose back
  as.data.frame()

tax <- as.data.frame(sapply(tax,as.numeric)) 
tax <- tax%>%
  mutate(Taxa_ID = tax2[,1])%>%
  column_to_rownames("Taxa_ID")

####.. AMF phyloseq set up ####
ph.taxAMF <- otu_table(tax, taxa_are_rows=TRUE) 
ph.metaAMF <- sample_data(metaAMF)	

psAMF <- phyloseq(ph.taxAMF, ph.metaAMF) %>% 
  prune_taxa(taxa_sums(.)>10,.) %>% 
  prune_samples(sample_sums(.)>0,.) %>% 
  subset_samples(.,!Adult_Species=="NA") %>% 
  subset_samples(.,!Seedling_Species=="NA")  

ps1AMF<- psAMF %>% subset_samples(Timepoint=="1") %>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) # keep only timepoint 1

####.. data setup ####
tax.amf<-t(as(otu_table(ps1AMF),'matrix')) 
colsum<-colSums(tax.amf!= 0) 
tax.amf<-rbind(tax.amf,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.amf<-tax.amf[!(row.names(tax.amf) %in% row.names.remove), ] 

smd1.amf <- as(sample_data(ps1AMF), 'data.frame') 
smd1.amf  <- smd1.amf[rownames(smd1.amf) %in% rownames(tax.amf), ]

taxa <- tax.amf
smd <- smd1.amf

####.. for loop ####
# set up output dataframe:
output.amf<-data.frame() 

# loop glm over
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag), data=smd)#
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.amf<- rbind(output.amf,results) 
}

## add otu names
names<-rep(colnames(taxa),each=11)
output.amf$Taxon<-names

## adjust p for multiple comparisons
output.amf$padj<-p.adjust2(output.amf$p.value, method = "BH", n= length(unique(output.amf$Taxon)))

write.csv(output.amf, file = "data/DiffAbundanceAMF_ASV_03_06_22.csv")
output.amf<- read.csv("data/DiffAbundanceAMF_ASV_03_06_22.csv")

####.. visualisation ####

####... contrast wise ####
#subset and filter output data

op.amf.htavg <- output.amf%>%
  filter(contrast == "HT_avg")%>%
  filter(padj < 0.07)

####... Taxon wise graph ####
# HT average
colScale <- scale_colour_manual(values = c(DG_Blue, HC_Green, HT_Yellow, SA_Purple))
fillScale <- scale_fill_manual(values = c(DG_Blue, HC_Green, HT_Yellow, SA_Purple))

#subset taxa data
# HT average
taxa.htavg <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.amf.htavg, by = "Taxon")
rownames(taxa.htavg)<- taxa.htavg$Taxon
taxa.htavg <- taxa.htavg%>%
  dplyr::select(-Taxon)%>%
  t(.)

# HT average
for(i in colnames(taxa.htavg)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.htavg <- means %>%
    mutate(NewSS = c("D.g.", "H.c.", "H.t.", "S.a.",
                     "D.g.", "H.c.", "H.t.", "S.a.",
                     "D.g.", "H.c.", "H.t.", "S.a.",
                     "D.g.", "H.c.", "H.t.", "S.a."))%>%
    mutate(NewAS = c("Dialium guianense","Dialium guianense","Dialium guianense","Dialium guianense", 
                     "Heisteria concinna","Heisteria concinna","Heisteria concinna","Heisteria concinna", 
                     "Hirtella triandra","Hirtella triandra","Hirtella triandra","Hirtella triandra", 
                     "Simarouba amara","Simarouba amara","Simarouba amara","Simarouba amara"))
  filename = paste("figures/MultGLM_contrast_htavg_AMF_ASV_07.01.22_", i, sep = "") 
  filepath = paste(filename, ".png", sep= "") 
  png(filepath, width=7, height= 6, units='in', res=300)
  print({ggplot(means.htavg, aes(NewSS, emmean, color=NewSS)) +
      geom_rect(data=means.htavg[c(1,5,9,13),], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
                ymin = -250,ymax = 5000, alpha = 0.25) +
      geom_point(position=position_dodge(1), size =4) + 
      geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=1, position=position_dodge(1))+
      labs(title=i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale+
      fillScale+
      facet_grid(~NewAS)+
      theme(text = element_text(size = 18, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 12, face="italic"),
            axis.text.y=element_text(size = 12),
            legend.position = "none",
            strip.text.x = element_text(size= 12,face="italic"))
  })
  dev.off()
}

####. FUN differential abundance ####
####.. FUN data ####

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# the following code will read the ASV data
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

taxaFUN <- read.csv('data/table_or_97_STRI_ASVFUN_R1_R2_forR.csv', header=TRUE) 
rownames(taxaFUN) <- paste("ASV", seq(1:nrow(taxaFUN)), sep = "_") 
taxaFun2 <- taxaFUN %>%
  dplyr::select(Taxa_ID) %>%
  rownames_to_column(var = "Taxa_name")
taxaFUN <- taxaFUN %>%
  dplyr::select(-Taxa_ID)

guildFUN <- read.csv('data/table_or_97_STRI_ASVFUN_R1_R2_tax.guilds.csv', header=TRUE)
guildFUN <- guildFUN %>% dplyr::select(Taxa_ID, taxonomy, Guild, Confidence.Ranking)

guildFUN <- guildFUN %>%
  full_join(., taxaFun2, by = "Taxa_ID") %>%
  dplyr::select(-Taxa_ID)

path<-guildFUN %>% filter(Guild=="Plant Pathogen" | Guild=="Plant Pathogen-Wood Saprotroph"|Guild=="Plant Pathogen-Plant Saprotroph"| 
                            Guild=="Endophyte-Plant Pathogen-Undefined Saprotroph"|Guild=="Endophyte-Fungal Parasite-Plant Pathogen"|  
                            Guild=="Leaf Saprotroph-Plant Pathogen-Undefined Saprotroph-Wood Saprotroph"| Guild=="Plant Pathogen-Undefined Parasite-Undefined Saprotroph"|
                            Guild=="Animal Endosymbiont-Animal Pathogen-Endophyte-Plant Pathogen-Undefined Saprotroph"|Guild=="Dung Saprotroph-Endophyte-Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Endophyte-Plant Pathogen"| Guild=="Ectomycorrhizal-Fungal Parasite-Plant Pathogen-Wood Saprotroph"|
                            Guild=="Fungal Parasite-Plant Pathogen"| Guild=="Endophyte-Leaf Saprotroph-Plant Pathogen"|
                            Guild=="Endophyte-Plant Pathogen-Plant Saprotroph"| Guild=="Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Endophyte-Lichen Parasite-Plant Pathogen-Undefined Saprotroph"| Guild=="Fungal Parasite-Plant Pathogen-Undefined Saprotroph"|
                            Guild=="Fungal Parasite-Plant Pathogen-Plant Saprotroph") %>% 
  mutate(newGuild="Pathogen") %>% # make new guild: path
  filter(Confidence.Ranking!="Possible") 

npath<- anti_join(guildFUN, path, by='Taxa_name') %>% mutate(newGuild="Non-Pathogen") 

guildFUN2 <- rbind(path,npath) %>%
  column_to_rownames(., 'Taxa_name')%>%
  as.matrix(.)

####.. FUN: phyloseq set up####
ph.taxaFUN <- otu_table(taxaFUN, taxa_are_rows=TRUE) 
ph.metaFUN <- sample_data(metaFUN)	
ph.guildFUN <- tax_table(guildFUN2) 

psFUN <- phyloseq(ph.taxaFUN, ph.metaFUN,ph.guildFUN) %>% 
  prune_taxa(taxa_sums(.)>10,.)%>% 
  prune_samples(sample_sums(.)>0,.)%>%
  subset_samples(.,!Adult_Species=="NA")%>% 
  subset_samples(.,!Seedling_Species=="NA") 


ps1FUN<- psFUN %>% subset_samples(Timepoint=="1")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) 

ps1FUN.p<- ps1FUN %>% subset_taxa(newGuild=="Pathogen")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) 
ps1FUN.n<- ps1FUN %>% subset_taxa(newGuild=="Non-Pathogen")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.) 

sample_data(ps1FUN.p)$UsableReads <- sample_sums(ps1FUN.p)
sample_data(ps1FUN.n)$UsableReads <- sample_sums(ps1FUN.n)

ps1FUN.p_soil <- ps1FUN.p %>% subset_samples(Sample_Type=="Soil")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)
ps1FUN.p_root <- ps1FUN.p %>% subset_samples(Sample_Type=="Root")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)

ps1FUN.n_soil <- ps1FUN.n %>% subset_samples(Sample_Type=="Soil")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)
ps1FUN.n_root <- ps1FUN.n %>% subset_samples(Sample_Type=="Root")%>% prune_taxa(taxa_sums(.)>10,.) %>% prune_samples(sample_sums(.)>0,.)


####... Pathogens root ####
####.... data set up ####
tax.p.root<-t(as(otu_table(ps1FUN.p_root),'matrix')) 
colsum<-colSums(tax.p.root!= 0) 
tax.p.root<-rbind(tax.p.root,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>%
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.p.root<-tax.p.root[!(row.names(tax.p.root) %in% row.names.remove), ] 

smd1.p.root <- as(sample_data(ps1FUN.p_root), 'data.frame') 
smd1.p.root  <- smd1.p.root[rownames(smd1.p.root) %in% rownames(tax.p.root), ] 

taxa <- tax.p.root
smd <- smd1.p.root

####.... for loop ####
# set up output dataframe:
output.p.root<-data.frame() 

# loop glm over 
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:InOut), data=smd)#
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.p.root<- rbind(output.p.root,results) 
}

# add taxa names
names<-rep(colnames(taxa),each=11)
output.p.root$Taxon<-names

# adjust p for multiple comparisons
output.p.root$padj<-p.adjust2(output.p.root$p.value, method="BH", n= length(unique(output.p.root$Taxon))) 

write.csv(output.p.root, file = "data/DiffAbundanceProot_ASV_03_06_22.csv")
output.p.root<- read.csv("data/DiffAbundanceProot_ASV_03_06_22.csv")

# subset and filter output data
op.p.root.dght <- output.p.root%>%
  filter(contrast == "DG_HT")%>%
  filter(padj < 0.05) 

op.p.root.hcht <- output.p.root%>%
  filter(contrast == "HC_HT")%>%
  filter(padj < 0.05) 

####.... Taxon wise graphs ####
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

#subset taxa data
taxa.dght <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.p.root.dght, by = "Taxon")

rownames(taxa.dght)<- taxa.dght$Taxon
taxa.dght <- taxa.dght%>%
  dplyr::select(-c(Taxon))%>%
  t(.)

#Taxon wise graphs
for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species =="DG"&means$Seedling_Species=="DG") 
                                 | (means$Adult_Species=="DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species=="HT"&means$Seedling_Species=="DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_dght_Proot_ASV_07.01.22_", i, sep = "") 
  filepath = paste(filename, ".png", sep= "") 
  png(filepath, width=6, height= 6, units='in', res=300)
  print({ggplot(means.dght, aes(NewSS, emmean, color=NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position=position_dodge(1), size =10) + 
      geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=2, position=position_dodge(1))+
      labs(title=i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      theme_minimal()+
      colScale+
      fillScale+
      facet_grid(~NewAS)+
      theme(text = element_text(size = 35, family = "Tahoma"),
            axis.title = element_text(face="bold"),
            plot.title = element_text(face="bold",hjust = 0.5),
            axis.text.x=element_text(size = 30, face="italic"),
            axis.text.y=element_text(size = 30),
            legend.position = "none",
            strip.text.x = element_text(face="italic"))
  })
  dev.off()
}

# select specific taxa: ASV_148
i<-"ASV_148"
model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
means.dght <- means %>% filter((means$Adult_Species =="DG"&means$Seedling_Species=="DG") 
                               | (means$Adult_Species=="DG"& means$Seedling_Species =="HT") 
                               | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                               | (means$Adult_Species=="HT"&means$Seedling_Species=="DG")) %>%
  mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
  mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))

p_148 <- ggplot(means.dght, aes(NewSS, emmean, color=NewSS)) +
  geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = -1000,ymax = 2500, alpha = 0.25) +
  geom_point(position=position_dodge(1), size =10) + 
  geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=2, position=position_dodge(1))+
  labs(title="ASV 148 (Pathogen root)")+
  xlab("Seedling Species")+
  ylab("Estimated abundance")+
  facet_grid(~NewAS)+
  theme_classic()+
  theme(axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 25))+
  colScale+
  fillScale
  
# HC - HT
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

#subset taxa data
taxa.hcht <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.p.root.hcht, by = "Taxon")

rownames(taxa.hcht)<- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht%>%
  dplyr::select(-c(Taxon))%>%
  t(.)

#Taxon wise graphs
for(i in colnames(taxa.hcht)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hcht <- means %>% filter((means$Adult_Species =="HC"&means$Seedling_Species=="HC") 
                                 | (means$Adult_Species=="HC"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species=="HT"&means$Seedling_Species=="HC")) %>%
    mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_hcht_Proot_ASV_07.01.22_", i, sep = "") 
  filepath = paste(filename, ".png", sep= "") 
  png(filepath, width=6, height= 6, units='in', res=300)
  print({ggplot(means.hcht, aes(NewSS, emmean, color=NewSS)) +
      geom_rect(data=means.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position=position_dodge(1), size =4) + 
      geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=1, position=position_dodge(1))+
      labs(title=i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      facet_grid(~NewAS)+
      theme_classic()+
      theme(axis.text.y = element_blank(), 
            axis.ticks = element_blank(),  
            axis.title.x = element_text(size=18, family = "Tahoma"), 
            axis.title.y = element_text(size=18, family = "Tahoma"), 
            panel.background = element_blank(), 
            panel.grid.major = element_blank(),  
            panel.grid.minor = element_blank(), 
            plot.background = element_blank(),
            legend.position = "none",
            plot.title = element_text(hjust = 0.5, size = 25))+
      colScale+
      fillScale
    })
  dev.off()
}

####... Pathogens soil ####
####.... data set up ####
tax.p.soil<-t(as(otu_table(ps1FUN.p_soil),'matrix')) 
colsum<-colSums(tax.p.soil!= 0) 
tax.p.soil<-rbind(tax.p.soil,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.p.soil<-tax.p.soil[!(row.names(tax.p.soil) %in% row.names.remove), ] 

smd1.p.soil <- as(sample_data(ps1FUN.p_soil), 'data.frame') 
smd1.p.soil  <- smd1.p.soil[rownames(smd1.p.soil) %in% rownames(tax.p.soil), ] 

taxa <- tax.p.soil
smd <- smd1.p.soil

####.... for loop ####
# set up output dataframe:
output.p.soil<-data.frame() 

# loop glm over
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.p.soil<- rbind(output.p.soil,results) 
}

## add taxa names
names<-rep(colnames(taxa),each=11)
output.p.soil$Taxon<-names

## adjust p for multiple comparisons
output.p.soil$padj<-p.adjust2(output.p.soil$p.value, method = "BH", n= length(unique(output.p.soil$Taxon)))

write.csv(output.p.soil, file = "data/DiffAbundancePsoil_ASV_03_06_22.csv")
output.p.soil<-read.csv("data/DiffAbundancePsoil_ASV_03_06_22.csv")

####.... contrast wise ####
# subset and filter output data
op.p.soil.dght <- output.p.soil%>%
  filter(contrast == "DG_HT")%>%
  filter(padj < 0.05) 

op.p.soil.hcht <- output.p.soil%>%
  filter(contrast == "HC_HT")%>%
  filter(padj < 0.05) 

####.... Taxon wise graphs ####
#no significant contrasts

####... Non-pathogens root ####

####.... data setup ####
tax.n.root<-t(as(otu_table(ps1FUN.n_root),'matrix')) 
colsum<-colSums(tax.n.root!= 0) 
tax.n.root<-rbind(tax.n.root,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>%
  as.matrix()
row.names.remove <- c("colsum")
tax.n.root<-tax.n.root[!(row.names(tax.n.root) %in% row.names.remove), ] 

smd1.n.root <- as(sample_data(ps1FUN.n_root), 'data.frame') 
smd1.n.root  <- smd1.n.root[rownames(smd1.n.root) %in% rownames(tax.n.root), ] 

taxa <- tax.n.root
smd <- smd1.n.root

####.... for loop ####
# set up output dataframe:
output.n.root<-data.frame() 

# loop glm over
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:InOut), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.n.root<- rbind(output.n.root,results) 
}

## add taxa names
names<-rep(colnames(taxa),each=11)
output.n.root$Taxon<-names

## adjust p for multiple comparisons
output.n.root$padj<-p.adjust2(output.n.root$p.value, method = "BH", n= length(unique(output.n.root$Taxon)))

write.csv(output.n.root, file = "data/DiffAbundanceNroot_ASV_02_06_22.csv") 
output.n.root<- read.csv("data/DiffAbundanceNroot_ASV_02_06_22.csv") 

####.... contrast wise ####
#subset and filter output data 
op.n.root.dght <- output.n.root%>%
  filter(contrast == "DG_HT")%>%
  filter(padj < 0.05) 

op.n.root.hcht <- output.n.root%>%
  filter(contrast == "HC_HT")%>%
  filter(padj < 0.05) 

####.... Taxon wise graphs ####
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

# exclude taxa that cause error in graph for loop
# for ASVs
op.n.root.dght <- op.n.root.dght%>%
  filter(Taxon != "ASV_684" & Taxon != "ASV_2882" 
         & Taxon != "ASV_5063") 

#subset taxa data 
taxa.dght <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.root.dght, by = "Taxon")
rownames(taxa.dght)<- taxa.dght$Taxon
taxa.dght <- taxa.dght%>%
  dplyr::select(-Taxon)%>%
  t(.)

for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species =="DG"&means$Seedling_Species=="DG") 
                                 | (means$Adult_Species=="DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species=="HT"&means$Seedling_Species=="DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_dght_Nroot_ASV_07.01.22_", i, sep = "") 
  filepath = paste(filename, ".png", sep= "") 
  png(filepath, width=6, height= 6, units='in', res=300)
  print({ggplot(means.dght, aes(NewSS, emmean, color=NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
                ymin = -100,ymax = 200, alpha = 0.25) + #adapt limits to data set
      geom_point(position=position_dodge(1), size =4) + 
      geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=1, position=position_dodge(1))+
      labs(title=i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      facet_grid(~NewAS)+
      theme_classic()+
      theme(axis.text.y = element_blank(), 
            axis.ticks = element_blank(),  
            axis.title.x = element_text(size=18, family = "Tahoma"), 
            axis.title.y = element_text(size=18, family = "Tahoma"), 
            panel.background = element_blank(), 
            panel.grid.major = element_blank(),  
            panel.grid.minor = element_blank(), 
            plot.background = element_blank(),
            legend.position = "none",
            plot.title = element_text(hjust = 0.5, size = 25))+
      colScale+
      fillScale
    })
  dev.off()
}

# HC - HT
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

#subset taxa data 
taxa.hcht <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.root.hcht, by = "Taxon")
rownames(taxa.hcht)<- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht%>%
  dplyr::select(-Taxon)%>%
  t(.)

for(i in colnames(taxa.hcht)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hcht <- means %>% filter((means$Adult_Species =="DG"&means$Seedling_Species=="DG") 
                                 | (means$Adult_Species=="DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species=="HT"&means$Seedling_Species=="DG")) %>%
    mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_hcht_Nroot_ASV_07.01.22_", i, sep = "") 
  filepath = paste(filename, ".png", sep= "") 
  png(filepath, width=6, height= 6, units='in', res=300)
  print({ggplot(means.hcht, aes(NewSS, emmean, color=NewSS)) +
      geom_rect(data=means.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
                ymin = -100,ymax = 200, alpha = 0.25) + #adapt limits to data set
      geom_point(position=position_dodge(1), size =4) + 
      geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=1, position=position_dodge(1))+
      labs(title=i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      facet_grid(~NewAS)+
      theme_classic()+
      theme(axis.text.y = element_blank(), 
            axis.ticks = element_blank(),  
            axis.title.x = element_text(size=18, family = "Tahoma"), 
            axis.title.y = element_text(size=18, family = "Tahoma"), 
            panel.background = element_blank(), 
            panel.grid.major = element_blank(),  
            panel.grid.minor = element_blank(), 
            plot.background = element_blank(),
            legend.position = "none",
            plot.title = element_text(hjust = 0.5, size = 25))+
      colScale+
      fillScale
    })
  dev.off()
}

#select specific taxa: ASV_179
i<-"ASV_179"
model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
means.dght <- means %>% filter((means$Adult_Species =="DG"&means$Seedling_Species=="DG") 
                               | (means$Adult_Species=="DG"& means$Seedling_Species =="HT") 
                               | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                               | (means$Adult_Species=="HT"&means$Seedling_Species=="DG")) %>%
  mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
  mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))

p_179 <- ggplot(means.dght, aes(NewSS, emmean, color=NewSS)) +
  geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
            ymin = -1000,ymax = 2500, alpha = 0.25) +
  geom_point(position=position_dodge(1), size =10) + 
  geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=2, position=position_dodge(1))+
  labs(title="ASV 179 (Non-pathogen root)")+
  xlab("Seedling Species")+
  ylab("Estimated abundance")+
  facet_grid(~NewAS)+
  theme_classic()+
  theme(axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "none",
        plot.title = element_text(hjust = 0.5, size = 25))+
  colScale+
  fillScale

####... Non-pathogens soil ####
####.... data setup ####
tax.n.soil<-t(as(otu_table(ps1FUN.n_soil),'matrix'))
colsum<-colSums(tax.n.soil!= 0) 
tax.n.soil<-rbind(tax.n.soil,colsum) %>% 
  t(.) %>% 
  as.data.frame(.) %>% 
  filter(colsum > 1) %>% 
  t(.) %>% 
  as.matrix()
row.names.remove <- c("colsum")
tax.n.soil<-tax.n.soil[!(row.names(tax.n.soil) %in% row.names.remove), ] 

smd1.n.soil <- as(sample_data(ps1FUN.n_soil), 'data.frame') 
smd1.n.soil  <- smd1.n.soil[rownames(smd1.n.soil) %in% rownames(tax.n.soil), ]

taxa <- tax.n.soil
smd <- smd1.n.soil

####.... for loop ####
# set up output dataframe:
output.n.soil<-data.frame() 

# loop glm over
for(i in 1:ncol(taxa)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag), data=smd)
  joint_tests(model)
  means <- emmeans(model, ~Seedling_Species*Adult_Species)
  results<-lsmeans::contrast(means,contrasts) %>% as.data.frame()
  output.n.soil<- rbind(output.n.soil,results) 
}

## add taxa names
names<-rep(colnames(taxa),each=11)
output.n.soil$Taxon<-names

## adjust p for multiple comparisons
output.n.soil$padj<-p.adjust2(output.n.soil$p.value, method = "BH", n= length(unique(output.n.soil$Taxon)))

write.csv(output.n.soil, file = "data/DiffAbundanceNsoil_ASV_02_06_22.csv") 
output.n.soil<- read.csv("data/DiffAbundanceNsoil_ASV_02_06_22.csv") 

####.... contrast wise ####
#subset and filter output data
op.n.soil.dght <- output.n.soil%>%
  filter(contrast == "DG_HT")%>%
  filter(padj < 0.05) 

op.n.soil.hcht <- output.n.soil%>%
  filter(contrast == "HC_HT")%>%
  filter(padj < 0.05) 

####.... Taxon wise graphs ####
colScale <- scale_colour_manual(values = c(DG_Blue, HT_Yellow))
fillScale <- scale_fill_manual(values = c(DG_Blue, HT_Yellow))

# exclude taxa that cause error message in graph for loop
#for ASVs only
op.n.soil.dght <- op.n.soil.dght%>%
  filter(Taxon != "ASV_7223" & Taxon != "ASV_9342"
         & Taxon != "ASV_9777" & Taxon != "ASV_10685")

taxa.dght <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.soil.dght, by = "Taxon")#%>%
rownames(taxa.dght)<- taxa.dght$Taxon
taxa.dght <- taxa.dght%>%
  dplyr::select(-Taxon)%>%
  t(.)

for(i in colnames(taxa.dght)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.dght <- means %>% filter((means$Adult_Species =="DG"&means$Seedling_Species=="DG") 
                                 | (means$Adult_Species=="DG"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species=="HT"&means$Seedling_Species=="DG")) %>%
    mutate(NewSS = c("D.g.", "H.t.", "D.g.", "H.t."))%>%
    mutate(NewAS = c("Dialium guianense", "Dialium guianense", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_dght_Nsoil_ASV_07.01.22_", i, sep = "") 
  filepath = paste(filename, ".png", sep= "") 
  png(filepath, width=6, height= 6, units='in', res=300)
  print({ggplot(means.dght, aes(NewSS, emmean, color=NewSS)) +
      geom_rect(data=means.dght[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
                ymin = -250,ymax = 1000, alpha = 0.25) +
      geom_point(position=position_dodge(1), size =4) + 
      geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=1, position=position_dodge(1))+
      labs(title=i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      facet_grid(~NewAS)+
      theme_classic()+
      theme(axis.text.y = element_blank(), 
            axis.ticks = element_blank(),  
            axis.title.x = element_text(size=18, family = "Tahoma"), 
            axis.title.y = element_text(size=18, family = "Tahoma"), 
            panel.background = element_blank(), 
            panel.grid.major = element_blank(),  
            panel.grid.minor = element_blank(), 
            plot.background = element_blank(),
            legend.position = "none",
            plot.title = element_text(hjust = 0.5, size = 25))+
      colScale+
      fillScale
    })
  dev.off()
}

# HC - HT
colScale <- scale_colour_manual(values = c(HC_Green, HT_Yellow))
fillScale <- scale_fill_manual(values = c(HC_Green, HT_Yellow))

# exclude taxa that cause error message in graph for loop
#for ASVs only
op.n.soil.hcht <- op.n.soil.hcht%>%
  filter(Taxon != "ASV_748" & Taxon != "ASV_783" 
         & Taxon != "ASV_878" & Taxon != "ASV_878" &
           Taxon !="ASV_3356" & Taxon != "ASV_4121" &
           Taxon !="ASV_5518" & Taxon != "ASV_7536" &
           Taxon !="ASV_7937" & Taxon !="ASV_9777" &
           Taxon !="ASV_11809")

#subset taxa data
taxa.hcht <- taxa %>%
  t(.)%>%
  as.data.frame()%>%
  rownames_to_column(var = "Taxon") %>%
  right_join(op.n.soil.hcht, by = "Taxon")

rownames(taxa.hcht)<- taxa.hcht$Taxon
taxa.hcht <- taxa.hcht%>%
  dplyr::select(-c(Taxon))%>%
  t(.)

#Taxon wise graphs
for(i in colnames(taxa.hcht)) {                                                              
  print(i)                                                                              
  model<-lmer(taxa[,i]~ Seedling_Species*Adult_Species+ (1|Adult_tag:Seedling_Species), data=smd)
  means <- as.data.frame(emmeans(model, ~Seedling_Species*Adult_Species))
  means.hcht <- means %>% filter((means$Adult_Species =="HC"&means$Seedling_Species=="HC") 
                                 | (means$Adult_Species=="HC"& means$Seedling_Species =="HT") 
                                 | (means$Adult_Species =="HT" & means$Seedling_Species =="HT") 
                                 | (means$Adult_Species=="HT"&means$Seedling_Species=="HC")) %>%
    mutate(NewSS = c("H.c.", "H.t.", "H.c.", "H.t."))%>%
    mutate(NewAS = c("Heisteria concinna", "Heisteria concinna", "Hirtella triandra", "Hirtella triandra"))
  filename = paste("figures/MultGLM_contrast_hcht_Nsoil_ASV_07.01.22_", i, sep = "") 
  filepath = paste(filename, ".png", sep= "") 
  png(filepath, width=6, height= 6, units='in', res=300)
  print({ggplot(means.hcht, aes(NewSS, emmean, color=NewSS)) +
      geom_rect(data=means.hcht[2:3,], aes(color= NA, fill = NewAS, alpha =0.1),xmin = -Inf,xmax = Inf,
                ymin = -1000,ymax = 2500, alpha = 0.25) +
      geom_point(position=position_dodge(1), size =4) + 
      geom_errorbar(aes(ymin=emmean-SE, ymax=emmean+SE), width=.5,size=1, position=position_dodge(1))+
      labs(title=i)+
      xlab("Seedling Species")+
      ylab("Estimated abundance")+
      facet_grid(~NewAS)+
      theme_classic()+
      theme(axis.text.y = element_blank(), 
            axis.ticks = element_blank(),  
            axis.title.x = element_text(size=18, family = "Tahoma"), 
            axis.title.y = element_text(size=18, family = "Tahoma"), 
            panel.background = element_blank(), 
            panel.grid.major = element_blank(),  
            panel.grid.minor = element_blank(), 
            plot.background = element_blank(),
            legend.position = "none",
            plot.title = element_text(hjust = 0.5, size = 25))+
      colScale+
      fillScale
    })
  dev.off()
}

png("figures/ASV_179.jpg", width=6, height= 6, units='in', res=300)
p_179
dev.off()

png("figures/ASV_148.jpg", width=6, height= 6, units='in', res=300)
p_148
dev.off()
