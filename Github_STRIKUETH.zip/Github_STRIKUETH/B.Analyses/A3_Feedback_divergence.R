## EXCLOSURE LEVEL (soil)
## For each species pair,
## separate individual tests of feedback (home x 2 away x 2)
## get feedback coefficient
## get microbial divergence in exclosures
## need to repeat for different microbial groups

## biomass diff = ln(finalbiomass)- ln(initialbiomass) = ln(finalbiomass/initialbiomass)
## biomass = ln(biomass)
## use diff2 = negative differences removed

#### PACKAGES ####
# for all analyses 
library(tidyverse)
library(ggplot2)
library(lsmeans)
library(dplyr)
library(lubridate)
library(lmerTest)
library(gridExtra)
library(lme4)
library(gdata)
library(ggeffects)
library(vegan)
library(phyloseq)

###############################
######### READ IN DATA ########
###############################

#july 15
#yday("2019-7-15") #196
#august 15
#yday("2019-8-15") # 227
#sept 15
#yday("2019-8-15") # 258

dat.bioheight <- read.csv("data/BiomassHeightOneRow07.06.22.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() %>%
  rename(Adult_tag = AdultTag) %>%
  mutate(Adult_tag = as.character(Adult_tag),Seedling_Species=as.character(Seedling_Species)) %>%
  dplyr::select(c("Exclosure_Tag","Adult_tag","Adult_Species","Seedling_Species","Height.diff2","BMTotal.diff2", "BMAbove.diff2", "BMBelow.diff2")) %>%
  drop_na()
  
blup.bio<-readRDS("data/blupestimatedbiomas_June10.22.rds") %>%
  mutate(Adult_tag=as.character(Adult_tag),Seedling_Species=as.character(Seedling_Species))

blup.filt <- dat.bioheight %>%
 full_join(blup.bio,by=c("Exclosure_Tag","Adult_tag","Seedling_Species")) %>%
 distinct(Exclosure_Tag, .keep_all=TRUE) %>%
 dplyr::select(c("Exclosure_Tag","Adult_tag","Adult_Species","Seedling_Species","mean_totalbiomass","mean_abovebiomass","mean_belowbiomass")) %>%
 drop_na()

surv <- readRDS('data/survivaldatarepeat.rds')
#On October 1, what was alive? What was still alive that day or after?
#For each observation, was it alive at that point?
surv.A <- surv %>% filter(Survival==1 & mdoy >=227) %>% distinct(Seedling_ID,.keep_all=TRUE)
#On October 1, what was dead? What was dead by that time?
# When things die, this only happens once. did things die before that day?
surv.D <- surv %>% filter(Survival==0 & mdoy <227)

surv.filt <- rbind(surv.A, surv.D) %>%
  group_by(Exclosure_Tag,Survival) %>%
  summarize(N = n()) %>%
  mutate(prop= N / sum(N)) %>%
  filter(Survival==1) %>%
  rename(propsurv=prop) %>%
  left_join(surv, by="Exclosure_Tag") %>%
  dplyr::select(c('Exclosure_Tag','propsurv','AdultTag','Adult_Species','Seedling_Species')) %>%
  dplyr::rename(Adult_tag=AdultTag) %>%
  distinct(Exclosure_Tag,.keep_all=TRUE)%>%
  drop_na()

###############################
##### PAIRWISE FEEDBACK #######
###############################

##!!!!! choose one below

#choose one
dat.filt <- dat.bioheight  # height & biomass
dat.filt <- blup.filt      # blup extracted biomass
dat.filt <- surv.filt      # survival

#lg biomass difference: aka what is the average/total growth in the exclosure

#measured values 
#BMTotal.diff2
#BMAbove.diff2
#BMBelow.diff2
#Height.diff2

#blup values (blup.filt)
#mean_totalbiomass
#mean_abovebiomass
#mean_belowbiomass

#measured survival (surv.filt)
#propsurv

sp.comb <- c("DG_HC","DG_HT", "DG_SA","HC_HT","HC_SA", "SA_HT","HC_DG","HT_DG", "SA_DG","HT_HC","SA_HC", "SA_HT")
  
feedback.out <- data.frame()
# for sp combinations
for(P in sp.comb){ 
  # get A and B
  A <- substr(P, start = 1, stop = 2)
  B <- substr(P, start = 4, stop = 5)
  #subset data to pairs
    pair.dat <- dat.filt %>% filter(Adult_Species == A & Seedling_Species ==A |Adult_Species ==B & Seedling_Species ==A| Adult_Species == A & Seedling_Species ==B |Adult_Species ==B & Seedling_Species ==B) %>%
      mutate(type = case_when(Adult_Species == A & Seedling_Species ==A  ~ "Aa",  
                              Adult_Species ==B & Seedling_Species ==B ~ "Bb",
                              Adult_Species == A & Seedling_Species ==B ~ "Ab",
                              Adult_Species ==B & Seedling_Species ==A ~ "Ba")) 
    #given A adult tag, choose B adult tag
    Adult_tagA <- pair.dat %>% filter(Adult_Species == A) %>% dplyr::select(Adult_tag) %>% distinct() %>% t() %>% as.vector()
    Adult_tagB <- pair.dat %>% filter(Adult_Species == B) %>% dplyr::select(Adult_tag) %>% distinct() %>% t() %>% as.vector()
    rep.dat.out <- data.frame()
     for(AT in Adult_tagA){
      rep.datA <- pair.dat %>% filter(Adult_tag==AT)
      for(BT in Adult_tagB){
        rep.datB <- pair.dat %>% filter(Adult_tag==BT)
        rep.dat <- rbind(rep.datA, rep.datB) 
        rep.dat.bio <- rep.dat %>%
          group_by(type) %>%
          #!!change metric here
          #!!change mean or sum
          summarize(metric = mean(mean_totalbiomass))
        Aa <- rep.dat.bio %>% filter(type=="Aa") %>% dplyr::select(metric)
        Bb <- rep.dat.bio %>% filter(type=="Bb") %>% dplyr::select(metric)
        Ab <- rep.dat.bio %>% filter(type=="Ab") %>% dplyr::select(metric)
        Ba <- rep.dat.bio %>% filter(type=="Ba") %>% dplyr::select(metric)
        if (nrow(Ab)==0 | nrow(Bb)==0 |nrow(Aa) == 0 |nrow(Ba)==0){
          print ("incomplete pair")
        }else{
        fb.coef <-  Aa - Ba - Ab + Bb
        out.dat <- cbind(A,B,AT,BT,fb.coef)
        rep.dat.out <- rbind(rep.dat.out, out.dat)
        }
      }
     }
    feedback.out <- rbind(feedback.out,rep.dat.out)
  }

feedback.out <- feedback.out %>% mutate(ATBT= paste(AT,BT,sep="_")) %>%
  distinct(ATBT,.keep_all=TRUE) %>%
  rename(feedback = metric)

###############################
##### MICROBIAL DIVERGENCE ####
###############################

dat.NP <- read.csv("data/PlantMicrobiomeSoilNonpathsASV.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() 

dat.P <- read.csv("data/PlantMicrobiomeSoilPathsASV.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() 

dat.A <- read.csv("data/PlantMicrobiomeAMFASV.csv",sep=",", header=TRUE) %>%
  dplyr::select(-X) %>%
  drop_na() 

#NP
dat.asv.NP <- dat.NP %>% 
  dplyr::select(-c("Exclosure_Tag","doy.diff.avg","BMT.diff.avg","BMA.diff.avg","BMB.diff.avg",
            "Sample_Name","Seedling_Species","Adult_Species","Group","Sample_Type","Timepoint","Conhetero")) %>% 
  group_by(AdultTag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('AdultTag')

asv.NP = otu_table(as.matrix(dat.asv.NP), taxa_are_rows = FALSE)     
ps.NP <- phyloseq(asv.NP) 

# purge out zero sum OTUS, but also remove rare OTUs (10 reads)
ps.NP <- prune_taxa(taxa_sums(ps.NP)>10,ps.NP) 

# rarify to even depth to compare between samples
set.seed(609) 
sample_sums(ps.NP)
ps.rare.NP <- rarefy_even_depth(ps.NP,sample.size = min(sample_sums(ps.NP)))

# save new meta and asv table
asv.rare.NP <-t(as(otu_table(ps.rare.NP),'matrix')) 
bray_dist.NP <- as.matrix(distance(ps.rare.NP, method = "bray", type = "samples"))  %>% unmatrix() %>% as.data.frame()
colnames(bray_dist.NP) <- c("bray.NP")

bray_dist.df.NP <- bray_dist.NP %>% rownames_to_column("AdultTagC") %>%
  separate(AdultTagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag,Btag,sep="_")) %>%
  dplyr::select(-c("Atag","Btag")) %>%
  filter(!bray.NP==0) %>% 
  distinct(ATBT,.keep_all=TRUE)

#PATH
dat.asv.P <- dat.P %>% 
  dplyr::select(-c("Exclosure_Tag","Adult_tag","doy.diff","BMTotal.diff2","BMAbove.diff2","BMBelow.diff2",
            "Sample_Name","Seedling_Species","Adult_Species","Group","Date_collected","Sample_Type","Timepoint","Conhetero","Seedling_ID")) %>% 
  group_by(AdultTag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('AdultTag')

asv.P = otu_table(as.matrix(dat.asv.P), taxa_are_rows = FALSE)     
ps.P <- phyloseq(asv.P) 

# purge out zero sum OTUS, but also remove rare OTUs (10 reads)
ps.P <- prune_taxa(taxa_sums(ps.P)>10,ps.P) 

# rarify to even depth to compare between samples
set.seed(609) 
sample_sums(ps.P)
ps.rare.P <- rarefy_even_depth(ps.P,sample.size = min(sample_sums(ps.P)))

# save new meta and asv table
asv.rare.P <-t(as(otu_table(ps.rare.P),'matrix')) 
bray_dist.P <- as.matrix(distance(ps.rare.P, method = "bray", type = "samples"))  %>% unmatrix() %>% as.data.frame()
colnames(bray_dist.P) <- c("bray.P")

bray_dist.df.P <- bray_dist.P %>% rownames_to_column("AdultTagC") %>%
  separate(AdultTagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag,Btag,sep="_")) %>%
  dplyr::select(-c("Atag","Btag")) %>%
  filter(!bray.P==0) %>% 
  distinct(ATBT,.keep_all=TRUE)

#AMF
dat.asv.A <- dat.A %>% 
  dplyr::select(-c("Exclosure_Tag","doy.diff.avg","BMT.diff.avg","BMA.diff.avg","BMB.diff.avg",
            "Sample_Name","Seedling_Species","Adult_Species","Group","Sample_Type","Timepoint","Conhetero")) %>% 
  group_by(AdultTag) %>%
  summarise(across(everything(), list(sum))) %>%
  column_to_rownames('AdultTag')

asv.A = otu_table(as.matrix(dat.asv.A), taxa_are_rows = FALSE)     
ps.A <- phyloseq(asv.A) 

# purge out zero sum OTUS, but also remove rare OTUs (10 reads)
ps.A <- prune_taxa(taxa_sums(ps.A)>10,ps.A) 

# rarify to even depth to compare between samples
set.seed(609) 
sample_sums(ps.A)
ps.rare.A <- rarefy_even_depth(ps.A,sample.size = min(sample_sums(ps.A)))

# save new meta and asv table
asv.rare.A <-t(as(otu_table(ps.rare.A),'matrix')) 
bray_dist.A <- as.matrix(distance(ps.rare.A, method = "bray", type = "samples"))  %>% unmatrix() %>% as.data.frame()
colnames(bray_dist.A) <- c("bray.A")

bray_dist.df.A <- bray_dist.A %>% rownames_to_column("AdultTagC") %>%
  separate(AdultTagC, c("Atag", "Btag"), ":")  %>%
  mutate(ATBT = paste(Atag,Btag,sep="_")) %>%
  dplyr::select(-c("Atag","Btag")) %>%
  filter(!bray.A==0) %>% 
  distinct(ATBT,.keep_all=TRUE)

###############################
#### JOIN ALL AND REGRESS #####
###############################

dat.reg <- feedback.out %>%
  left_join(bray_dist.df.NP, by ="ATBT") %>%
  left_join(bray_dist.df.P, by ="ATBT") %>%
  left_join(bray_dist.df.A, by ="ATBT") %>%
  mutate(AB = map2_chr(A, B, ~toString(sort(c(.x, .y))))) 

#choose one:
#m1 <- lm(feedback ~ bray.NP+bray.P+bray.A, data=dat.reg)
m1 <- lm(feedback ~ bray.NP, data=dat.reg)
m1 <- lm(feedback ~ bray.P, data=dat.reg)
m1 <- lm(feedback ~ bray.A, data=dat.reg)

summary(m1)
anova(m1)

#check model
par(mfrow = c(2, 2))
plot(m1)

m1.plot <- ggeffect(m1, terms = c("bray.NP"), type= "re")
plot(m1.plot,raw=TRUE)

m1.plot <- ggeffect(m1, terms = c("bray.P"), type= "re")
plot(m1.plot,raw=TRUE)

#### Visualisation ####

new.dat <- with(dat.reg, expand.grid(bray.NP = seq(min(na.omit(dat.reg$bray.NP)), max(na.omit(dat.reg$bray.NP)), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.NP=new.dat$bray.NP)

#TOTAL BIOMASS NON-PATHOGEN
TB.NP <-
ggplot(data = pred,aes(x = bray.NP, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.NP),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Non-pathogen)") +
  ylab("Feedback (Biomass)")+
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

new.dat <- with(dat.reg, expand.grid(bray.P = seq(min(na.omit(dat.reg$bray.P)), max(na.omit(dat.reg$bray.P)), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.P=new.dat$bray.P)

#TOTAL BIOMASS PATHOGEN
TB.P <-
  ggplot(data = pred,aes(x = bray.P, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.P),color="dimgrey", size= 2)+ 
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Pathogen)") +
  ylab("Feedback (total biomass)")+
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

#SURVIVAL PATHOGEN 

new.dat <- with(dat.reg, expand.grid(bray.P = seq(min(na.omit(dat.reg$bray.P)), max(na.omit(dat.reg$bray.P)), length = 100))) 
pred <- predict(m1,newdata = new.dat,type = "response", se=TRUE) %>%
  as.data.frame() %>% 
  mutate(bray.P=new.dat$bray.P)

SUR.P <- 
  ggplot(data = pred,aes(x = bray.P, y = fit))+
  geom_line() +
  geom_ribbon(aes(ymin = fit-se.fit, ymax = fit+se.fit), alpha = .1) + 
  geom_point(data= dat.reg, aes(y=feedback, x=bray.P),color="dimgrey", size= 2) +
  theme(axis.title.y = element_text(color="black",size= 25))+
  theme(axis.title.x = element_text(color="black",size= 25))+
  xlab("Bray dissimilarity (Pathogen)") +
  ylab("Feedback (Survival)")+
  theme_classic()+
  theme(axis.text.x = element_blank(),  
        axis.text.y = element_blank(), 
        axis.ticks = element_blank(),  
        axis.title.x = element_text(size=18, family = "Tahoma"), 
        axis.title.y = element_text(size=18, family = "Tahoma"), 
        panel.background = element_blank(), 
        panel.grid.major = element_blank(),  
        panel.grid.minor = element_blank(), 
        plot.background = element_blank(),
        legend.position = "bottom",
        plot.title = element_text(hjust = 0.5, size = 25))

png("Figures/Figure5_27.6.22.jpg", width=12, height= 6, units='in', res=300)
grid.arrange(TB.NP,SUR.P, ncol=2)
dev.off()

