# Clean metadata:

#load packages:
library(tidyverse)

# import meta data
meta.seed <- read.table('data/Seedling_Metadata_05.27.2021.txt',header=TRUE)
meta.soil.1 <- read.table('data/Sequenced_soil_metadata_1.txt',header=TRUE)
meta.soil.2 <- read.table('data/Sequenced_soil_metadata_2.txt',header=TRUE)

meta.soil <- meta.soil.1 %>% full_join(meta.soil.2, by ="Soil_ID") %>%
  mutate(Sample_Type ="Soil") %>%
  select(-Soil_ID)
meta.seed <- meta.seed %>%
  rename(Adult_Tag = Adult_tag)

# add Sample_Type:
meta.seed.root<-filter(meta.seed, grepl("_R",Sample_Name)) %>%
  mutate(Sample_Type="Root")
meta.seed.leaf<-filter(meta.seed, grepl("_L",Sample_Name)) %>%
  mutate(Sample_Type="Leaf")
meta.seed<-rbind(meta.seed.root,meta.seed.leaf)
meta.seed$Timepoint<- "1"

# add timepoint to roots:
meta.soil.T2<- filter(meta.soil, grepl("_T",Sample_Name)) %>%
  mutate(Timepoint="2")
meta.soil.T1<- filter(meta.soil, grepl("_S",Sample_Name)) %>%
  mutate(Timepoint="1")
meta.soil<-rbind(meta.soil.T1, meta.soil.T2)

# join meta.seed and meta.soil:
meta <- bind_rows(meta.seed,meta.soil) %>% 
  select(-c('Seedling_ID','Status','Sample_Name')) %>%
  mutate_all(as.factor)

saveRDS(meta, file="data/meta.data.complete_5.28.21.RDS")

# some changes in the data sheets
dat <- read_tsv("data/ASVtable_clean_AMFonly.tsv") %>%
  rename(X.Taxa.ID = X.ASV.ID) 
write.csv(dat, file = "data/ASVtable_clean_AMFonly.csv")

dat <- read_tsv("data/otu97table_clean_AMFonly.tsv")%>%
  rename (X.Taxa.ID = X.OTU.ID)
write.csv(dat, file = "data/otu97table_clean_AMFonly.csv")

asvsFUN <- read.delim('data/table_or_97_STRI_ASVFUN_R1_R2_forR.txt', header=TRUE,sep='\t')%>%
  rename(Taxa_ID = OTU_ID)
write.csv(asvsFUN, file = "data/table_or_97_STRI_ASVFUN_R1_R2_forR.csv")

guildFUN <- read.delim('data/table_or_97_STRI_ASVFUN_R1_R2_tax.guilds.txt', header=TRUE,sep='\t')%>%
  rename(Taxa_ID = OTU.ID)
write.csv(guildFUN, file = "data/table_or_97_STRI_ASVFUN_R1_R2_tax.guilds.csv")

asvsFUN <- read.delim("data/table_or_97_STRI_FUN_R1_R2_forR.txt", header= TRUE, sep='\t')%>%
  rename(Taxa_ID = OTU_ID)
write.csv(asvsFUN, file = "data/table_or_97_STRI_FUN_R1_R2_forR.csv")

asvsFUN <- read.delim("data/table_or_97_STRI_FUN_R1_R2_tax.guilds.txt", header= TRUE, sep='\t')%>%
  rename(Taxa_ID = OTU.ID)
write.csv(asvsFUN, file = "data/table_or_97_STRI_FUN_R1_R2_tax.guilds.csv")
